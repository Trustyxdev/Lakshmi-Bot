# Lakshmi - Discord Bot

<div align="center">

**A powerful multipurpose Discord bot with moderation, anti-nuke, music, games, and more.**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Discord](https://img.shields.io/badge/Discord-Join%20Community-7289DA)](https://discord.gg/ibadat)
[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://www.python.org/downloads/)

**Developed by Trusty X Ayaan | Krishx Development**

</div>

---

## ⚠️ IMPORTANT LEGAL NOTICE

**🔴 READ BEFORE USING:**

This software is **open-source** and **free to use**, but comes with **mandatory attribution requirements**.

- ✅ **You CAN:** Use, modify, and distribute this bot freely
- ❌ **You CANNOT:** Remove credits or claim it as your own work
- ⚖️ **Violations will result in:** DMCA takedowns and legal action

**📜 Full Terms:** See [LICENSE](LICENSE) and [DISCLAIMER.md](DISCLAIMER.md)

**🔍 This codebase contains 509 embedded attribution markers across 153+ files for copyright protection.**

---

## Features

- **Anti-Nuke Protection** - Protect your server from raids
- **Moderation** - Ban, kick, mute, warn, purge
- **Auto-Moderation** - Anti-spam, anti-caps, anti-link
- **Music Player** - Play music from YouTube, Spotify
- **Giveaways** - Host giveaways with custom branding
- **Games** - 2048, Battleship, Country Guess, etc.
- **Leveling System** - XP and ranks
- **Ticket System** - Support tickets
- **Auto-Roles** - Assign roles automatically
- **Logging** - Track server events

## Setup

1. Install Python 3.11+
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Copy `.env.example` to `.env` and add your bot token
4. Run the bot:
   ```
   python bot.py
   ```

## Configuration

Edit `.env` file:
```
TOKEN=your_bot_token_here
BOT_PREFIX=.
```

Get your bot token from [Discord Developer Portal](https://discord.com/developers/applications)

Enable these intents:
- Presence Intent
- Server Members Intent  
- Message Content Intent

## Commands

Use `.help` to see all commands

**Moderation:**
- `.ban @user` - Ban user
- `.kick @user` - Kick user
- `.timeout @user` - Timeout user
- `.purge <amount>` - Delete messages

**Anti-Nuke:**
- `.antinuke enable` - Enable protection
- `.whitelist add @user` - Add to whitelist

**Music:**
- `.play <song>` - Play music
- `.skip` - Skip song
- `.queue` - View queue

**Giveaway:**
- `.gstart` - Start giveaway
- `.gend` - End giveaway

## Credits

**Original Developers:** Trusty X Ayaan  
**Organization:** Krishx Development  
**Community:** [discord.gg/ibadat](https://discord.gg/ibadat)

### ⚠️ Attribution Requirements

This bot is licensed under MIT License **with mandatory attribution**. If you use, modify, or distribute this bot:

1. ✅ **KEEP** all developer credits in the source code
2. ✅ **MAINTAIN** the "Dev: Trusty X Ayaan" comments
3. ✅ **INCLUDE** proper attribution in your README
4. ✅ **LINK** to this repository and our community

**Failure to comply may result in legal action. See [LICENSE](LICENSE) for full terms.**

---

## License

This project is licensed under the **MIT License with Attribution Requirements**.

- 📜 See [LICENSE](LICENSE) file for full license text
- ⚠️ See [DISCLAIMER.md](DISCLAIMER.md) for legal terms and conditions
- 🔒 **509 embedded attribution markers** protect copyright

**© 2024-2026 Trusty X Ayaan | Krishx Development | All Rights Reserved**

---

## ⚖️ Legal Protection

This codebase is protected by:
- ✅ International copyright law
- ✅ DMCA (Digital Millennium Copyright Act)
- ✅ Embedded attribution markers (509 locations)
- ✅ Code fingerprinting technology

**Unauthorized credit removal will be detected and prosecuted.**

---

<div align="center">

**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

### 🙏 Thank you for respecting open source and supporting developers!

**If you find this bot useful, please:**
- ⭐ Star this repository
- 🔗 Give proper credit
- 💬 Join our community: [discord.gg/ibadat](https://discord.gg/ibadat)
- 🤝 Contribute improvements back to the project

**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

**Made with ❤️ by Trusty X Ayaan**

</div>
