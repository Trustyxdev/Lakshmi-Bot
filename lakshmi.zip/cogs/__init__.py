"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
from __future__ import annotations 
from core import Lakshmi 
from colorama import Fore ,Style ,init 
from utils.logger import logger
import asyncio 
import traceback 


init (autoreset =True )


from .commands .help import Help 
from .commands .helpslash import HelpSlash 
from .commands .general import General 
from .commands .tracking import TrackingCog 
from .commands .unblacklist import Unblacklist 
from .commands .counting import Counting 
from .commands .automod import Automod 
from .commands .welcomer import Welcomer 
from .commands .leveling import Leveling 
from .commands .fun import Fun 

from .commands .Games import Games 
from .commands .extra import Extra 
from .commands .owner import Owner 
from .commands .voice import Voice 
from .commands .afk import afk 
from .commands .ignore import Ignore 
from .commands .Media import Media 
from .commands .Invc import Invcrole 
from .commands .giveaway import Giveaway 
from .commands .Embed import Embed 
from .commands .steal import Steal 
from .commands .premium import Premium 
from .commands .ticket import AdvancedTicketSystem 
from .commands .timer import Timer 
from .commands .roleplay import Roleplay 
from .commands .blacklist import Blacklist 
from .commands .block import Block 
from .commands .nightmode import Nightmode 
from .commands .ai import AI 
from .commands .owner import Badges 
from .commands .autoresponder import AutoResponder 
from .commands .customrole import Customrole 
from .commands .autorole import AutoRole 
from .commands .antinuke import Antinuke 
from .commands .extraown import Extraowner 
from .commands .anti_wl import Whitelist 
from .commands .anti_unwl import Unwhitelist 
from .commands .slots import Slots 
from .commands .autoreact import AutoReaction 
from .commands .stats import Stats 
from .commands .notify import NotifCommands 
from .commands .np import NoPrefix 
from .commands .filters import FilterCog 
from .commands .owner2 import Global 
from .commands .backup_final import Backup 
from .commands .sticky import Sticky
from .commands .vanityroles import VanityRoles 
from .commands .todo import TodoList
from .commands .googlelens import GoogleLens
from .commands .googlesearch import GoogleSearch
from .commands .pfps import ProfilePictures 
from .commands .guildprofile import GuildProfile
from .commands .botstatus import BotStatus
from .commands .crypto import Crypto
from .commands .purge import Purge
from .commands .chatban import ChatBan
from .commands .wordblacklist import WordBlacklist
from .commands .embed_commands import EmbedBuilder
from .commands .antibot import AntiBot
from .commands .autorole_commands import AutoRole as AutoRoleCommands
from .commands .autoresponder_commands import AutoResponder as AutoResponderCommands
from .commands .autoreact_commands import AutoReact
from .commands .greetings import Greetings
# from .commands .music import AdvancedMusic as Music  # Disabled - conflicts with SimpleVoice
# from .commands .music_ytdl import MusicYTDL  # Disabled - conflicts with SimpleVoice
from .commands .voice_simple import SimpleVoice
from .commands .server_logging import Logging
from .commands .tempvc import TempVC
from .commands .profile import Profile
from .commands .branding import Branding
from .commands .variables import Variables
from .commands .mainrole import MainRole
from .commands .panicmode import PanicMode
from .commands .permit import Permit
from .commands .trusted import Trusted
from .commands .prefix import Prefix
from .commands .profile_commands import ProfileCommands
from .commands .owner_commands import OwnerCommands
from .commands .music_display import MusicDisplay
from .commands .botaccess import BotAccess
from .commands .playlist import Playlist
from .commands .spotify_integration import SpotifyIntegration
from .commands .owner_status import OwnerStatus



from .events .autoblacklist import AutoBlacklist 
from .events .Errors import Errors 
from .events .on_guild import Guild 
from .events .autorole import Autorole2 
from .events .auto import Autorole 
from .events .greet2 import greet 
from .events .mention import Mention 
from .events .ai import AIResponses 
from .events .autoreact import AutoReactListener
from .events .stickymessage import StickyMessageListener 




try:
    from .Lakshmi.main_menu.general import _general
    from .Lakshmi.main_menu.voice import _voice
    from .Lakshmi.main_menu.games import _games
    from .Lakshmi.main_menu.welcome import _welcome
    from .Lakshmi.main_menu.stickymessage import __sticky
    from .Lakshmi.main_menu.ticket import ticket

    from .Lakshmi.extra_menu.antinuke import _antinuke
    from .Lakshmi.extra_menu.automod import _automod
    from .Lakshmi.extra_menu.leveling import _leveling
    from .Lakshmi.extra_menu.extra import _extra
    from .Lakshmi.extra_menu.fun import _fun
    from .Lakshmi.extra_menu.ai import _ai
    from .Lakshmi.extra_menu.giveaway import _giveaway
    from .Lakshmi.extra_menu.moderation import _moderation
    from .Lakshmi.extra_menu.server import _server
    from .Lakshmi.extra_menu.roleplay import RoleplayHelp
    from .Lakshmi.extra_menu.verification import VerificationHelp
    from .Lakshmi.extra_menu.tracking import _tracking
    # from .Lakshmi.extra_menu.logging import _logging  # File doesn't exist
    from .Lakshmi.extra_menu.counting import _counting
    from .Lakshmi.extra_menu.backup import _Backup
    from .Lakshmi.extra_menu.crew import _crew
    from .Lakshmi.extra_menu.ignore import _ignore
    
    LAKSHMI_MODULES = [
        (_general, "_general"),
        (_voice, "_voice"),
        (_games, "_games"),
        (_welcome, "_welcome"),
        (__sticky, "__sticky"),
        (ticket, "_ticket"),
        (_antinuke, "_antinuke"),
        (_automod, "_automod"),
        (_leveling, "_leveling"),
        (_extra, "_extra"),
        (_fun, "_fun"),
        (_ai, "_ai"),
        (_giveaway, "_giveaway"),
        (_moderation, "_moderation"),
        (_server, "_server"),
        (RoleplayHelp, "RoleplayHelp"),
        (VerificationHelp, "VerificationHelp"),
        (_tracking, "_tracking"),
        # (_logging, "_logging"),  # File doesn't exist
        (_counting, "_counting"),
        (_Backup, "_Backup"),
        (_crew, "_crew"),
        (_ignore, "_ignore"),
    ]
except ModuleNotFoundError:
    LAKSHMI_MODULES = [] 

from .antinuke .anti_member_update import AntiMemberUpdate 
from .antinuke .antiban import AntiBan 
from .antinuke .antibotadd import AntiBotAdd 
from .antinuke .antichcr import AntiChannelCreate 
from .antinuke .antichdl import AntiChannelDelete 
from .antinuke .antichup import AntiChannelUpdate 
from .antinuke .antieveryone import AntiEveryone 
from .antinuke .antiguild import AntiGuildUpdate 
from .antinuke .antiIntegration import AntiIntegration 
from .antinuke .antikick import AntiKick 
from .antinuke .antiprune import AntiPrune 
from .antinuke .antirlcr import AntiRoleCreate 
from .antinuke .antirldl import AntiRoleDelete 
from .antinuke .antirlup import AntiRoleUpdate 
from .antinuke .antiwebhook import AntiWebhookUpdate 
from .antinuke .antiwebhookcr import AntiWebhookCreate 
from .antinuke .antiwebhookdl import AntiWebhookDelete 






# Dev: Trusty X Ayaan



from .automod .antispam import AntiSpam 
from .automod .anticaps import AntiCaps 
from .automod .antilink import AntiLink 
from .automod .anti_invites import AntiInvite 
from .automod .anti_mass_mention import AntiMassMention 
from .automod .anti_emoji_spam import AntiEmojiSpam 

from .moderation .ban import Ban 
from .moderation .unban import Unban 
from .moderation .timeout import Mute 
from .moderation .unmute import Unmute 
from .moderation .lock import Lock 
from .moderation .unlock import Unlock 
from .moderation .hide import Hide 
from .moderation .unhide import Unhide 
from .moderation .kick import Kick 
from .moderation .warn import Warn 
from .moderation .role import Role 
from .moderation .message import Message 
from .moderation .moderation import Moderation 
from .moderation .topcheck import TopCheck 
from .moderation .snipe import Snipe 
# Made by Trusty X Ayaan Dev


async def setup (bot :Lakshmi ):
    """Load all bot modules with grouped progress reporting"""
    
    # Categorize cogs for organized loading
    command_cogs = [
        (Help ,"Help"), (HelpSlash ,"HelpSlash"), (General ,"General"),
        (Fun ,"Fun"), (Games ,"Games"), (Extra ,"Extra"), (Owner ,"Owner"),
        (Extraowner ,"Extraowner"), (afk ,"afk"), (Embed ,"Embed"),
        (Media ,"Media"), (Steal ,"Steal"), (Premium ,"Premium"),
        (Timer ,"Timer"), (Roleplay ,"Roleplay"), (Slots ,"Slots"),
        (Stats ,"Stats"), (NoPrefix ,"NoPrefix"), (FilterCog ,"FilterCog"),
        (Global ,"Global"), (VanityRoles ,"VanityRoles"), (TodoList ,"TodoList"),
        (GoogleLens ,"GoogleLens"), (GoogleSearch ,"GoogleSearch"),
        (ProfilePictures ,"ProfilePictures"), (GuildProfile ,"GuildProfile"),
        (BotStatus ,"BotStatus"), (Crypto ,"Crypto"), (Purge ,"Purge"),
        (ChatBan ,"ChatBan"), (WordBlacklist ,"WordBlacklist"),
        (EmbedBuilder ,"EmbedBuilder"), (AntiBot ,"AntiBot"),
        (Greetings ,"Greetings"), (Profile ,"Profile"), (Branding ,"Branding"),
        (Variables ,"Variables"), (MainRole ,"MainRole"), (PanicMode ,"PanicMode"),
        (Permit ,"Permit"), (Trusted ,"Trusted"), (Prefix ,"Prefix"),
        (ProfileCommands ,"ProfileCommands"), (OwnerCommands ,"OwnerCommands"),
        (BotAccess ,"BotAccess"), (Playlist ,"Playlist"),
        (SpotifyIntegration ,"SpotifyIntegration"), (NotifCommands ,"NotifCommands"),
        (OwnerStatus ,"OwnerStatus"),
    ]
    
    antinuke_cogs = [
        (Antinuke ,"Antinuke"), (Whitelist ,"Whitelist"), (Unwhitelist ,"Unwhitelist"),
        (AntiMemberUpdate ,"AntiMemberUpdate"), (AntiBan ,"AntiBan"),
        (AntiBotAdd ,"AntiBotAdd"), (AntiChannelCreate ,"AntiChannelCreate"),
        (AntiChannelDelete ,"AntiChannelDelete"), (AntiChannelUpdate ,"AntiChannelUpdate"),
        (AntiEveryone ,"AntiEveryone"), (AntiGuildUpdate ,"AntiGuildUpdate"),
        (AntiIntegration ,"AntiIntegration"), (AntiKick ,"AntiKick"),
        (AntiPrune ,"AntiPrune"), (AntiRoleCreate ,"AntiRoleCreate"),
        (AntiRoleDelete ,"AntiRoleDelete"), (AntiRoleUpdate ,"AntiRoleUpdate"),
        (AntiWebhookUpdate ,"AntiWebhookUpdate"), (AntiWebhookCreate ,"AntiWebhookCreate"),
        (AntiWebhookDelete ,"AntiWebhookDelete"),
    ]
    
    automod_cogs = [
        (Automod ,"Automod"), (AntiSpam ,"AntiSpam"), (AntiCaps ,"AntiCaps"),
        (AntiLink ,"AntiLink"), (AntiInvite ,"AntiInvite"),
        (AntiMassMention ,"AntiMassMention"), (AntiEmojiSpam ,"AntiEmojiSpam"),
    ]
    
    moderation_cogs = [
        (Ban ,"Ban"), (Unban ,"Unban"), (Mute ,"Mute"), (Unmute ,"Unmute"),
        (Lock ,"Lock"), (Unlock ,"Unlock"), (Hide ,"Hide"), (Unhide ,"Unhide"),
        (Kick ,"Kick"), (Warn ,"Warn"), (Role ,"Role"), (Message ,"Message"),
        (Moderation ,"Moderation"), (TopCheck ,"TopCheck"), (Snipe ,"Snipe"),
    ]
    
    utility_cogs = [
        (Leveling ,"Leveling"), (TrackingCog ,"TrackingCog"), (Counting ,"Counting"),
        (Unblacklist ,"Unblacklist"), (Backup ,"Backup"), (Welcomer ,"Welcomer"),
        (Sticky ,"Sticky"), (StickyMessageListener ,"StickyMessageListener"),
        (Voice ,"Voice"), (Customrole ,"Customrole"), (Ignore ,"Ignore"),
        (Invcrole ,"Invcrole"), (Giveaway ,"Giveaway"), (AdvancedTicketSystem ,"AdvancedTicketSystem"),
        (Blacklist ,"Blacklist"), (Block ,"Block"), (Nightmode ,"Nightmode"),
        (AI ,"AI"), (Badges ,"Badges"), (AutoRoleCommands ,"AutoRoleCommands"),
        (AutoResponderCommands ,"AutoResponderCommands"), (AutoReact ,"AutoReact"),
        (SimpleVoice ,"SimpleVoice"), (Logging ,"Logging"), (TempVC ,"TempVC"),
        (MusicDisplay ,"MusicDisplay"),
    ]
    
    event_cogs = [
        (AutoBlacklist ,"AutoBlacklist"), (Guild ,"Guild"), (Errors ,"Errors"),
        (Autorole2 ,"Autorole2"), (Autorole ,"Autorole"), (greet ,"greet"),
        (AutoResponder ,"AutoResponder"), (Mention ,"Mention"), (AutoRole ,"AutoRole"),
        (AutoReaction ,"AutoReaction"), (AutoReactListener ,"AutoReactListener"),
    ]

    # Group all cogs with their categories
    cog_groups = [
        ("command", command_cogs),
        ("antinuke", antinuke_cogs),
        ("automod", automod_cogs),
        ("moderation", moderation_cogs),
        ("utility", utility_cogs),
        ("event", event_cogs),
    ]
    
    # Add Lakshmi modules if available
    if LAKSHMI_MODULES:
        cog_groups.append(("lakshmi", LAKSHMI_MODULES))

    total_loaded = 0
    total_failed = 0
    failed_cogs = []

    # Load each category
    for category, cogs_list in cog_groups:
        category_loaded = 0
        for cog_class, cog_name in cogs_list:
            try:
                await bot.add_cog(cog_class(bot))
                category_loaded += 1
                total_loaded += 1
            except Exception as e:
                failed_cogs.append(cog_name)
                total_failed += 1
                # Only log individual failures to file, not console
                logger.debug("INIT", f"Failed to load {cog_name}: {str(e)}")
        
        # Show category summary
        if category_loaded > 0:
            category_names = {
                "command": "Command modules",
                "antinuke": "Anti-nuke protection",
                "automod": "Auto-moderation",
                "moderation": "Moderation tools",
                "utility": "Utility features",
                "event": "Event listeners",
                "lakshmi": "Extended features"
            }
            logger.info("LOAD", f"{category_names.get(category, category.title())} loaded ({category_loaded})")

    # Final summary
    if failed_cogs:
        logger.error("BOOT", f"Failed to load {total_failed} modules")
    
    logger.success("BOOT", f"All modules loaded successfully ({total_loaded} total)")



"""
: ! Lakshmi !
# Created by Trusty X Ayaan
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""

