"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
from discord.ext import commands
from utils.Tools import blacklist_check, ignore_check
# Code by Trusty X Ayaan


# Trusty X Ayaan - Krishx Dev
class WordBlacklist(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/bot_database.db") as db:
            await db.execute(
                """CREATE TABLE IF NOT EXISTS word_blacklist (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER,
                    word TEXT,
                    punishment TEXT DEFAULT 'delete',
                    added_by INTEGER,
                    added_at TEXT,
                    UNIQUE(guild_id, word)
                )"""
            )
            await db.execute(
                """CREATE TABLE IF NOT EXISTS word_violations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER,
                    user_id INTEGER,
                    word TEXT,
                    violation_count INTEGER DEFAULT 1,
                    last_violation TEXT
                )"""
            )
            await db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000
        )
        for key, value in kwargs.items():
            if value:
                embed.add_field(name=key, value=value, inline=False)
        return embed

    @commands.group(name="blword", invoke_without_command=True)
    @commands.has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def blword(self, ctx):
        """Manage word blacklist"""
        await ctx.send_help(ctx.command)

    @blword.command(name="add")
    @commands.has_permissions(manage_messages=True)
    async def blword_add(self, ctx, word: str, punishment: str = "delete"):
        """Add a word to the blacklist"""
        if punishment not in ["delete", "warn", "mute", "kick"]:
            embed = self.create_embed(
                "❌ Invalid Punishment",
                "Valid punishments: delete, warn, mute, kick"
            )
            return await ctx.reply(embed=embed)

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO word_blacklist 
                    (guild_id, word, punishment, added_by, added_at)
                    VALUES (?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, word.lower(), punishment, ctx.author.id)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Word Added",
                f"Added '{word}' to blacklist with punishment: **{punishment}**"
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to add word: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @blword.command(name="remove")
    @commands.has_permissions(manage_messages=True)
    async def blword_remove(self, ctx, word: str):
        """Remove a word from the blacklist"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM word_blacklist WHERE guild_id = ? AND word = ?",
                    (ctx.guild.id, word.lower())
                )
                existing = await cursor.fetchone()

                if not existing:
                    embed = self.create_embed(
                        "❌ Word Not Found",
                        f"'{word}' is not in the blacklist."
                    )
                    return await ctx.reply(embed=embed)

                await db.execute(
                    "DELETE FROM word_blacklist WHERE guild_id = ? AND word = ?",
                    (ctx.guild.id, word.lower())
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Word Removed",
                f"Removed '{word}' from blacklist."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to remove word: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @blword.command(name="list")
    @commands.has_permissions(manage_messages=True)
    async def blword_list(self, ctx):
        """View all blacklisted words"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    "SELECT * FROM word_blacklist WHERE guild_id = ? ORDER BY added_at DESC",
                    (ctx.guild.id,)
                )
                words = await cursor.fetchall()

            if not words:
                embed = self.create_embed(
                    "📋 Word Blacklist",
                    "No words are currently blacklisted."
                )
                return await ctx.reply(embed=embed)

            word_text = ""
            for idx, word_entry in enumerate(words, 1):
                word_text += f"**{idx}.** `{word_entry['word']}`\n"
                word_text += f"   Punishment: {word_entry['punishment']}\n"

            embed = self.create_embed(
                "📋 Word Blacklist",
                word_text
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to fetch blacklist: {str(e)}"
# Created by Trusty X Ayaan
            )
            await ctx.reply(embed=embed)

    @blword.command(name="violations")
    @commands.has_permissions(manage_messages=True)
    async def blword_violations(self, ctx, user: discord.User = None):
        """View word violation records"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                if user:
                    cursor = await db.execute(
                        """SELECT * FROM word_violations 
                        WHERE guild_id = ? AND user_id = ? 
                        ORDER BY last_violation DESC""",
                        (ctx.guild.id, user.id)
                    )
                else:
                    cursor = await db.execute(
                        """SELECT * FROM word_violations 
                        WHERE guild_id = ? 
                        ORDER BY last_violation DESC LIMIT 20""",
                        (ctx.guild.id,)
                    )
                violations = await cursor.fetchall()

            if not violations:
                embed = self.create_embed(
                    "📋 Violations",
                    "No violations found."
                )
                return await ctx.reply(embed=embed)

            violation_text = ""
            for idx, violation in enumerate(violations, 1):
                violator = self.bot.get_user(violation['user_id'])
                violator_name = violator.mention if violator else f"Unknown ({violation['user_id']})"
                violation_text += f"**{idx}.** {violator_name}\n"
                violation_text += f"   Word: `{violation['word']}`\n"
                violation_text += f"   Count: {violation['violation_count']}\n\n"

            embed = self.create_embed(
                "📋 Word Violations",
                violation_text
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to fetch violations: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @blword.command(name="clear")
    @commands.has_permissions(manage_messages=True)
    async def blword_clear(self, ctx):
        """Clear all blacklisted words"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT COUNT(*) FROM word_blacklist WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                count = await cursor.fetchone()

                if count[0] == 0:
                    embed = self.create_embed(
                        "❌ No Words",
                        "There are no blacklisted words to clear."
                    )
                    return await ctx.reply(embed=embed)

                await db.execute(
                    "DELETE FROM word_blacklist WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Blacklist Cleared",
                f"Removed **{count[0]}** words from the blacklist."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to clear blacklist: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    "SELECT * FROM word_blacklist WHERE guild_id = ?",
                    (message.guild.id,)
                )
                blacklisted_words = await cursor.fetchall()

                for word_entry in blacklisted_words:
                    if word_entry['word'] in message.content.lower():
                        punishment = word_entry['punishment']

                        # Log violation
                        cursor = await db.execute(
                            """SELECT * FROM word_violations 
                            WHERE guild_id = ? AND user_id = ? AND word = ?""",
                            (message.guild.id, message.author.id, word_entry['word'])
                        )
                        violation = await cursor.fetchone()

                        if violation:
                            await db.execute(
                                """UPDATE word_violations 
                                SET violation_count = violation_count + 1, last_violation = datetime('now')
                                WHERE guild_id = ? AND user_id = ? AND word = ?""",
                                (message.guild.id, message.author.id, word_entry['word'])
                            )
                        else:
                            await db.execute(
                                """INSERT INTO word_violations 
                                (guild_id, user_id, word, violation_count, last_violation)
                                VALUES (?, ?, ?, 1, datetime('now'))""",
                                (message.guild.id, message.author.id, word_entry['word'])
                            )
                        await db.commit()

                        # Apply punishment
                        if punishment == "delete":
                            try:
                                await message.delete()
                            except:
                                pass
                        elif punishment == "warn":
                            try:
                                await message.author.send(
                                    f"⚠️ Warning: Your message in {message.guild.name} contained a blacklisted word."
                                )
                            except:
                                pass
                        elif punishment == "mute":
                            try:
                                await message.delete()
                                await message.author.send(
                                    f"🔇 You have been muted in {message.guild.name} for using a blacklisted word."
                                )
                            except:
                                pass
                        elif punishment == "kick":
                            try:
                                await message.guild.kick(
                                    message.author,
                                    reason=f"Used blacklisted word: {word_entry['word']}"
                                )
                            except:
                                pass
                        break
        except:
            pass


async def setup(bot):
    await bot.add_cog(WordBlacklist(bot))
