"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord 
from discord .ext import commands 
from discord .ui import View ,Button 
import requests 
from io import BytesIO 
import re 
from utils .Tools import *

# Trusty X Ayaan - Krishx Dev
class Steal (commands .Cog ):
    def __init__ (self ,bot ):
        self .bot =bot 



    @commands .hybrid_command (name ="steal",help ="Steal an emoji or sticker",usage ="steal <emoji>",aliases =["eadd"],with_app_command =True )
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )
    @commands .has_permissions (manage_emojis =True )
    async def steal (self ,ctx ,emote =None ):
        if ctx .message .reference :
            ref_message =await ctx .channel .fetch_message (ctx .message .reference .message_id )
            attachments =ref_message .attachments 
            stickers =ref_message .stickers 
            emojis =[emote for emote in ref_message .content .split ()if emote .startswith ('<:')or emote .startswith ('<a:')]

            if attachments or stickers or emojis :
                await self .create_buttons (ctx ,attachments ,stickers ,emojis )
                return 

        if emote :
            await self .process_emoji (ctx ,emote )
        else :
            await ctx .send (embed =discord .Embed (title ="Steal",description ="No emoji or sticker found",color =0x000000 ))

    async def process_emoji (self ,ctx ,emote ):
        try :
            if emote [0 ]=='<':
                name =emote .split (':')[1 ]
                emoji_id =emote .split (':')[2 ][:-1 ]
                anim =emote .split (':')[0 ]
                if anim =='<a':
                    url =f'https://cdn.discordapp.com/emojis/{emoji_id}.gif'
                else :
                    url =f'https://cdn.discordapp.com/emojis/{emoji_id}.png'
                await self .add_emoji (ctx ,url ,name ,animated =(anim =='<a'))
            else :
                await ctx .send (embed =discord .Embed (title ="Steal",description ="Invalid emoji",color =0x000000 ))
        except Exception as e :
            await ctx .send (embed =discord .Embed (title ="Steal",description =f"Failed to add emoji: {str(e)}",color =0x000000 ))

    async def add_emoji (self ,ctx ,url ,name ,animated ):
        try :
            if not self .has_emoji_slot (ctx .guild ,animated ):
                await ctx .send (embed =discord .Embed (title ="Steal",description ="No more emoji slots available",color =0x2f3136 ))
                return 

            sanitized_name =self .sanitize_name (name )
            response =requests .get (url )
            img =response .content 
            emote =await ctx .guild .create_custom_emoji (name =sanitized_name ,image =img )
            await ctx .send (embed =discord .Embed (title ="Steal",description =f"Added emoji \"**{emote}**\"!",color =0x000000 ))
        except Exception as e :
            await ctx .send (embed =discord .Embed (title ="Steal",description =f"Failed to add emoji: {str(e)}",color =0x2f3136 ))

    async def add_sticker (self ,ctx ,url ,name ):
        try :
            if len (ctx .guild .stickers )>=self .get_max_sticker_count (ctx .guild ):
                await ctx .send (embed =discord .Embed (title ="Steal",description ="No more sticker slots available",color =0x000000 ))
                return 

            sanitized_name =self .sanitize_name (name )
            response =requests .get (url )
            img_data = response .content
            
            # Process and optimize image to fit under 512KB
            try:
                from PIL import Image
                import io
# Built by Trusty X Ayaan Dev
                
                # Open image
                img = Image.open(BytesIO(img_data))
                
                # Convert to RGBA if needed (for transparency support)
                if img.mode not in ('RGBA', 'RGB'):
                    img = img.convert('RGBA')
                
                # Start with original size
                quality = 95
                max_size = 512000  # 512KB in bytes
                
                # Resize if image is too large (max 320x320 for stickers)
                max_dimension = 320
                if img.width > max_dimension or img.height > max_dimension:
                    img.thumbnail((max_dimension, max_dimension), Image.Resampling.LANCZOS)
                
                # Compress until under 512KB
                output = io.BytesIO()
                
                # Try PNG first
                img.save(output, format='PNG', optimize=True)
                output.seek(0)
                
                # If still too large, reduce quality and try again
                while len(output.getvalue()) > max_size and quality > 10:
                    output = io.BytesIO()
                    
                    # Convert to RGB for JPEG compression if needed
                    if img.mode == 'RGBA':
                        # Create white background
                        background = Image.new('RGB', img.size, (255, 255, 255))
                        background.paste(img, mask=img.split()[3] if len(img.split()) == 4 else None)
                        background.save(output, format='PNG', optimize=True, quality=quality)
                    else:
                        img.save(output, format='PNG', optimize=True, quality=quality)
                    
                    output.seek(0)
                    quality -= 10
                
                # If still too large, resize more aggressively
                if len(output.getvalue()) > max_size:
                    scale = 0.8
                    while len(output.getvalue()) > max_size and scale > 0.3:
                        new_width = int(img.width * scale)
                        new_height = int(img.height * scale)
                        resized = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                        
                        output = io.BytesIO()
                        resized.save(output, format='PNG', optimize=True)
                        output.seek(0)
                        scale -= 0.1
                
                final_size = len(output.getvalue())
                
                # Check if we managed to get under the limit
                if final_size > max_size:
                    await ctx .send (embed =discord .Embed (
                        title ="Steal",
                        description =f"Could not compress image under 512KB (current: {final_size//1000}KB)",
                        color =0x000000 
                    ))
                    return
                
                output.seek(0)
                
                emoji ="⭐"
                await ctx .guild .create_sticker (
                    name =sanitized_name ,
                    description ="Added by Lakshmi",
                    file =discord .File (output ,filename ="sticker.png"),
                    emoji =emoji 
                )
                
                size_kb = final_size // 1000
                await ctx .send (embed =discord .Embed (
                    title ="Steal",
                    description =f"Added sticker \"**{sanitized_name}**\"! (Size: {size_kb}KB)",
                    color =0x000000 
                ))
                
            except ImportError:
                # Fallback if PIL is not installed
                await ctx .send (embed =discord .Embed (
                    title ="Steal",
                    description ="PIL/Pillow not installed. Run: pip install Pillow",
                    color =0x000000 
                ))
                return
                
        except discord.HTTPException as e:
            # More specific error handling
            if e.code == 50046:
                await ctx .send (embed =discord .Embed (
                    title ="Steal",
                    description ="Invalid image format. Stickers must be PNG, APNG, or Lottie format.",
                    color =0x000000 
                ))
            else:
                await ctx .send (embed =discord .Embed (
                    title ="Steal",
                    description =f"Failed to add sticker: {str(e)}",
                    color =0x000000 
                ))
        except Exception as e :
            await ctx .send (embed =discord .Embed (
                title ="Steal",
                description =f"Failed to add sticker: {str(e)}",
                color =0x000000 
            ))

    def sanitize_name (self ,name ):
        sanitized =re .sub (r'[^a-zA-Z0-9_]','_',name )
        return sanitized [:32 ]

    def has_emoji_slot (self ,guild ,animated ):
        normal_emojis =[emoji for emoji in guild .emojis if not emoji .animated ]
        animated_emojis =[emoji for emoji in guild .emojis if emoji .animated ]
        max_normal ,max_animated =self .get_max_emoji_count (guild )

        if animated :
            return len (animated_emojis )<max_animated 
        else :
            return len (normal_emojis )<max_normal 

    def get_max_emoji_count (self ,guild ):
        if guild .premium_tier ==3 :
            return 250 ,250 
        elif guild .premium_tier ==2 :
            return 150 ,150 
        elif guild .premium_tier ==1 :
            return 100 ,100 
        else :
            return 50 ,50 

    def get_max_sticker_count (self ,guild ):
        if guild .premium_tier ==3 :
            return 60 
        elif guild .premium_tier ==2 :
            return 30 
        elif guild .premium_tier ==1 :
            return 15 
        else :
            return 5 

    async def create_buttons (self ,ctx ,attachments ,stickers ,emojis ):
        class StealView (discord.ui.View ):
            def __init__ (self ,bot ,ctx ,attachments ,stickers ,emojis ):
                super ().__init__ ()
                self .bot =bot 
                self .ctx =ctx 
                self .attachments =attachments 
                self .stickers =stickers 
                self .emojis =emojis 
                self .current_page =0
                self .total_items =len(attachments) + len(stickers) + len(emojis)
                
                # Add select menu
                select = discord.ui.Select(
                    placeholder="Choose an Option to proceed",
                    options=[
                        discord.SelectOption(
                            label="Add as Emoji",
                            value="emoji",
                            description="Add this item as a server emoji."
                        ),
                        discord.SelectOption(
                            label="Add as Sticker",
                            value="sticker",
                            description="Add this item as a server sticker."
                        ),
                        discord.SelectOption(
                            label="Add as Both",
                            value="both",
                            description="Add as both an emoji and a sticker."
                        ),
                        discord.SelectOption(
# © Trusty X Ayaan Development
                            label="Add all as Emojis",
                            value="all_emoji",
                            description="Add all items as server emojis."
                        ),
                        discord.SelectOption(
                            label="Add all as Stickers",
                            value="all_sticker",
                            description="Add all items as server stickers."
                        ),
                    ]
                )
                select.callback = self.select_callback
                self.add_item(select)
                
                # Add pagination buttons
                self.add_item(discord.ui.Button(
                    label="",
                    emoji="⏮️",
                    style=discord.ButtonStyle.secondary
                ))
                
                self.add_item(discord.ui.Button(
                    label="",
                    emoji="◀️",
                    style=discord.ButtonStyle.secondary
                ))
                
                self.add_item(discord.ui.Button(
                    label="",
                    emoji="▶️",
                    style=discord.ButtonStyle.secondary
                ))
                
                self.add_item(discord.ui.Button(
                    label="",
                    emoji="⏭️",
                    style=discord.ButtonStyle.secondary
                ))
                
                self.add_item(discord.ui.Button(
                    label="",
                    emoji="❌",
                    style=discord.ButtonStyle.danger
                ))
            
            async def get_embed(self):
                embed = discord.Embed(
                    title=f"Steal Emoji [{self.total_items}]",
                    description="> :ulta_babu:\n\n",
                    color=0x2f3136
                )
                
                # Get current item
                all_items = []
                for attachment in self.attachments:
                    all_items.append(("attachment", attachment))
                for sticker in self.stickers:
                    all_items.append(("sticker", sticker))
                for emote in self.emojis:
                    all_items.append(("emoji", emote))
                
                if self.current_page < len(all_items):
                    item_type, item = all_items[self.current_page]
                    
                    if item_type == "attachment":
                        embed.set_image(url=item.url)
                        embed.description = f"> {item.filename}\n\n"
                    elif item_type == "sticker":
                        embed.set_image(url=item.url)
                        embed.description = f"> {item.name}\n\n"
                    elif item_type == "emoji":
                        emoji_id = item.split(':')[2][:-1]
                        url = f"https://cdn.discordapp.com/emojis/{emoji_id}.png"
                        embed.set_image(url=url)
                        embed.description = f"> {item}\n\n"
                
                embed.set_footer(text=f"Requested By ! कृष / Krishx !!|Page {self.current_page + 1}/{self.total_items}")
                return embed
            
            async def select_callback(self, interaction: discord.Interaction):
                if interaction.user.id != self.ctx.author.id:
                    await interaction.response.send_message("This interaction is not for you.", ephemeral=True)
                    return
                
                await interaction.response.defer()
                
                choice = interaction.data.get('values', ['emoji'])[0]
                
                if choice == "emoji":
                    await self.steal_as_emoji_single()
                elif choice == "sticker":
                    await self.steal_as_sticker_single()
                elif choice == "both":
                    await self.steal_as_both_single()
                elif choice == "all_emoji":
                    await self.steal_all_as_emoji()
                elif choice == "all_sticker":
                    await self.steal_all_as_sticker()
            
            async def steal_as_emoji_single(self):
                all_items = []
                for attachment in self.attachments:
                    all_items.append(("attachment", attachment))
                for sticker in self.stickers:
                    all_items.append(("sticker", sticker))
                for emote in self.emojis:
                    all_items.append(("emoji", emote))
                
                if self.current_page < len(all_items):
                    item_type, item = all_items[self.current_page]
                    
                    if item_type == "attachment":
                        await self.bot.cogs['Steal'].add_emoji(self.ctx, item.url, item.filename.split('.')[0].replace(' ', '_'), animated=False)
                    elif item_type == "sticker":
                        if item.format in [discord.StickerFormatType.png, discord.StickerFormatType.apng, discord.StickerFormatType.lottie]:
                            animated = item.format == discord.StickerFormatType.apng
                            await self.bot.cogs['Steal'].add_emoji(self.ctx, item.url, item.name.replace(' ', '_'), animated=animated)
                    elif item_type == "emoji":
                        name = item.split(':')[1]
                        emoji_id = item.split(':')[2][:-1]
                        anim = item.split(':')[0]
                        if anim == '<a':
                            url = f'https://cdn.discordapp.com/emojis/{emoji_id}.gif'
                        else:
                            url = f'https://cdn.discordapp.com/emojis/{emoji_id}.png'
                        await self.bot.cogs['Steal'].add_emoji(self.ctx, url, name, animated=(anim == '<a'))
            
            async def steal_as_sticker_single(self):
                all_items = []
                for attachment in self.attachments:
                    all_items.append(("attachment", attachment))
                for sticker in self.stickers:
                    all_items.append(("sticker", sticker))
                for emote in self.emojis:
                    all_items.append(("emoji", emote))
                
                if self.current_page < len(all_items):
                    item_type, item = all_items[self.current_page]
                    
                    if item_type == "attachment":
                        await self.bot.cogs['Steal'].add_sticker(self.ctx, item.url, item.filename.split('.')[0])
                    elif item_type == "sticker":
                        await self.bot.cogs['Steal'].add_sticker(self.ctx, item.url, item.name)
                    elif item_type == "emoji":
                        name = item.split(':')[1]
                        emoji_id = item.split(':')[2][:-1]
                        anim = item.split(':')[0]
                        if anim == '<a':
                            url = f'https://cdn.discordapp.com/emojis/{emoji_id}.gif'
                        else:
                            url = f'https://cdn.discordapp.com/emojis/{emoji_id}.png'
                        await self.bot.cogs['Steal'].add_sticker(self.ctx, url, name)
            
            async def steal_as_both_single(self):
                await self.steal_as_emoji_single()
                await self.steal_as_sticker_single()
            
            async def steal_all_as_emoji(self):
                for sticker in self.stickers:
                    if sticker.format in [discord.StickerFormatType.png, discord.StickerFormatType.apng, discord.StickerFormatType.lottie]:
                        animated = sticker.format == discord.StickerFormatType.apng
                        await self.bot.cogs['Steal'].add_emoji(self.ctx, sticker.url, sticker.name.replace(' ', '_'), animated=animated)
                
                for attachment in self.attachments:
                    await self.bot.cogs['Steal'].add_emoji(self.ctx, attachment.url, attachment.filename.split('.')[0].replace(' ', '_'), animated=False)
                
                for emote in self.emojis:
                    name = emote.split(':')[1]
                    emoji_id = emote.split(':')[2][:-1]
                    anim = emote.split(':')[0]
                    if anim == '<a':
                        url = f'https://cdn.discordapp.com/emojis/{emoji_id}.gif'
                    else:
                        url = f'https://cdn.discordapp.com/emojis/{emoji_id}.png'
                    await self.bot.cogs['Steal'].add_emoji(self.ctx, url, name, animated=(anim == '<a'))
            
            async def steal_all_as_sticker(self):
                for sticker in self.stickers:
                    await self.bot.cogs['Steal'].add_sticker(self.ctx, sticker.url, sticker.name)
                
                for attachment in self.attachments:
                    await self.bot.cogs['Steal'].add_sticker(self.ctx, attachment.url, attachment.filename.split('.')[0])
                
                for emote in self.emojis:
                    name = emote.split(':')[1]
                    emoji_id = emote.split(':')[2][:-1]
                    anim = emote.split(':')[0]
                    if anim == '<a':
                        url = f'https://cdn.discordapp.com/emojis/{emoji_id}.gif'
                    else:
                        url = f'https://cdn.discordapp.com/emojis/{emoji_id}.png'
                    await self.bot.cogs['Steal'].add_sticker(self.ctx, url, name)
            
            async def interaction_check(self, interaction: discord.Interaction) -> bool:
                if interaction.user.id != self.ctx.author.id:
                    await interaction.response.send_message("This interaction is not for you.", ephemeral=True)
                    return False
                return True

        view = StealView(self.bot, ctx, attachments, stickers, emojis)
        
        # Set button callbacks
        buttons = [item for item in view.children if isinstance(item, discord.ui.Button)]
        if len(buttons) >= 5:
            buttons[0].callback = lambda i: self._button_first(view, i)
            buttons[1].callback = lambda i: self._button_prev(view, i)
            buttons[2].callback = lambda i: self._button_next(view, i)
            buttons[3].callback = lambda i: self._button_last(view, i)
            buttons[4].callback = lambda i: self._button_cancel(view, i)
        
        embed = await view.get_embed()
        await ctx.send(embed=embed, view=view)
    
    async def _button_first(self, view, interaction: discord.Interaction):
        if interaction.user.id != view.ctx.author.id:
            await interaction.response.send_message("This interaction is not for you.", ephemeral=True)
            return
        view.current_page = 0
        embed = await view.get_embed()
        await interaction.response.edit_message(embed=embed)
    
    async def _button_prev(self, view, interaction: discord.Interaction):
        if interaction.user.id != view.ctx.author.id:
            await interaction.response.send_message("This interaction is not for you.", ephemeral=True)
            return
        if view.current_page > 0:
            view.current_page -= 1
        embed = await view.get_embed()
        await interaction.response.edit_message(embed=embed)
    
    async def _button_next(self, view, interaction: discord.Interaction):
        if interaction.user.id != view.ctx.author.id:
            await interaction.response.send_message("This interaction is not for you.", ephemeral=True)
            return
        if view.current_page < view.total_items - 1:
            view.current_page += 1
        embed = await view.get_embed()
        await interaction.response.edit_message(embed=embed)
    
    async def _button_last(self, view, interaction: discord.Interaction):
        if interaction.user.id != view.ctx.author.id:
            await interaction.response.send_message("This interaction is not for you.", ephemeral=True)
            return
        view.current_page = view.total_items - 1
        embed = await view.get_embed()
        await interaction.response.edit_message(embed=embed)
    
    async def _button_cancel(self, view, interaction: discord.Interaction):
        if interaction.user.id != view.ctx.author.id:
            await interaction.response.send_message("This interaction is not for you.", ephemeral=True)
            return
        await interaction.response.defer()
        await interaction.message.delete()




"""
: ! Lakshmi !
# Trusty X Ayaan - discord.gg/ibadat
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""

