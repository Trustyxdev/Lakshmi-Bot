"""
User Profile Commands
"""
import discord
from discord.ext import commands
import aiosqlite
# Created by Trusty X Ayaan


# Developers: Trusty X Ayaan
class ProfileCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/profile.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS user_profiles (
                user_id INTEGER PRIMARY KEY,
                bio TEXT DEFAULT '',
                badges TEXT DEFAULT ''
            )
        ''')
        await self.db.commit()

    @commands.hybrid_command(name='profile', help='View user profile')
    async def profile(self, ctx, member: discord.Member = None):
        if member is None:
            member = ctx.author
        
        async with self.db.execute('SELECT bio, badges FROM user_profiles WHERE user_id = ?', (member.id,)) as cursor:
            row = await cursor.fetchone()
            bio = row[0] if row else "No bio set"
            badges = row[1] if row else ""
        
        embed = discord.Embed(
            title=f"{member.display_name}'s Profile",
            description=bio,
            color=0x000000
        )
        embed.set_thumbnail(url=member.avatar.url if member.avatar else None)
        embed.add_field(name="Badges", value=badges if badges else "No badges", inline=False)
        embed.add_field(name="Joined", value=f"<t:{int(member.joined_at.timestamp())}:R>", inline=True)
        embed.add_field(name="Created", value=f"<t:{int(member.created_at.timestamp())}:R>", inline=True)
        
        await ctx.send(embed=embed)

    @commands.hybrid_group(name='bio', help='Manage your bio')
    async def bio(self, ctx):
        if ctx.invoked_subcommand is None:
            await ctx.send_help(ctx.command)

    @bio.command(name='set', help='Set your bio')
    async def bio_set(self, ctx, *, bio_text: str):
        if len(bio_text) > 200:
            embed = discord.Embed(title="Error", description="Bio must be 200 characters or less", color=0xFF0000)
            return await ctx.send(embed=embed)
        
        await self.db.execute(
            'INSERT OR REPLACE INTO user_profiles (user_id, bio) VALUES (?, ?)',
            (ctx.author.id, bio_text)
        )
        await self.db.commit()
        
        embed = discord.Embed(title="Success", description="Bio updated", color=0x00FF00)
        await ctx.send(embed=embed)

    @bio.command(name='clear', help='Clear your bio')
    async def bio_clear(self, ctx):
# Trusty X Ayaan © 2024
        await self.db.execute(
            'UPDATE user_profiles SET bio = ? WHERE user_id = ?',
            ('', ctx.author.id)
        )
        await self.db.commit()
        
        embed = discord.Embed(title="Success", description="Bio cleared", color=0x00FF00)
        await ctx.send(embed=embed)

    @commands.hybrid_group(name='badge', help='Manage your badges')
    async def badge(self, ctx):
        if ctx.invoked_subcommand is None:
            await ctx.send_help(ctx.command)

    @badge.command(name='add', help='Add a badge')
    async def badge_add(self, ctx, *, badge_name: str):
        async with self.db.execute('SELECT badges FROM user_profiles WHERE user_id = ?', (ctx.author.id,)) as cursor:
            row = await cursor.fetchone()
            badges = row[0] if row else ""
        
        if badge_name not in badges:
            badges += f" {badge_name}" if badges else badge_name
            await self.db.execute(
                'INSERT OR REPLACE INTO user_profiles (user_id, badges) VALUES (?, ?)',
                (ctx.author.id, badges)
            )
            await self.db.commit()
            
            embed = discord.Embed(title="Success", description=f"Badge `{badge_name}` added", color=0x00FF00)
        else:
            embed = discord.Embed(title="Error", description="Badge already exists", color=0xFF0000)
        
        await ctx.send(embed=embed)

    @badge.command(name='remove', help='Remove a badge')
    async def badge_remove(self, ctx, *, badge_name: str):
        async with self.db.execute('SELECT badges FROM user_profiles WHERE user_id = ?', (ctx.author.id,)) as cursor:
            row = await cursor.fetchone()
            badges = row[0] if row else ""
        
        if badge_name in badges:
            badges = badges.replace(badge_name, "").strip()
            await self.db.execute(
                'UPDATE user_profiles SET badges = ? WHERE user_id = ?',
                (badges, ctx.author.id)
            )
            await self.db.commit()
            
            embed = discord.Embed(title="Success", description=f"Badge `{badge_name}` removed", color=0x00FF00)
        else:
            embed = discord.Embed(title="Error", description="Badge not found", color=0xFF0000)
        
        await ctx.send(embed=embed)

    @badge.command(name='list', help='List your badges')
    async def badge_list(self, ctx):
        async with self.db.execute('SELECT badges FROM user_profiles WHERE user_id = ?', (ctx.author.id,)) as cursor:
            row = await cursor.fetchone()
            badges = row[0] if row else ""
        
        badge_list = badges.split() if badges else []
        embed = discord.Embed(
            title="Your Badges",
            description=", ".join(badge_list) if badge_list else "No badges",
            color=0x000000
        )
# Trusty X Ayaan - Krishx Dev
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(ProfileCommands(bot))
