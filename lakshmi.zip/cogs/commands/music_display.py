# -*- coding: utf-8 -*-
"""
Music Player Display - Sidebar Music Player UI
Uses the same ui.TextDisplay system as help.py without colored embeds
"""
import discord
from discord import ui
from discord.ext import commands
import wavelink
from core import Context
from utils.Tools import getConfig
from utils.logger import logger
# Built by Trusty X Ayaan Dev


# Trusty X Ayaan - Krishx Dev
class MusicPlayerView(ui.LayoutView):
    """Music player display using TextDisplay components"""
    
    def __init__(self, ctx: Context, player: wavelink.Player):
        super().__init__(timeout=300.0)
        self.ctx = ctx
        self.player = player
        self.container = ui.Container(accent_color=None)
        self.add_item(self.container)
        self.setup_music_display()
    
    def _format_time(self, ms: int) -> str:
        """Format milliseconds to MM:SS"""
        seconds = ms // 1000
        minutes = seconds // 60
        seconds = seconds % 60
        return f"{minutes:02d}:{seconds:02d}"
    
    def setup_music_display(self):
        """Setup the music player display"""
        self.container.clear_items()
        
        if not self.player or not self.player.current:
            self.container.add_item(
                ui.TextDisplay("🎵 **Music Player**\n\nNo track currently playing")
            )
            return
        
        track = self.player.current
        
        # Header
        self.container.add_item(
            ui.TextDisplay("# 🎵 Now Playing")
        )
        
        # Track Title
        self.container.add_item(
            ui.TextDisplay(f"**[{track.title}]({track.uri})**")
        )
        
        # Track Info
# Dev: Trusty X Ayaan
        info_text = (
            f"• **Author:** {track.author}\n"
            f"• **Duration:** {self._format_time(track.length)}\n"
            f"• **Position:** {self._format_time(self.player.position)}"
        )
        self.container.add_item(ui.TextDisplay(info_text))
        
        # Progress Bar
        if track.length > 0:
            progress = int((self.player.position / track.length) * 20)
            bar = "█" * progress + "░" * (20 - progress)
            progress_text = f"`{bar}`\n`{self._format_time(self.player.position)} / {self._format_time(track.length)}`"
            self.container.add_item(ui.TextDisplay(progress_text))
        
        self.container.add_item(ui.Separator())
        
        # Queue Info
        queue_size = len(self.player.queue)
        queue_text = f"**Queue:** {queue_size} song{'s' if queue_size != 1 else ''} waiting"
        self.container.add_item(ui.TextDisplay(queue_text))
        
        # Player Status
        status = "⏸️ Paused" if self.player.is_paused() else "▶️ Playing"
        volume = f"🔊 Volume: {self.player.volume}%"
        status_text = f"{status} • {volume}"
        self.container.add_item(ui.TextDisplay(status_text))
        
        self.container.add_item(ui.Separator())
        
        # Control Instructions
        controls_text = (
            "**Controls:**\n"
            "`play <song>` • `pause` • `resume` • `skip` • `stop`\n"
            "`queue` • `volume <0-100>` • `loop <mode>`"
        )
        self.container.add_item(ui.TextDisplay(controls_text))


class MusicDisplay(commands.Cog):
    """Music display cog for sidebar music player"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="musicdisplay", aliases=["mdisplay", "mp"])
    async def music_display(self, ctx: Context):
        """Show music player in sidebar style"""
        vc: wavelink.Player = ctx.voice_client
        
        if not vc:
            return await ctx.send("❌ Bot is not connected to a voice channel!")
        
        view = MusicPlayerView(ctx, vc)
        await ctx.send(view=view)


async def setup(bot):
    await bot.add_cog(MusicDisplay(bot))
