"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
from discord.ext import commands
from utils.Tools import blacklist_check, ignore_check
# Built by Trusty X Ayaan Dev


# Trusty X Ayaan - Krishx Dev
class AutoReact(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/bot_database.db") as db:
            await db.execute(
                """CREATE TABLE IF NOT EXISTS auto_reactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER,
                    trigger TEXT,
                    emoji TEXT,
                    created_by INTEGER,
                    created_at TEXT,
                    UNIQUE(guild_id, trigger, emoji)
                )"""
            )
            await db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000
        )
        for key, value in kwargs.items():
            if value:
                embed.add_field(name=key, value=value, inline=False)
        return embed

    @commands.group(name="autoreact", invoke_without_command=True)
    @commands.has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def autoreact(self, ctx):
        """Manage auto-reactions"""
        await ctx.send_help(ctx.command)

    @autoreact.command(name="add")
    @commands.has_permissions(manage_messages=True)
    async def autoreact_add(self, ctx, trigger: str, emoji: str):
        """Add an auto-reaction"""
        try:
            # Validate emoji
            await ctx.message.add_reaction(emoji)
            await ctx.message.remove_reaction(emoji, ctx.me)
        except:
            embed = self.create_embed(
                "❌ Invalid Emoji",
                "Please provide a valid emoji."
            )
            return await ctx.reply(embed=embed)

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO auto_reactions 
                    (guild_id, trigger, emoji, created_by, created_at)
                    VALUES (?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, trigger.lower(), emoji, ctx.author.id)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Auto-Reaction Added",
                f"Trigger: `{trigger}`\nEmoji: {emoji}"
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to add auto-reaction: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @autoreact.command(name="remove")
    @commands.has_permissions(manage_messages=True)
    async def autoreact_remove(self, ctx, trigger: str, emoji: str = None):
        """Remove an auto-reaction"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                if emoji:
                    cursor = await db.execute(
                        "SELECT * FROM auto_reactions WHERE guild_id = ? AND trigger = ? AND emoji = ?",
                        (ctx.guild.id, trigger.lower(), emoji)
                    )
                else:
                    cursor = await db.execute(
                        "SELECT * FROM auto_reactions WHERE guild_id = ? AND trigger = ?",
                        (ctx.guild.id, trigger.lower())
                    )
                existing = await cursor.fetchone()

                if not existing:
                    embed = self.create_embed(
                        "❌ Not Found",
                        f"No auto-reaction found for trigger: `{trigger}`"
                    )
                    return await ctx.reply(embed=embed)

                if emoji:
                    await db.execute(
                        "DELETE FROM auto_reactions WHERE guild_id = ? AND trigger = ? AND emoji = ?",
                        (ctx.guild.id, trigger.lower(), emoji)
# © Trusty X Ayaan Development
                    )
                else:
                    await db.execute(
                        "DELETE FROM auto_reactions WHERE guild_id = ? AND trigger = ?",
                        (ctx.guild.id, trigger.lower())
                    )
                await db.commit()

            embed = self.create_embed(
                "✅ Auto-Reaction Removed",
                f"Removed auto-reaction for trigger: `{trigger}`"
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to remove auto-reaction: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @autoreact.command(name="list")
    @commands.has_permissions(manage_messages=True)
    async def autoreact_list(self, ctx):
        """List all auto-reactions"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    "SELECT * FROM auto_reactions WHERE guild_id = ? ORDER BY created_at DESC",
                    (ctx.guild.id,)
                )
                reactions = await cursor.fetchall()

            if not reactions:
                embed = self.create_embed(
                    "📋 Auto-Reactions",
                    "No auto-reactions configured."
                )
                return await ctx.reply(embed=embed)

            reaction_text = ""
            for idx, reaction in enumerate(reactions, 1):
                reaction_text += f"**{idx}.** Trigger: `{reaction['trigger']}` → {reaction['emoji']}\n"

            embed = self.create_embed(
                "📋 Auto-Reactions",
                reaction_text
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to fetch auto-reactions: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @autoreact.command(name="clear")
    @commands.has_permissions(manage_messages=True)
    async def autoreact_clear(self, ctx):
        """Clear all auto-reactions"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT COUNT(*) FROM auto_reactions WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                count = await cursor.fetchone()

                if count[0] == 0:
                    embed = self.create_embed(
                        "❌ No Reactions",
                        "There are no auto-reactions to clear."
                    )
                    return await ctx.reply(embed=embed)

                await db.execute(
                    "DELETE FROM auto_reactions WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Auto-Reactions Cleared",
                f"Removed **{count[0]}** auto-reactions."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to clear auto-reactions: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    "SELECT * FROM auto_reactions WHERE guild_id = ?",
                    (message.guild.id,)
                )
                reactions = await cursor.fetchall()

                for reaction in reactions:
                    trigger = reaction['trigger']
                    if trigger in message.content.lower():
                        try:
                            await message.add_reaction(reaction['emoji'])
                        except:
                            pass
        except:
# Made by Trusty X Ayaan Dev
            pass


async def setup(bot):
    await bot.add_cog(AutoReact(bot))
