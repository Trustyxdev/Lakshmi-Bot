"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
from discord.ext import commands
import aiosqlite
# Dev: Trusty X Ayaan


# © Trusty X Ayaan Development
class TempVC(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/tempvc.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS tempvc_config (
                guild_id INTEGER PRIMARY KEY,
                enabled BOOLEAN DEFAULT 0,
                creator_channel_id INTEGER
            )
        ''')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS tempvc_channels (
                channel_id INTEGER PRIMARY KEY,
                owner_id INTEGER,
                guild_id INTEGER,
                locked BOOLEAN DEFAULT 0,
                hidden BOOLEAN DEFAULT 0,
                user_limit INTEGER DEFAULT 0
            )
        ''')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS tempvc_trusted (
                channel_id INTEGER,
                user_id INTEGER,
                PRIMARY KEY (channel_id, user_id)
            )
        ''')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS tempvc_banned (
                channel_id INTEGER,
                user_id INTEGER,
                PRIMARY KEY (channel_id, user_id)
            )
        ''')
        await self.db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000,
            **kwargs
        )
        return embed

    @commands.hybrid_group(name='tempvc', help='Manage temporary voice channels')
    async def tempvc(self, ctx):
        if ctx.invoked_subcommand is None:
            embed = self.create_embed(
                title="Temp VC",
                description="Use subcommands to manage temporary voice channels"
            )
            await ctx.send(embed=embed)

    @tempvc.command(name='claim', help='Claim a temp VC')
    async def tempvc_claim(self, ctx):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        async with self.db.execute('SELECT owner_id FROM tempvc_channels WHERE channel_id = ?', (channel_id,)) as cursor:
            row = await cursor.fetchone()
        
        if row:
            await self.db.execute(
                'UPDATE tempvc_channels SET owner_id = ? WHERE channel_id = ?',
                (ctx.author.id, channel_id)
            )
            await self.db.commit()
            embed = self.create_embed(title="Success", description="Channel claimed")
        else:
            embed = self.create_embed(title="Error", description="This is not a temp VC")
        
        await ctx.send(embed=embed)

    @tempvc.command(name='unlock', help='Unlock temp VC')
    async def tempvc_unlock(self, ctx):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        await self.db.execute(
            'UPDATE tempvc_channels SET locked = ? WHERE channel_id = ?',
            (False, channel_id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Channel unlocked")
        await ctx.send(embed=embed)

    @tempvc.command(name='lock', help='Lock temp VC')
    async def tempvc_lock(self, ctx):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        await self.db.execute(
            'UPDATE tempvc_channels SET locked = ? WHERE channel_id = ?',
            (True, channel_id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Channel locked")
        await ctx.send(embed=embed)

    @tempvc.command(name='trust', help='Trust a user in temp VC')
    async def tempvc_trust(self, ctx, user: discord.User):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        await self.db.execute(
            'INSERT OR REPLACE INTO tempvc_trusted (channel_id, user_id) VALUES (?, ?)',
            (channel_id, user.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"{user.mention} is now trusted")
        await ctx.send(embed=embed)

    @tempvc.command(name='untrust', help='Untrust a user in temp VC')
    async def tempvc_untrust(self, ctx, user: discord.User):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        await self.db.execute(
            'DELETE FROM tempvc_trusted WHERE channel_id = ? AND user_id = ?',
# Trusty X Ayaan © 2024
            (channel_id, user.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"{user.mention} is no longer trusted")
        await ctx.send(embed=embed)

    @tempvc.command(name='ban', help='Ban a user from temp VC')
    async def tempvc_ban(self, ctx, user: discord.User):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        await self.db.execute(
            'INSERT OR REPLACE INTO tempvc_banned (channel_id, user_id) VALUES (?, ?)',
            (channel_id, user.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"{user.mention} is banned")
        await ctx.send(embed=embed)

    @tempvc.command(name='unban', help='Unban a user from temp VC')
    async def tempvc_unban(self, ctx, user: discord.User):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        await self.db.execute(
            'DELETE FROM tempvc_banned WHERE channel_id = ? AND user_id = ?',
            (channel_id, user.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"{user.mention} is unbanned")
        await ctx.send(embed=embed)

    @tempvc.command(name='name', help='Rename temp VC')
    async def tempvc_name(self, ctx, *, name: str):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel = ctx.author.voice.channel
        await channel.edit(name=name)
        
        embed = self.create_embed(title="Success", description=f"Channel renamed to {name}")
        await ctx.send(embed=embed)

    @tempvc.command(name='limit', help='Set user limit for temp VC')
    async def tempvc_limit(self, ctx, limit: int):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        await self.db.execute(
            'UPDATE tempvc_channels SET user_limit = ? WHERE channel_id = ?',
            (limit, channel_id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"User limit set to {limit}")
        await ctx.send(embed=embed)

    @tempvc.command(name='hide', help='Hide temp VC')
    async def tempvc_hide(self, ctx):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        await self.db.execute(
            'UPDATE tempvc_channels SET hidden = ? WHERE channel_id = ?',
            (True, channel_id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Channel hidden")
        await ctx.send(embed=embed)

    @tempvc.command(name='unhide', help='Unhide temp VC')
    async def tempvc_unhide(self, ctx):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        await self.db.execute(
            'UPDATE tempvc_channels SET hidden = ? WHERE channel_id = ?',
            (False, channel_id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Channel unhidden")
        await ctx.send(embed=embed)

    @tempvc.command(name='kick', help='Kick a user from temp VC')
    async def tempvc_kick(self, ctx, user: discord.User):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel = ctx.author.voice.channel
        member = ctx.guild.get_member(user.id)
        if member and member.voice:
            await member.move_to(None)
        
        embed = self.create_embed(title="Success", description=f"{user.mention} kicked")
        await ctx.send(embed=embed)

    @tempvc.command(name='transfer', help='Transfer temp VC ownership')
    async def tempvc_transfer(self, ctx, user: discord.User):
        if not isinstance(ctx.author.voice, discord.VoiceState) or not ctx.author.voice.channel:
            embed = self.create_embed(title="Error", description="You must be in a voice channel")
            return await ctx.send(embed=embed)
        
        channel_id = ctx.author.voice.channel.id
        await self.db.execute(
            'UPDATE tempvc_channels SET owner_id = ? WHERE channel_id = ?',
            (user.id, channel_id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"Ownership transferred to {user.mention}")
        await ctx.send(embed=embed)

    @tempvc.command(name='config', help='Configure temp VC')
    async def tempvc_config(self, ctx):
        embed = self.create_embed(
            title="Temp VC Config",
            description="Use subcommands to configure temp VC"
        )
        await ctx.send(embed=embed)

    @tempvc.command(name='lobby', help='Set temp VC lobby')
    async def tempvc_lobby(self, ctx, channel: discord.VoiceChannel):
        await self.db.execute(
            'INSERT OR REPLACE INTO tempvc_config (guild_id, creator_channel_id) VALUES (?, ?)',
            (ctx.guild.id, channel.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"Lobby set to {channel.mention}")
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(TempVC(bot))
