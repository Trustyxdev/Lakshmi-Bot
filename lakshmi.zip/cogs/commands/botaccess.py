"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
from discord.ext import commands
from discord import ui
from core import Cog, Context
from utils.Tools import *
# Trusty X Ayaan - discord.gg/ibadat


# Developers: Trusty X Ayaan
class BotAccess(Cog):
    """Control bot access for normal and premium users"""

    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        """Setup bot access control database"""
        async with aiosqlite.connect('db/bot_database.db') as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS bot_access (
                    guild_id INTEGER PRIMARY KEY,
                    normal_users_blocked INTEGER DEFAULT 0,
                    premium_users_blocked INTEGER DEFAULT 0
                )
            """)
            await db.commit()

    async def is_access_allowed(self, ctx: Context) -> tuple[bool, str]:
        """
        Check if user has access to use bot
        Returns: (allowed: bool, reason: str)
        """
        # Owner always has access
        if ctx.author.id in [1414058403202072688, 1442939274982068335]:
            return True, "Owner bypass"

        # Check if guild has access restrictions
        async with aiosqlite.connect('db/bot_database.db') as db:
            cursor = await db.execute(
                "SELECT normal_users_blocked, premium_users_blocked FROM bot_access WHERE guild_id = ?",
                (ctx.guild.id,)
            )
            row = await cursor.fetchone()

            if not row:
                # No restrictions set
                return True, "No restrictions"

            normal_blocked, premium_blocked = row

            # Check if user is premium
            is_premium = False
            try:
                async with aiosqlite.connect('db/premium.db') as pdb:
                    pcursor = await pdb.execute(
                        "SELECT user_id FROM premium_users WHERE user_id = ?",
                        (ctx.author.id,)
                    )
                    prow = await pcursor.fetchone()
                    is_premium = prow is not None
            except:
                pass

            # Check access based on user type
            if is_premium:
                if premium_blocked:
                    return False, "Premium users are blocked from using this bot in this server"
                return True, "Premium user access"
            else:
                if normal_blocked:
                    return False, "Normal users are blocked from using this bot in this server"
                return True, "Normal user access"

    @commands.group(name="botaccess", aliases=["baccess", "ba"], invoke_without_command=True)
    @commands.is_owner()  # Only bot owner can use this
    @blacklist_check()
    @ignore_check()
    async def botaccess(self, ctx: Context):
        """Control bot access for normal and premium users"""
        if ctx.invoked_subcommand is None:
            # Show current status
            async with aiosqlite.connect('db/bot_database.db') as db:
                cursor = await db.execute(
                    "SELECT normal_users_blocked, premium_users_blocked FROM bot_access WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                row = await cursor.fetchone()

                if row:
                    normal_blocked, premium_blocked = row
                else:
                    normal_blocked, premium_blocked = 0, 0

            # Create status embed
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay("# Bot Access Control"))
            container.add_item(ui.Separator())
            
            normal_status = "🔴 Blocked" if normal_blocked else "🟢 Allowed"
            premium_status = "🔴 Blocked" if premium_blocked else "🟢 Allowed"
            
            container.add_item(ui.TextDisplay(
                f"**Normal Users:** {normal_status}\n"
                f"**Premium Users:** {premium_status}\n\n"
                f"**Note:** Owners always have access"
            ))
            container.add_item(ui.Separator())
            container.add_item(ui.TextDisplay(
                "**Commands:**\n"
                f"`{ctx.prefix}botaccess block normal` - Block normal users\n"
                f"`{ctx.prefix}botaccess unblock normal` - Unblock normal users\n"
                f"`{ctx.prefix}botaccess block premium` - Block premium users\n"
                f"`{ctx.prefix}botaccess unblock premium` - Unblock premium users"
            ))

            view = ui.LayoutView()
            view.add_item(container)
            await ctx.reply(view=view)

    @botaccess.command(name="block")
    @commands.is_owner()  # Only bot owner
    @blacklist_check()
    @ignore_check()
    async def botaccess_block(self, ctx: Context, user_type: str):
        """Block normal or premium users from using the bot
        
        Usage: botaccess block <normal|premium>
        """
        user_type = user_type.lower()
        
        if user_type not in ["normal", "premium"]:
            return await ctx.reply("❌ Invalid user type! Use `normal` or `premium`")

        async with aiosqlite.connect('db/bot_database.db') as db:
            if user_type == "normal":
                await db.execute(
                    "INSERT OR REPLACE INTO bot_access (guild_id, normal_users_blocked, premium_users_blocked) "
                    "VALUES (?, 1, COALESCE((SELECT premium_users_blocked FROM bot_access WHERE guild_id = ?), 0))",
                    (ctx.guild.id, ctx.guild.id)
                )
            else:  # premium
                await db.execute(
                    "INSERT OR REPLACE INTO bot_access (guild_id, normal_users_blocked, premium_users_blocked) "
                    "VALUES (?, COALESCE((SELECT normal_users_blocked FROM bot_access WHERE guild_id = ?), 0), 1)",
                    (ctx.guild.id, ctx.guild.id)
                )
            await db.commit()

        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"# 🔴 Access Blocked"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(
            f"**{user_type.capitalize()} users** are now blocked from using this bot\n\n"
            f"**Note:** Owners can still use all commands"
        ))

        view = ui.LayoutView()
        view.add_item(container)
        await ctx.reply(view=view)

    @botaccess.command(name="unblock")
    @commands.is_owner()  # Only bot owner
    @blacklist_check()
    @ignore_check()
    async def botaccess_unblock(self, ctx: Context, user_type: str):
        """Unblock normal or premium users from using the bot
        
        Usage: botaccess unblock <normal|premium>
        """
        user_type = user_type.lower()
        
        if user_type not in ["normal", "premium"]:
            return await ctx.reply("❌ Invalid user type! Use `normal` or `premium`")

        async with aiosqlite.connect('db/bot_database.db') as db:
            if user_type == "normal":
                await db.execute(
                    "INSERT OR REPLACE INTO bot_access (guild_id, normal_users_blocked, premium_users_blocked) "
                    "VALUES (?, 0, COALESCE((SELECT premium_users_blocked FROM bot_access WHERE guild_id = ?), 0))",
                    (ctx.guild.id, ctx.guild.id)
                )
            else:  # premium
                await db.execute(
                    "INSERT OR REPLACE INTO bot_access (guild_id, normal_users_blocked, premium_users_blocked) "
                    "VALUES (?, COALESCE((SELECT normal_users_blocked FROM bot_access WHERE guild_id = ?), 0), 0)",
                    (ctx.guild.id, ctx.guild.id)
                )
            await db.commit()

        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"# 🟢 Access Restored"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(
            f"**{user_type.capitalize()} users** can now use this bot again"
        ))

        view = ui.LayoutView()
        view.add_item(container)
        await ctx.reply(view=view)

    def help_custom(self):
# Code by Trusty X Ayaan
        return ("🔐", "Bot Access", "Control bot access for different user types")


async def setup(bot):
    await bot.add_cog(BotAccess(bot))
