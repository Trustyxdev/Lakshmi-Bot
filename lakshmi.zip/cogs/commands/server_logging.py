"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
from discord.ext import commands
from typing import Union
import aiosqlite
# Created by Trusty X Ayaan


# © Trusty X Ayaan Development
class Logging(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/logging.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS logging_config (
                guild_id INTEGER PRIMARY KEY,
                enabled BOOLEAN DEFAULT 0,
                log_channel_id INTEGER,
                ignored_channels TEXT DEFAULT '',
                ignored_users TEXT DEFAULT ''
            )
        ''')
        await self.db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000,
            **kwargs
        )
        return embed

    @commands.hybrid_group(name='logging', help='Manage server logging')
    @commands.has_permissions(administrator=True)
    async def logging(self, ctx):
        if ctx.invoked_subcommand is None:
            async with self.db.execute('SELECT enabled, log_channel_id FROM logging_config WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                row = await cursor.fetchone()
            
            if row:
                enabled = row[0]
                channel = ctx.guild.get_channel(row[1]) if row[1] else None
                embed = self.create_embed(
                    title="Logging Status",
                    description=f"Status: {'Enabled' if enabled else 'Disabled'}\nChannel: {channel.mention if channel else 'Not set'}"
                )
            else:
                embed = self.create_embed(title="Logging Status", description="Logging not configured")
            
            await ctx.send(embed=embed)

    @logging.command(name='enable', help='Enable logging')
    @commands.has_permissions(administrator=True)
    async def logging_enable(self, ctx, channel: discord.TextChannel):
        await self.db.execute(
            'INSERT OR REPLACE INTO logging_config (guild_id, enabled, log_channel_id) VALUES (?, ?, ?)',
            (ctx.guild.id, True, channel.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(
            title="Success",
            description=f"Logging enabled in {channel.mention}"
        )
        await ctx.send(embed=embed)

    @logging.command(name='disable', help='Disable logging')
    @commands.has_permissions(administrator=True)
    async def logging_disable(self, ctx):
        await self.db.execute(
            'UPDATE logging_config SET enabled = ? WHERE guild_id = ?',
            (False, ctx.guild.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Logging disabled")
        await ctx.send(embed=embed)

    @logging.group(name='ignore', help='Ignore channels or users from logging')
    @commands.has_permissions(administrator=True)
    async def logging_ignore(self, ctx):
        if ctx.invoked_subcommand is None:
            await ctx.send_help(ctx.command)

    @logging_ignore.command(name='channel', help='Ignore a channel')
    @commands.has_permissions(administrator=True)
    async def logging_ignore_channel(self, ctx, channel: discord.TextChannel):
        async with self.db.execute('SELECT ignored_channels FROM logging_config WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            row = await cursor.fetchone()
        
        ignored_channels = row[0].split(',') if row and row[0] else []
        
        if str(channel.id) not in ignored_channels:
            ignored_channels.append(str(channel.id))
        
        await self.db.execute(
            'INSERT OR REPLACE INTO logging_config (guild_id, ignored_channels) VALUES (?, ?)',
            (ctx.guild.id, ','.join(ignored_channels))
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"Ignored channel {channel.mention}")
        await ctx.send(embed=embed)

    @logging_ignore.command(name='user', help='Ignore a user')
    @commands.has_permissions(administrator=True)
    async def logging_ignore_user(self, ctx, user: discord.User):
        async with self.db.execute('SELECT ignored_users FROM logging_config WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            row = await cursor.fetchone()
        
        ignored_users = row[0].split(',') if row and row[0] else []
        
        if str(user.id) not in ignored_users:
            ignored_users.append(str(user.id))
        
        await self.db.execute(
            'INSERT OR REPLACE INTO logging_config (guild_id, ignored_users) VALUES (?, ?)',
            (ctx.guild.id, ','.join(ignored_users))
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"Ignored user {user.mention}")
        await ctx.send(embed=embed)

    @logging.command(name='status', help='Show logging status')
    @commands.has_permissions(administrator=True)
    async def logging_status(self, ctx):
        async with self.db.execute('SELECT enabled, log_channel_id, ignored_channels, ignored_users FROM logging_config WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            row = await cursor.fetchone()
        
        if row:
            enabled, channel_id, ignored_ch, ignored_u = row
            channel = ctx.guild.get_channel(channel_id) if channel_id else None
            
            embed = self.create_embed(
                title="Logging Status",
                description=f"Status: {'Enabled' if enabled else 'Disabled'}\nChannel: {channel.mention if channel else 'Not set'}"
            )
            
            if ignored_ch:
                embed.add_field(name="Ignored Channels", value=ignored_ch, inline=False)
            if ignored_u:
                embed.add_field(name="Ignored Users", value=ignored_u, inline=False)
        else:
            embed = self.create_embed(title="Logging Status", description="Logging not configured")
        
        await ctx.send(embed=embed)

    @logging.command(name='setup', help='Setup logging wizard')
    @commands.has_permissions(administrator=True)
    async def logging_setup(self, ctx):
        embed = self.create_embed(
            title="Logging Setup",
            description="Please mention the channel where logs should be sent"
        )
        await ctx.send(embed=embed)

    @logging.command(name='wizard', help='Interactive logging setup')
    @commands.has_permissions(administrator=True)
    async def logging_wizard(self, ctx):
        embed = self.create_embed(
            title="Logging Wizard",
            description="Starting interactive setup...\nPlease mention the log channel"
        )
# Built by Trusty X Ayaan Dev
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Logging(bot))
