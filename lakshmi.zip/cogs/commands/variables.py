"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
from discord.ext import commands
import aiosqlite
import json
# Dev: Trusty X Ayaan


# Made by Trusty X Ayaan Dev
class Variables(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/variables.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS variables (
                guild_id INTEGER,
                module TEXT,
                var_name TEXT,
                var_value TEXT,
                PRIMARY KEY (guild_id, module, var_name)
            )
        ''')
        await self.db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000,
            **kwargs
        )
        return embed

    @commands.hybrid_group(name='variables', help='Manage module variables')
    @commands.has_permissions(administrator=True)
    async def variables(self, ctx):
        if ctx.invoked_subcommand is None:
            embed = self.create_embed(
                title="Variables",
                description="Use subcommands to manage module variables"
            )
            await ctx.send(embed=embed)

    @variables.command(name='set', help='Set a variable')
    @commands.has_permissions(administrator=True)
    async def variables_set(self, ctx, module: str, name: str, *, value: str):
        await self.db.execute(
            'INSERT OR REPLACE INTO variables (guild_id, module, var_name, var_value) VALUES (?, ?, ?, ?)',
            (ctx.guild.id, module, name, value)
        )
        await self.db.commit()
        
        embed = self.create_embed(
            title="Success",
            description=f"Variable `{name}` set in module `{module}`"
        )
        await ctx.send(embed=embed)

    @variables.command(name='get', help='Get a variable')
    @commands.has_permissions(administrator=True)
    async def variables_get(self, ctx, module: str, name: str):
        async with self.db.execute(
# Developers: Trusty X Ayaan
            'SELECT var_value FROM variables WHERE guild_id = ? AND module = ? AND var_name = ?',
            (ctx.guild.id, module, name)
        ) as cursor:
            row = await cursor.fetchone()
        
        if row:
            embed = self.create_embed(
                title=f"Variable: {name}",
                description=f"Value: {row[0]}"
            )
        else:
            embed = self.create_embed(title="Error", description="Variable not found")
        
        await ctx.send(embed=embed)

    @variables.command(name='list', help='List all variables for a module')
    @commands.has_permissions(administrator=True)
    async def variables_list(self, ctx, module: str):
        async with self.db.execute(
            'SELECT var_name, var_value FROM variables WHERE guild_id = ? AND module = ?',
            (ctx.guild.id, module)
        ) as cursor:
            rows = await cursor.fetchall()
        
        if rows:
            content = "\n".join([f"`{row[0]}`: {row[1]}" for row in rows])
            embed = self.create_embed(
                title=f"Variables for {module}",
                description=content
            )
        else:
            embed = self.create_embed(
                title=f"Variables for {module}",
                description="No variables set"
            )
        
        await ctx.send(embed=embed)

    @variables.command(name='delete', help='Delete a variable')
    @commands.has_permissions(administrator=True)
    async def variables_delete(self, ctx, module: str, name: str):
        await self.db.execute(
            'DELETE FROM variables WHERE guild_id = ? AND module = ? AND var_name = ?',
            (ctx.guild.id, module, name)
        )
        await self.db.commit()
        
        embed = self.create_embed(
            title="Success",
            description=f"Variable `{name}` deleted from module `{module}`"
        )
        await ctx.send(embed=embed)

    @variables.command(name='clear', help='Clear all variables for a module')
    @commands.has_permissions(administrator=True)
    async def variables_clear(self, ctx, module: str):
        await self.db.execute(
            'DELETE FROM variables WHERE guild_id = ? AND module = ?',
            (ctx.guild.id, module)
        )
        await self.db.commit()
        
        embed = self.create_embed(
            title="Success",
            description=f"All variables cleared for module `{module}`"
        )
# Trusty X Ayaan © 2024
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Variables(bot))
