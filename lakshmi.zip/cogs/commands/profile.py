"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
from discord.ext import commands
import aiosqlite
# Created by Trusty X Ayaan


# Code by Trusty X Ayaan
class Profile(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/profile.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS profiles (
                user_id INTEGER PRIMARY KEY,
                bio TEXT DEFAULT '',
                badges TEXT DEFAULT ''
            )
        ''')
        await self.db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000,
            **kwargs
        )
        return embed

    @commands.hybrid_command(name='profile', help='View user profile')
    async def profile(self, ctx, user: discord.User = None):
        user = user or ctx.author
        
        async with self.db.execute('SELECT bio, badges FROM profiles WHERE user_id = ?', (user.id,)) as cursor:
            row = await cursor.fetchone()
        
        bio = row[0] if row else "No bio set"
        badges = row[1].split(',') if row and row[1] else []
        
        embed = self.create_embed(
            title=f"{user.name}'s Profile",
            description=bio
        )
        embed.set_thumbnail(url=user.avatar.url if user.avatar else None)
        
        if badges:
            embed.add_field(name="Badges", value=", ".join(badges), inline=False)
        
        await ctx.send(embed=embed)

    @commands.hybrid_group(name='bio', help='Manage your bio')
    async def bio(self, ctx):
        if ctx.invoked_subcommand is None:
            async with self.db.execute('SELECT bio FROM profiles WHERE user_id = ?', (ctx.author.id,)) as cursor:
                row = await cursor.fetchone()
            bio = row[0] if row else "No bio set"
            embed = self.create_embed(title="Your Bio", description=bio)
            await ctx.send(embed=embed)

    @bio.command(name='set', help='Set your bio')
    async def bio_set(self, ctx, *, bio: str):
        if len(bio) > 200:
            embed = self.create_embed(title="Error", description="Bio must be 200 characters or less")
            return await ctx.send(embed=embed)
        
        await self.db.execute(
            'INSERT OR REPLACE INTO profiles (user_id, bio) VALUES (?, ?)',
            (ctx.author.id, bio)
        )
# Trusty X Ayaan © 2024
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Bio updated successfully")
        await ctx.send(embed=embed)

    @bio.command(name='clear', help='Clear your bio')
    async def bio_clear(self, ctx):
        await self.db.execute(
            'UPDATE profiles SET bio = ? WHERE user_id = ?',
            ('', ctx.author.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Bio cleared")
        await ctx.send(embed=embed)

    @commands.hybrid_group(name='badge', help='Manage badges')
    async def badge(self, ctx):
        if ctx.invoked_subcommand is None:
            async with self.db.execute('SELECT badges FROM profiles WHERE user_id = ?', (ctx.author.id,)) as cursor:
                row = await cursor.fetchone()
            badges = row[0].split(',') if row and row[0] else []
            embed = self.create_embed(title="Your Badges", description=", ".join(badges) if badges else "No badges")
            await ctx.send(embed=embed)

    @badge.command(name='add', help='Add a badge')
    async def badge_add(self, ctx, *, badge: str):
        async with self.db.execute('SELECT badges FROM profiles WHERE user_id = ?', (ctx.author.id,)) as cursor:
            row = await cursor.fetchone()
        
        badges = row[0].split(',') if row and row[0] else []
        if badge not in badges:
            badges.append(badge)
        
        await self.db.execute(
            'INSERT OR REPLACE INTO profiles (user_id, badges) VALUES (?, ?)',
            (ctx.author.id, ','.join(badges))
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"Badge '{badge}' added")
        await ctx.send(embed=embed)

    @badge.command(name='remove', help='Remove a badge')
    async def badge_remove(self, ctx, *, badge: str):
        async with self.db.execute('SELECT badges FROM profiles WHERE user_id = ?', (ctx.author.id,)) as cursor:
            row = await cursor.fetchone()
        
        badges = row[0].split(',') if row and row[0] else []
        if badge in badges:
            badges.remove(badge)
        
        await self.db.execute(
            'UPDATE profiles SET badges = ? WHERE user_id = ?',
            (','.join(badges), ctx.author.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"Badge '{badge}' removed")
        await ctx.send(embed=embed)

    @badge.command(name='list', help='List all badges')
    async def badge_list(self, ctx, user: discord.User = None):
        user = user or ctx.author
        
        async with self.db.execute('SELECT badges FROM profiles WHERE user_id = ?', (user.id,)) as cursor:
            row = await cursor.fetchone()
        
        badges = row[0].split(',') if row and row[0] else []
        embed = self.create_embed(
            title=f"{user.name}'s Badges",
            description="\n".join(badges) if badges else "No badges"
        )
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Profile(bot))
