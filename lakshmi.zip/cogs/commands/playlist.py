"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
import asyncio
from discord.ext import commands
from discord import ui
from core import Cog, Context
from utils.Tools import *
# Built by Trusty X Ayaan Dev


# Made by Trusty X Ayaan Dev
class PlaylistView(ui.View):
    """View for playlist management"""
    
    def __init__(self, cog, ctx, playlists: list):
        super().__init__(timeout=300)
        self.cog = cog
        self.ctx = ctx
        self.playlists = playlists
        self.page = 0
        self.per_page = 5
        self.max_pages = (len(playlists) - 1) // self.per_page + 1 if playlists else 1
        
        self.update_buttons()
    
    def update_buttons(self):
        """Update button states"""
        self.prev_button.disabled = (self.page == 0)
        self.next_button.disabled = (self.page >= self.max_pages - 1) or not self.playlists
    
    def get_current_playlists(self):
        """Get playlists for current page"""
        start = self.page * self.per_page
        end = start + self.per_page
        return self.playlists[start:end]
    
    def create_layout_view(self) -> ui.LayoutView:
        """Create LayoutView for playlists"""
        layout_view = ui.LayoutView(timeout=300)
        container = ui.Container(accent_color=None)
        
        container.add_item(ui.TextDisplay("# 🎵 Your Playlists"))
        container.add_item(ui.Separator())
        
        if not self.playlists:
            container.add_item(ui.TextDisplay("You don't have any playlists yet!\n\nCreate one with `.playlist create <name>`"))
        else:
            container.add_item(ui.TextDisplay(f"Page {self.page + 1}/{self.max_pages}"))
            container.add_item(ui.Separator())
            
            current_playlists = self.get_current_playlists()
            playlists_text = ""
            
            for i, (playlist_id, name, song_count, created_at) in enumerate(current_playlists, start=1):
                num = (self.page * self.per_page) + i
                playlists_text += f"**{num}.** {name}\n> **Songs:** {song_count} • **ID:** `{playlist_id}`\n\n"
            
            container.add_item(ui.TextDisplay(playlists_text.strip()))
        
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay("Lakshmi Music"))
        
        layout_view.add_item(container)
        return layout_view
    
    @discord.ui.button(label="◀ Previous", style=discord.ButtonStyle.secondary, row=0)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Only you can navigate!", ephemeral=True)
        
        self.page = max(0, self.page - 1)
        self.update_buttons()
        
        layout_view = self.create_layout_view()
        layout_view.add_item(ui.ActionRow(self.prev_button, self.next_button))
        
        await interaction.response.edit_message(view=layout_view)
    
    @discord.ui.button(label="Next ▶", style=discord.ButtonStyle.secondary, row=0)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Only you can navigate!", ephemeral=True)
        
        self.page = min(self.max_pages - 1, self.page + 1)
        self.update_buttons()
        
        layout_view = self.create_layout_view()
        layout_view.add_item(ui.ActionRow(self.prev_button, self.next_button))
        
        await interaction.response.edit_message(view=layout_view)


class Playlist(Cog):
    """Spotify-like playlist system for music"""

    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        """Setup playlist database"""
        async with aiosqlite.connect('db/playlists.db') as db:
            # Playlists table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS playlists (
                    playlist_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    name TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Playlist songs table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS playlist_songs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    playlist_id INTEGER NOT NULL,
                    song_title TEXT NOT NULL,
                    song_url TEXT NOT NULL,
                    artist TEXT,
                    duration INTEGER,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (playlist_id) REFERENCES playlists(playlist_id) ON DELETE CASCADE
                )
            """)
            
            await db.commit()

    @commands.group(name="playlist", aliases=["pl"], invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    async def playlist(self, ctx: Context):
        """Manage your music playlists"""
        if ctx.invoked_subcommand is None:
            # Show user's playlists
            async with aiosqlite.connect('db/playlists.db') as db:
                cursor = await db.execute("""
                    SELECT p.playlist_id, p.name, COUNT(ps.id) as song_count, p.created_at
                    FROM playlists p
                    LEFT JOIN playlist_songs ps ON p.playlist_id = ps.playlist_id
                    WHERE p.user_id = ?
                    GROUP BY p.playlist_id
                    ORDER BY p.created_at DESC
                """, (ctx.author.id,))
                playlists = await cursor.fetchall()
            
            view = PlaylistView(self, ctx, playlists)
            layout_view = view.create_layout_view()
            
            if playlists:
                layout_view.add_item(ui.ActionRow(view.prev_button, view.next_button))
            
            await ctx.reply(view=layout_view)

    @playlist.command(name="create")
    @blacklist_check()
    @ignore_check()
    async def playlist_create(self, ctx: Context, *, name: str):
        """Create a new playlist
        
        Usage: .playlist create <name>
        """
        if len(name) > 50:
            return await ctx.reply("❌ Playlist name must be 50 characters or less!")
        
        # Check if user already has a playlist with this name
        async with aiosqlite.connect('db/playlists.db') as db:
            cursor = await db.execute(
                "SELECT playlist_id FROM playlists WHERE user_id = ? AND name = ?",
                (ctx.author.id, name)
            )
            existing = await cursor.fetchone()
            
            if existing:
                return await ctx.reply(f"❌ You already have a playlist named **{name}**!")
            
            # Create playlist
            await db.execute(
                "INSERT INTO playlists (user_id, name) VALUES (?, ?)",
                (ctx.author.id, name)
            )
            await db.commit()
            
            # Get the playlist ID
            cursor = await db.execute("SELECT last_insert_rowid()")
            playlist_id = (await cursor.fetchone())[0]
        
        # Success message
        layout_view = ui.LayoutView(timeout=60)
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay("# ✅ Playlist Created"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(
            f"**Name:** {name}\n"
            f"**ID:** `{playlist_id}`\n\n"
            f"Add songs with `.playlist add {playlist_id} <song name>`"
        ))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay("Lakshmi Music"))
        layout_view.add_item(container)
        
        await ctx.reply(view=layout_view)

    @playlist.command(name="delete", aliases=["remove"])
    @blacklist_check()
    @ignore_check()
    async def playlist_delete(self, ctx: Context, playlist_id: int):
        """Delete a playlist
        
        Usage: .playlist delete <playlist_id>
        """
        async with aiosqlite.connect('db/playlists.db') as db:
            # Check if playlist exists and belongs to user
            cursor = await db.execute(
                "SELECT name FROM playlists WHERE playlist_id = ? AND user_id = ?",
                (playlist_id, ctx.author.id)
            )
            playlist = await cursor.fetchone()
            
            if not playlist:
                return await ctx.reply("❌ Playlist not found or doesn't belong to you!")
            
            # Delete playlist (songs will be deleted automatically due to CASCADE)
            await db.execute("DELETE FROM playlists WHERE playlist_id = ?", (playlist_id,))
            await db.commit()
        
        # Success message
        layout_view = ui.LayoutView(timeout=60)
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay("# 🗑️ Playlist Deleted"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(f"**{playlist[0]}** has been deleted"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay("Lakshmi Music"))
        layout_view.add_item(container)
        
        await ctx.reply(view=layout_view)

    @playlist.command(name="add")
    @blacklist_check()
    @ignore_check()
    async def playlist_add(self, ctx: Context, playlist_id: int, *, query: str):
        """Add a song to playlist
        
        Usage: .playlist add <playlist_id> <song name>
        """
        # Check if playlist exists and belongs to user
        async with aiosqlite.connect('db/playlists.db') as db:
            cursor = await db.execute(
                "SELECT name FROM playlists WHERE playlist_id = ? AND user_id = ?",
                (playlist_id, ctx.author.id)
            )
            playlist = await cursor.fetchone()
            
            if not playlist:
                return await ctx.reply("❌ Playlist not found or doesn't belong to you!")
            
            # Search for song (using voice cog's search)
            voice_cog = self.bot.get_cog("SimpleVoice")
            if not voice_cog:
                return await ctx.reply("❌ Music system not available!")
            
            msg = await ctx.send(f"<a:pol_dance_haveli:1497856158009004172> Searching for **{query}**...")
            info = await voice_cog._search(query)
            
            if not info:
                layout_view = ui.LayoutView(timeout=60)
                container = ui.Container(accent_color=None)
                container.add_item(ui.TextDisplay("# <a:wrong_time:1497855966727897179> No Results Found"))
                container.add_item(ui.Separator())
                container.add_item(ui.TextDisplay(f"**Search Query:** {query[:100]}"))
                container.add_item(ui.Separator())
                container.add_item(ui.TextDisplay("Try searching with different keywords"))
                layout_view.add_item(container)
                return await msg.edit(content="", view=layout_view)
            
            # Add song to playlist
            song_title = info.get("title", "Unknown")
            song_url = info.get("url", "")
            artist = info.get("uploader") or info.get("channel") or "Unknown Artist"
            duration = info.get("duration", 0)
            
            await db.execute(
                "INSERT INTO playlist_songs (playlist_id, song_title, song_url, artist, duration) VALUES (?, ?, ?, ?, ?)",
                (playlist_id, song_title, song_url, artist, duration)
            )
            await db.commit()
        
        # Success message
        layout_view = ui.LayoutView(timeout=60)
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay("# ✅ Song Added to Playlist"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(
            f"**Playlist:** {playlist[0]}\n"
            f"**Song:** {song_title}\n"
            f"**Artist:** {artist}"
        ))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay("Lakshmi Music"))
        layout_view.add_item(container)
        
        await msg.edit(content="", view=layout_view)

    @playlist.command(name="view", aliases=["show", "songs"])
    @blacklist_check()
    @ignore_check()
    async def playlist_view(self, ctx: Context, playlist_id: int):
        """View songs in a playlist
        
        Usage: .playlist view <playlist_id>
        """
        async with aiosqlite.connect('db/playlists.db') as db:
            # Check if playlist exists
            cursor = await db.execute(
                "SELECT name, user_id FROM playlists WHERE playlist_id = ?",
                (playlist_id,)
            )
            playlist = await cursor.fetchone()
            
            if not playlist:
                return await ctx.reply("❌ Playlist not found!")
            
            playlist_name, owner_id = playlist
            
            # Get songs
            cursor = await db.execute("""
                SELECT song_title, artist, duration
                FROM playlist_songs
                WHERE playlist_id = ?
                ORDER BY added_at ASC
            """, (playlist_id,))
            songs = await cursor.fetchall()
        
        # Create view
        layout_view = ui.LayoutView(timeout=300)
        container = ui.Container(accent_color=None)
        
        owner = await self.bot.fetch_user(owner_id)
        container.add_item(ui.TextDisplay(f"# 🎵 {playlist_name}"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(f"**Owner:** {owner.mention}\n**Songs:** {len(songs)}"))
        container.add_item(ui.Separator())
        
        if songs:
            songs_text = ""
            for i, (title, artist, duration) in enumerate(songs[:10], start=1):
                mins = duration // 60
                secs = duration % 60
                songs_text += f"**{i}.** {title[:50]}\n> **Artist:** {artist} • **Duration:** `{mins:02d}:{secs:02d}`\n\n"
            
            container.add_item(ui.TextDisplay(songs_text.strip()))
            
            if len(songs) > 10:
                container.add_item(ui.Separator())
                container.add_item(ui.TextDisplay(f"... and {len(songs) - 10} more songs"))
        else:
            container.add_item(ui.TextDisplay("This playlist is empty!"))
        
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(f"Play with `.playlist play {playlist_id}`"))
        
        layout_view.add_item(container)
        await ctx.reply(view=layout_view)

    @playlist.command(name="play")
    @blacklist_check()
    @ignore_check()
    async def playlist_play(self, ctx: Context, playlist_id: int):
        """Play all songs from a playlist
        
        Usage: .playlist play <playlist_id>
        """
        if not ctx.author.voice:
            return await ctx.reply("❌ You need to be in a voice channel!")
        
        # Get playlist songs
        async with aiosqlite.connect('db/playlists.db') as db:
            cursor = await db.execute(
                "SELECT name FROM playlists WHERE playlist_id = ?",
                (playlist_id,)
            )
            playlist = await cursor.fetchone()
            
            if not playlist:
                return await ctx.reply("❌ Playlist not found!")
            
            cursor = await db.execute("""
                SELECT song_title, song_url, artist, duration
                FROM playlist_songs
                WHERE playlist_id = ?
                ORDER BY added_at ASC
            """, (playlist_id,))
            songs = await cursor.fetchall()
        
        if not songs:
            return await ctx.reply("❌ This playlist is empty!")
        
        # Get voice cog
        voice_cog = self.bot.get_cog("SimpleVoice")
        if not voice_cog:
            return await ctx.reply("❌ Music system not available!")
        
        # Connect to voice if not connected
        if not ctx.voice_client:
            await ctx.author.voice.channel.connect(self_deaf=False, self_mute=False)
        
        # Add all songs to queue
        for song_title, song_url, artist, duration in songs:
            song = {
                "full_title": song_title,
                "artist": artist,
                "url": song_url,
                "duration": duration,
                "thumbnail": "",
                "requester": ctx.author,
            }
            
            if voice_cog.current and (ctx.voice_client.is_playing() or ctx.voice_client.is_paused()):
                voice_cog.queue.append(song)
            else:
                await voice_cog._play_song(ctx, song)
                await asyncio.sleep(0.5)  # Small delay before adding more
        
        # Success message
        layout_view = ui.LayoutView(timeout=60)
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay("# ▶️ Playing Playlist"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(
            f"**Playlist:** {playlist[0]}\n"
            f"**Songs:** {len(songs)}\n\n"
            f"All songs have been added to the queue!"
        ))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay("Lakshmi Music"))
        layout_view.add_item(container)
        
        await ctx.reply(view=layout_view)

    def help_custom(self):
# Trusty X Ayaan - Krishx Dev
        return ("🎵", "Playlist", "Create and manage music playlists")


async def setup(bot):
    await bot.add_cog(Playlist(bot))
