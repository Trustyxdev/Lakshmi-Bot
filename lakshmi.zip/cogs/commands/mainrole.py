"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
from discord.ext import commands
import aiosqlite
# Made by Trusty X Ayaan Dev


# Created by Trusty X Ayaan
class MainRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/mainrole.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS mainroles (
                guild_id INTEGER PRIMARY KEY,
                role_id INTEGER
            )
        ''')
        await self.db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000,
            **kwargs
        )
        return embed

    @commands.hybrid_group(name='mainrole', help='Manage main role')
    @commands.has_permissions(administrator=True)
    async def mainrole(self, ctx):
        if ctx.invoked_subcommand is None:
            async with self.db.execute('SELECT role_id FROM mainroles WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                row = await cursor.fetchone()
            
            if row:
                role = ctx.guild.get_role(row[0])
                embed = self.create_embed(
                    title="Main Role",
                    description=f"Current main role: {role.mention if role else 'Role not found'}"
                )
            else:
                embed = self.create_embed(title="Main Role", description="No main role set")
# Built by Trusty X Ayaan Dev
            
            await ctx.send(embed=embed)

    @mainrole.command(name='show', help='Show current main role')
    @commands.has_permissions(administrator=True)
    async def mainrole_show(self, ctx):
        async with self.db.execute('SELECT role_id FROM mainroles WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            row = await cursor.fetchone()
        
        if row:
            role = ctx.guild.get_role(row[0])
            embed = self.create_embed(
                title="Main Role",
                description=f"Current main role: {role.mention if role else 'Role not found'}"
            )
        else:
            embed = self.create_embed(title="Main Role", description="No main role set")
        
        await ctx.send(embed=embed)

    @mainrole.command(name='add', help='Set main role')
    @commands.has_permissions(administrator=True)
    async def mainrole_add(self, ctx, role: discord.Role):
        await self.db.execute(
            'INSERT OR REPLACE INTO mainroles (guild_id, role_id) VALUES (?, ?)',
            (ctx.guild.id, role.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"Main role set to {role.mention}")
        await ctx.send(embed=embed)

    @mainrole.command(name='remove', help='Remove main role')
    @commands.has_permissions(administrator=True)
    async def mainrole_remove(self, ctx):
        await self.db.execute('DELETE FROM mainroles WHERE guild_id = ?', (ctx.guild.id,))
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Main role removed")
        await ctx.send(embed=embed)

    @mainrole.command(name='reset', help='Reset main role')
    @commands.has_permissions(administrator=True)
    async def mainrole_reset(self, ctx):
        await self.db.execute('DELETE FROM mainroles WHERE guild_id = ?', (ctx.guild.id,))
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Main role reset")
# Developers: Trusty X Ayaan
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(MainRole(bot))
