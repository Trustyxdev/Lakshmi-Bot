"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
import asyncio
import re
import os
import aiohttp
import base64
from discord.ext import commands
from discord import ui
from core import Cog, Context
from utils.Tools import *


# Developers: Trusty X Ayaan
class SpotifyIntegration(Cog):
    """Link and play Spotify playlists"""

    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())
        
        # Spotify API credentials
        self.client_id = os.getenv("SPOTIFY_CLIENT_ID")
        self.client_secret = os.getenv("SPOTIFY_CLIENT_SECRET")
        self.access_token = None
        self.token_expires_at = 0

    async def setup_database(self):
        """Setup Spotify integration database"""
        async with aiosqlite.connect('db/spotify.db') as db:
            # User Spotify links - Enhanced with more fields
            await db.execute("""
                CREATE TABLE IF NOT EXISTS spotify_users (
                    user_id INTEGER PRIMARY KEY,
                    spotify_id TEXT,
                    spotify_username TEXT,
                    display_name TEXT,
                    profile_url TEXT,
                    profile_image TEXT,
                    followers INTEGER DEFAULT 0,
                    linked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Saved Spotify playlists
            await db.execute("""
                CREATE TABLE IF NOT EXISTS spotify_playlists (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    playlist_name TEXT NOT NULL,
                    playlist_url TEXT NOT NULL,
                    playlist_id TEXT NOT NULL,
                    playlist_image TEXT,
                    track_count INTEGER DEFAULT 0,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES spotify_users(user_id) ON DELETE CASCADE
                )
            """)
            
            await db.commit()

    async def get_spotify_token(self):
        """Get Spotify API access token"""
        import time
# Trusty X Ayaan © 2024
        
        # Check if token is still valid
        if self.access_token and time.time() < self.token_expires_at:
            return self.access_token
        
        if not self.client_id or not self.client_secret:
            return None
        
        # Get new token
        auth_str = f"{self.client_id}:{self.client_secret}"
        auth_bytes = auth_str.encode('utf-8')
        auth_base64 = base64.b64encode(auth_bytes).decode('utf-8')
        
        headers = {
            'Authorization': f'Basic {auth_base64}',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        data = {'grant_type': 'client_credentials'}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post('https://accounts.spotify.com/api/token', headers=headers, data=data) as resp:
                    if resp.status == 200:
                        token_data = await resp.json()
                        self.access_token = token_data['access_token']
                        self.token_expires_at = time.time() + token_data['expires_in'] - 60
                        return self.access_token
        except Exception as e:
            print(f"Spotify token error: {e}")
        
        return None

    async def get_spotify_user(self, user_id: str):
        """Fetch Spotify user profile data"""
        token = await self.get_spotify_token()
        if not token:
            return None
        
        headers = {'Authorization': f'Bearer {token}'}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f'https://api.spotify.com/v1/users/{user_id}', headers=headers) as resp:
                    if resp.status == 200:
                        return await resp.json()
        except Exception as e:
            print(f"Spotify user fetch error: {e}")
        
        return None

    async def get_user_playlists(self, user_id: str):
        """Fetch user's public playlists"""
        token = await self.get_spotify_token()
        if not token:
            return []
        
        headers = {'Authorization': f'Bearer {token}'}
        playlists = []
        
        try:
            async with aiohttp.ClientSession() as session:
                url = f'https://api.spotify.com/v1/users/{user_id}/playlists?limit=50'
                async with session.get(url, headers=headers) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        playlists = data.get('items', [])
        except Exception as e:
            print(f"Spotify playlists fetch error: {e}")
        
        return playlists

    def extract_spotify_id(self, url: str) -> tuple:
        """Extract Spotify user/playlist/track ID from URL"""
        # User: https://open.spotify.com/user/username
        user_match = re.search(r'spotify\.com/user/([a-zA-Z0-9_-]+)', url)
        if user_match:
            return ('user', user_match.group(1))
        
        # Playlist: https://open.spotify.com/playlist/37i9dQZF1DXcBWIGoYBM5M
        playlist_match = re.search(r'spotify\.com/playlist/([a-zA-Z0-9]+)', url)
        if playlist_match:
            return ('playlist', playlist_match.group(1))
        
        # Track: https://open.spotify.com/track/3n3Ppam7vgaVa1iaRUc9Lp
        track_match = re.search(r'spotify\.com/track/([a-zA-Z0-9]+)', url)
        if track_match:
            return ('track', track_match.group(1))
        
        return (None, None)

    @commands.group(name="spotify", aliases=["sp"], invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    async def spotify(self, ctx: Context):
        """🎵 Spotify Integration - Manage and play Spotify playlists"""
        if ctx.invoked_subcommand is None:
            # Show ALL Spotify commands
            async with aiosqlite.connect('db/spotify.db') as db:
                cursor = await db.execute(
                    "SELECT display_name, spotify_id, profile_image, followers FROM spotify_users WHERE user_id = ?",
                    (ctx.author.id,)
                )
                user_data = await cursor.fetchone()
                
                # Create help embed
                embed = discord.Embed(
                    title="🎵 Spotify Commands",
                    description="Link your Spotify account and manage playlists",
                    color=0x1DB954
                )
                
                if user_data:
                    display_name, spotify_id, profile_image, followers = user_data
                    
                    if profile_image:
                        embed.set_thumbnail(url=profile_image)
                    
                    embed.add_field(
                        name="📊 Linked Account",
                        value=f"**Name:** {display_name}\n"
                              f"**Username:** {spotify_id}\n"
                              f"**Followers:** {followers:,}",
                        inline=False
                    )
                else:
                    embed.add_field(
                        name="Status",
                        value="❌ Not linked",
                        inline=False
                    )
                
                embed.add_field(
                    name="Available Commands",
                    value=f"`{ctx.prefix}spotify link <link>` - Link Spotify account (auto-fetches profile & playlists)\n"
                          f"`{ctx.prefix}spotify unlink` - Unlink Spotify account\n"
                          f"`{ctx.prefix}spotify add <url> [name]` - Add Spotify playlist\n"
                          f"`{ctx.prefix}spotify playlists` - View saved playlists\n"
                          f"`{ctx.prefix}spotify play <id>` - Play a playlist\n"
                          f"`{ctx.prefix}spotify remove <id>` - Remove a playlist",
                    inline=False
                )
                
                embed.set_footer(text="Lakshmi Music • Spotify Integration")
                
                return await ctx.reply(embed=embed)

    @spotify.command(name="link")
    @blacklist_check()
    @ignore_check()
    async def spotify_link(self, ctx: Context, *, link_or_username: str):
        """Link your Spotify account - Bot will automatically fetch your profile and playlists
        
        Usage: .spotify link <profile_link or username>
        Example: .spotify link https://open.spotify.com/user/ayaanbaby
        Example: .spotify link ayaanbaby
        """
        # Send loading message
        loading_msg = await ctx.reply("<a:pol_dance_haveli:1497856158009004172> Fetching your Spotify profile...")
        
        # Extract user ID from link or use as username
        item_type, user_id = self.extract_spotify_id(link_or_username)
        
        if item_type == 'user':
            username = user_id
        elif 'spotify.com' not in link_or_username:
            username = link_or_username
        else:
            await loading_msg.edit(content="❌ Invalid Spotify profile link! Please provide a valid user profile link.")
            return
        
        # Check if API is configured
        if not self.client_id or not self.client_secret:
            # Fallback to basic linking without API
            profile_url = f"https://open.spotify.com/user/{username}"
            
            async with aiosqlite.connect('db/spotify.db') as db:
                cursor = await db.execute(
                    "SELECT spotify_username FROM spotify_users WHERE user_id = ?",
                    (ctx.author.id,)
                )
                existing = await cursor.fetchone()
                
                if existing:
                    await db.execute(
                        "UPDATE spotify_users SET spotify_username = ?, profile_url = ? WHERE user_id = ?",
                        (username, profile_url, ctx.author.id)
                    )
                else:
                    await db.execute(
                        "INSERT INTO spotify_users (user_id, spotify_username, profile_url) VALUES (?, ?, ?)",
                        (ctx.author.id, username, profile_url)
                    )
                
                await db.commit()
            
            layout_view = ui.LayoutView(timeout=60)
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay("# ✅ Spotify Linked"))
            container.add_item(ui.Separator())
            container.add_item(ui.TextDisplay(
                f"**Username:** {username}\n"
                f"**Profile:** [Open Spotify]({profile_url})\n\n"
                f"⚠️ **Note:** Spotify API not configured. Using basic mode.\n"
                f"Add playlists manually with `{ctx.prefix}spotify add <playlist_url>`"
            ))
            container.add_item(ui.Separator())
            container.add_item(ui.TextDisplay("Lakshmi Music"))
            layout_view.add_item(container)
            
            await loading_msg.edit(content="", view=layout_view)
            return
        
        # Fetch user data from Spotify API
        user_data = await self.get_spotify_user(username)
        
        if not user_data:
            await loading_msg.edit(content=f"❌ Could not find Spotify user `{username}`. Make sure the profile is public!")
            return
        
        # Extract user info
        spotify_id = user_data.get('id', username)
        display_name = user_data.get('display_name', username)
        profile_url = user_data.get('external_urls', {}).get('spotify', f"https://open.spotify.com/user/{username}")
        followers = user_data.get('followers', {}).get('total', 0)
        
        # Get profile image
        images = user_data.get('images', [])
        profile_image = images[0]['url'] if images else None
        
        # Fetch user's playlists
        playlists = await self.get_user_playlists(spotify_id)
        
        # Save to database
        async with aiosqlite.connect('db/spotify.db') as db:
            cursor = await db.execute(
                "SELECT spotify_id FROM spotify_users WHERE user_id = ?",
                (ctx.author.id,)
            )
            existing = await cursor.fetchone()
            
            if existing:
                # Update existing
                await db.execute("""
                    UPDATE spotify_users 
                    SET spotify_id = ?, spotify_username = ?, display_name = ?, 
                        profile_url = ?, profile_image = ?, followers = ?
                    WHERE user_id = ?
                """, (spotify_id, username, display_name, profile_url, profile_image, followers, ctx.author.id))
            else:
                # Insert new
                await db.execute("""
                    INSERT INTO spotify_users 
                    (user_id, spotify_id, spotify_username, display_name, profile_url, profile_image, followers)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (ctx.author.id, spotify_id, username, display_name, profile_url, profile_image, followers))
            
            # Auto-save public playlists (optional - first 10)
            saved_count = 0
            for playlist in playlists[:10]:
                playlist_id = playlist.get('id')
                playlist_name = playlist.get('name', 'Unnamed Playlist')
                playlist_url = playlist.get('external_urls', {}).get('spotify', '')
                track_count = playlist.get('tracks', {}).get('total', 0)
                
                # Get playlist image
                playlist_images = playlist.get('images', [])
                playlist_image = playlist_images[0]['url'] if playlist_images else None
                
                # Check if already exists
                cursor = await db.execute(
                    "SELECT id FROM spotify_playlists WHERE user_id = ? AND playlist_id = ?",
                    (ctx.author.id, playlist_id)
                )
                if not await cursor.fetchone():
                    await db.execute("""
                        INSERT INTO spotify_playlists 
                        (user_id, playlist_name, playlist_url, playlist_id, playlist_image, track_count)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (ctx.author.id, playlist_name, playlist_url, playlist_id, playlist_image, track_count))
                    saved_count += 1
            
            await db.commit()
        
        # Create success embed
        embed = discord.Embed(
            title="✅ Spotify Linked Successfully",
            description=f"Your Spotify account has been linked and synced!",
            color=0x1DB954  # Spotify green
        )
        
        if profile_image:
            embed.set_thumbnail(url=profile_image)
        
        embed.add_field(
            name="📊 Profile Info",
            value=f"**Display Name:** {display_name}\n"
                  f"**Username:** {spotify_id}\n"
                  f"**Followers:** {followers:,}\n"
                  f"**Profile:** [Open Spotify]({profile_url})",
            inline=False
        )
        
        embed.add_field(
            name="🎵 Playlists",
            value=f"**Found:** {len(playlists)} public playlists\n"
                  f"**Auto-Saved:** {saved_count} playlists\n\n"
                  f"View with `{ctx.prefix}spotify playlists`",
            inline=False
        )
        
        embed.set_footer(text="Lakshmi Music • Spotify Integration")
        
        await loading_msg.edit(content="", embed=embed)

    @spotify.command(name="unlink")
    @blacklist_check()
    @ignore_check()
    async def spotify_unlink(self, ctx: Context):
        """Unlink your Spotify account and remove all saved playlists"""
        async with aiosqlite.connect('db/spotify.db') as db:
            cursor = await db.execute(
                "SELECT display_name, spotify_id FROM spotify_users WHERE user_id = ?",
# © Trusty X Ayaan Development
                (ctx.author.id,)
            )
            user_data = await cursor.fetchone()
            
            if not user_data:
                return await ctx.reply("❌ You haven't linked a Spotify account!")
            
            display_name, spotify_id = user_data
            
            # Get playlist count before deletion
            cursor = await db.execute(
                "SELECT COUNT(*) FROM spotify_playlists WHERE user_id = ?",
                (ctx.author.id,)
            )
            playlist_count = (await cursor.fetchone())[0]
            
            # Delete user data (playlists will be deleted due to CASCADE)
            await db.execute("DELETE FROM spotify_users WHERE user_id = ?", (ctx.author.id,))
            await db.commit()
        
        # Success embed
        embed = discord.Embed(
            title="🔓 Spotify Unlinked",
            description=f"Your Spotify account has been successfully unlinked",
            color=0xFF0000
        )
        
        embed.add_field(
            name="Removed Data",
            value=f"**Account:** {display_name} ({spotify_id})\n"
                  f"**Playlists Removed:** {playlist_count}",
            inline=False
        )
        
        embed.add_field(
            name="Link Again",
            value=f"You can link your account anytime with:\n`{ctx.prefix}spotify link <username>`",
            inline=False
        )
        
        embed.set_footer(text="Lakshmi Music • Spotify Integration")
        
        await ctx.reply(embed=embed)

    @spotify.command(name="add")
    @blacklist_check()
    @ignore_check()
    async def spotify_add(self, ctx: Context, playlist_url: str, *, name: str = None):
        """Add a Spotify playlist - Bot will fetch playlist details automatically
        
        Usage: .spotify add <playlist_url> [name]
        Example: .spotify add https://open.spotify.com/playlist/37i9dQZF1DXcBWIGoYBM5M
        """
        # Check if user has linked Spotify
        async with aiosqlite.connect('db/spotify.db') as db:
            cursor = await db.execute(
                "SELECT spotify_username FROM spotify_users WHERE user_id = ?",
                (ctx.author.id,)
            )
            user_data = await cursor.fetchone()
            
            if not user_data:
                return await ctx.reply(f"❌ Please link your Spotify first with `{ctx.prefix}spotify link <username>`")
            
            # Extract playlist ID
            item_type, playlist_id = self.extract_spotify_id(playlist_url)
            
            if item_type != 'playlist':
                return await ctx.reply("❌ Invalid Spotify playlist URL! Please provide a valid playlist link.")
            
            # Check if already added
            cursor = await db.execute(
                "SELECT id FROM spotify_playlists WHERE user_id = ? AND playlist_id = ?",
                (ctx.author.id, playlist_id)
            )
            existing = await cursor.fetchone()
            
            if existing:
                return await ctx.reply("❌ You've already added this playlist!")
            
            # Send loading message
            loading_msg = await ctx.reply("<a:pol_dance_haveli:1497856158009004172> Fetching playlist details...")
            
            # Try to fetch playlist details from API
            playlist_name = name
            playlist_image = None
            track_count = 0
            
            token = await self.get_spotify_token()
            if token:
                try:
                    headers = {'Authorization': f'Bearer {token}'}
                    async with aiohttp.ClientSession() as session:
                        async with session.get(f'https://api.spotify.com/v1/playlists/{playlist_id}', headers=headers) as resp:
                            if resp.status == 200:
                                playlist_data = await resp.json()
                                if not playlist_name:
                                    playlist_name = playlist_data.get('name', f'Playlist {playlist_id[:8]}')
                                track_count = playlist_data.get('tracks', {}).get('total', 0)
                                images = playlist_data.get('images', [])
                                playlist_image = images[0]['url'] if images else None
                except Exception as e:
                    print(f"Error fetching playlist: {e}")
            
            # Fallback name if still not set
            if not playlist_name:
                playlist_name = name or f"Playlist {playlist_id[:8]}"
            
            # Add playlist
            await db.execute("""
                INSERT INTO spotify_playlists 
                (user_id, playlist_name, playlist_url, playlist_id, playlist_image, track_count)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (ctx.author.id, playlist_name, playlist_url, playlist_id, playlist_image, track_count))
            await db.commit()
            
            # Get the ID
            cursor = await db.execute("SELECT last_insert_rowid()")
            db_id = (await cursor.fetchone())[0]
        
        # Success embed
        embed = discord.Embed(
            title="✅ Playlist Added",
            description=f"**{playlist_name}** has been added to your library",
            color=0x1DB954
        )
        
        if playlist_image:
            embed.set_thumbnail(url=playlist_image)
        
        embed.add_field(
            name="Playlist Info",
            value=f"**Name:** {playlist_name}\n"
                  f"**ID:** `{db_id}`\n"
                  f"**Tracks:** {track_count if track_count > 0 else 'Unknown'}\n"
                  f"**Spotify ID:** `{playlist_id}`",
            inline=False
        )
        
        embed.add_field(
            name="Play Now",
            value=f"Use `{ctx.prefix}spotify play {db_id}` to play this playlist",
            inline=False
        )
        
        embed.set_footer(text="Lakshmi Music • Spotify Integration")
        
        await loading_msg.edit(content="", embed=embed)

    @spotify.command(name="playlists", aliases=["list"])
    @blacklist_check()
    @ignore_check()
    async def spotify_playlists(self, ctx: Context):
        """View your Spotify playlists with details"""
        async with aiosqlite.connect('db/spotify.db') as db:
            # Check if linked
            cursor = await db.execute(
                "SELECT spotify_id, display_name, profile_image, followers FROM spotify_users WHERE user_id = ?",
                (ctx.author.id,)
            )
            user_data = await cursor.fetchone()
            
            if not user_data:
                return await ctx.reply(f"❌ Please link your Spotify first with `{ctx.prefix}spotify link <username>`")
            
            spotify_id, display_name, profile_image, followers = user_data
            
            # Get playlists
            cursor = await db.execute("""
                SELECT id, playlist_name, playlist_id, playlist_image, track_count
                FROM spotify_playlists
                WHERE user_id = ?
                ORDER BY added_at DESC
            """, (ctx.author.id,))
            playlists = await cursor.fetchall()
        
        # Create embed
        embed = discord.Embed(
            title=f"🎵 {display_name}'s Spotify Playlists",
            description=f"**Followers:** {followers:,} • **Playlists:** {len(playlists)}",
            color=0x1DB954
        )
        
        if profile_image:
            embed.set_thumbnail(url=profile_image)
        
        if not playlists:
            embed.add_field(
                name="No Playlists",
                value=f"You haven't added any playlists yet!\n\n"
                      f"Add one with `{ctx.prefix}spotify add <playlist_url>`\n"
                      f"Or re-link to auto-sync: `{ctx.prefix}spotify link {spotify_id}`",
                inline=False
            )
        else:
            # Show first 10 playlists
            for i, (db_id, name, sp_id, image, track_count) in enumerate(playlists[:10], start=1):
                embed.add_field(
                    name=f"{i}. {name}",
                    value=f"**ID:** `{db_id}` • **Tracks:** {track_count}\n"
                          f"**Play:** `{ctx.prefix}spotify play {db_id}`",
                    inline=False
                )
            
            if len(playlists) > 10:
                embed.add_field(
                    name="More Playlists",
                    value=f"... and {len(playlists) - 10} more playlists",
                    inline=False
                )
        
        embed.set_footer(text="Lakshmi Music • Spotify Integration")
        
        await ctx.reply(embed=embed)

    @spotify.command(name="play")
    @blacklist_check()
    @ignore_check()
    async def spotify_play(self, ctx: Context, playlist_id: int):
        """Play a Spotify playlist in voice channel
        
        Usage: .spotify play <playlist_id>
        Example: .spotify play 1
        """
        if not ctx.author.voice:
            return await ctx.reply("❌ You need to be in a voice channel!")
        
        # Get playlist
        async with aiosqlite.connect('db/spotify.db') as db:
            cursor = await db.execute("""
                SELECT playlist_name, playlist_url, playlist_id, playlist_image, track_count
                FROM spotify_playlists
                WHERE id = ? AND user_id = ?
            """, (playlist_id, ctx.author.id))
            playlist = await cursor.fetchone()
            
            if not playlist:
                return await ctx.reply("❌ Playlist not found or doesn't belong to you!")
        
        playlist_name, playlist_url, spotify_id, playlist_image, track_count = playlist
        
        # Get voice cog
        voice_cog = self.bot.get_cog("SimpleVoice")
        if not voice_cog:
            return await ctx.reply("❌ Music system not available!")
        
        # Connect to voice if not connected
        if not ctx.voice_client:
            await ctx.author.voice.channel.connect(self_deaf=False, self_mute=False)
        
        # Send loading embed
        loading_embed = discord.Embed(
            title="<a:pol_dance_haveli:1497856158009004172> Loading Playlist",
            description=f"Fetching songs from **{playlist_name}**...",
            color=0x1DB954
        )
        if playlist_image:
            loading_embed.set_thumbnail(url=playlist_image)
        loading_msg = await ctx.send(embed=loading_embed)
        
        try:
            # Use yt-dlp to extract Spotify playlist
            loop = asyncio.get_event_loop()
            data = await loop.run_in_executor(
                None, lambda: voice_cog.ytdl.extract_info(playlist_url, download=False)
            )
            
            if not data or 'entries' not in data:
                error_embed = discord.Embed(
                    title="❌ Failed to Load",
                    description="Could not load Spotify playlist.\n\n"
                                "**Note:** Spotify integration requires yt-dlp with Spotify support.",
                    color=0xFF0000
                )
                return await loading_msg.edit(embed=error_embed)
            
            entries = data.get('entries', [])
            
            if not entries:
                return await loading_msg.edit(content="❌ No songs found in this playlist!", embed=None)
            
            # Add songs to queue
            added_count = 0
            for entry in entries[:50]:  # Limit to 50 songs
                if not entry:
                    continue
                
                song = {
                    "full_title": entry.get("title", "Unknown"),
                    "artist": entry.get("uploader") or entry.get("artist") or "Unknown Artist",
                    "url": entry.get("url", ""),
                    "duration": entry.get("duration", 0),
                    "thumbnail": entry.get("thumbnail", ""),
                    "requester": ctx.author,
                }
                
                if voice_cog.current and (ctx.voice_client.is_playing() or ctx.voice_client.is_paused()):
                    voice_cog.queue.append(song)
                else:
                    await voice_cog._play_song(ctx, song)
                    await asyncio.sleep(0.5)
                
                added_count += 1
            
            # Success embed
            success_embed = discord.Embed(
                title="▶️ Playing Spotify Playlist",
                description=f"**{playlist_name}** is now playing!",
                color=0x1DB954
            )
            
            if playlist_image:
                success_embed.set_thumbnail(url=playlist_image)
            
            success_embed.add_field(
                name="Playlist Info",
                value=f"**Songs Added:** {added_count}\n"
                      f"**Total Tracks:** {track_count if track_count > 0 else 'Unknown'}\n"
                      f"**Source:** Spotify",
                inline=False
            )
            
            success_embed.add_field(
                name="Queue Status",
                value=f"All songs have been added to the queue!\n"
                      f"Use `{ctx.prefix}queue` to view the full queue",
                inline=False
            )
            
            success_embed.set_footer(text="Lakshmi Music • Spotify Integration")
            
            await loading_msg.edit(embed=success_embed)
            
        except Exception as e:
            error_embed = discord.Embed(
                title="❌ Error Loading Playlist",
                description=f"Failed to load Spotify playlist:\n```{str(e)}```\n\n"
                            "**Note:** Make sure the playlist is public and accessible.",
                color=0xFF0000
            )
            await loading_msg.edit(embed=error_embed)

    @spotify.command(name="remove", aliases=["delete", "del"])
    @blacklist_check()
    @ignore_check()
    async def spotify_remove(self, ctx: Context, playlist_id: int):
        """Remove a Spotify playlist from your library
        
        Usage: .spotify remove <playlist_id>
        Example: .spotify remove 1
        """
        async with aiosqlite.connect('db/spotify.db') as db:
            cursor = await db.execute(
                "SELECT playlist_name, playlist_image, track_count FROM spotify_playlists WHERE id = ? AND user_id = ?",
                (playlist_id, ctx.author.id)
            )
            playlist = await cursor.fetchone()
            
            if not playlist:
                return await ctx.reply("❌ Playlist not found or doesn't belong to you!")
            
            playlist_name, playlist_image, track_count = playlist
            
            # Delete playlist
            await db.execute("DELETE FROM spotify_playlists WHERE id = ?", (playlist_id,))
            await db.commit()
        
        # Success embed
        embed = discord.Embed(
            title="🗑️ Playlist Removed",
            description=f"**{playlist_name}** has been removed from your library",
            color=0xFF0000
        )
        
        if playlist_image:
            embed.set_thumbnail(url=playlist_image)
        
        embed.add_field(
            name="Removed Playlist",
            value=f"**Name:** {playlist_name}\n"
                  f"**ID:** `{playlist_id}`\n"
                  f"**Tracks:** {track_count if track_count > 0 else 'Unknown'}",
            inline=False
        )
        
        embed.set_footer(text="Lakshmi Music • Spotify Integration")
        
        await ctx.reply(embed=embed)

    def help_custom(self):
# Created by Trusty X Ayaan
        return ("🎵", "Spotify", "Link and play Spotify playlists")


async def setup(bot):
    await bot.add_cog(SpotifyIntegration(bot))
