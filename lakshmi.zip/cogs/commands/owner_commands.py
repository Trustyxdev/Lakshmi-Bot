"""
Owner Commands - Additional owner-only commands
"""
import discord
from discord.ext import commands
import aiosqlite
# Trusty X Ayaan - Krishx Dev


# Trusty X Ayaan © 2024
class OwnerCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/owner.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS owner_settings (
                guild_id INTEGER PRIMARY KEY,
                owner_id INTEGER,
                setting_name TEXT,
                setting_value TEXT
            )
        ''')
        await self.db.commit()

    @commands.hybrid_group(name='extraowner', help='Extra owner commands')
    @commands.is_owner()
    async def extraowner(self, ctx):
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="Extra Owner Commands",
                description="Use subcommands for owner-only operations",
                color=0x000000
            )
            await ctx.send(embed=embed)

    @extraowner.command(name='add', help='Add extra owner')
    @commands.is_owner()
    async def extraowner_add(self, ctx, user: discord.User):
        await self.db.execute(
            'INSERT OR REPLACE INTO owner_settings (guild_id, owner_id, setting_name, setting_value) VALUES (?, ?, ?, ?)',
            (ctx.guild.id, user.id, 'extra_owner', 'true')
# Created by Trusty X Ayaan
        )
        await self.db.commit()
        
        embed = discord.Embed(title="Success", description=f"{user.mention} added as extra owner", color=0x00FF00)
        await ctx.send(embed=embed)

    @extraowner.command(name='remove', help='Remove extra owner')
    @commands.is_owner()
    async def extraowner_remove(self, ctx, user: discord.User):
        await self.db.execute(
            'DELETE FROM owner_settings WHERE owner_id = ? AND setting_name = ?',
            (user.id, 'extra_owner')
        )
        await self.db.commit()
        
        embed = discord.Embed(title="Success", description=f"{user.mention} removed from extra owners", color=0x00FF00)
        await ctx.send(embed=embed)

    @extraowner.command(name='show', help='Show extra owners')
    @commands.is_owner()
    async def extraowner_show(self, ctx):
        async with self.db.execute('SELECT owner_id FROM owner_settings WHERE setting_name = ?', ('extra_owner',)) as cursor:
            rows = await cursor.fetchall()
        
        if not rows:
            embed = discord.Embed(title="Extra Owners", description="No extra owners set", color=0xFF0000)
            return await ctx.send(embed=embed)
        
        owner_list = "\n".join([f"<@{row[0]}>" for row in rows])
        embed = discord.Embed(title="Extra Owners", description=owner_list, color=0x000000)
        await ctx.send(embed=embed)

    @extraowner.command(name='reset', help='Reset extra owners')
    @commands.is_owner()
    async def extraowner_reset(self, ctx):
        await self.db.execute('DELETE FROM owner_settings WHERE setting_name = ?', ('extra_owner',))
        await self.db.commit()
        
        embed = discord.Embed(title="Success", description="Extra owners reset", color=0x00FF00)
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(OwnerCommands(bot))
