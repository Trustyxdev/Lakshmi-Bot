"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
from discord.ext import commands
from utils.Tools import blacklist_check, ignore_check
# © Trusty X Ayaan Development


# Trusty X Ayaan - discord.gg/ibadat
class AutoRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/bot_database.db") as db:
            await db.execute(
                """CREATE TABLE IF NOT EXISTS autorole_config (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER,
                    role_id INTEGER,
                    apply_to_bots INTEGER DEFAULT 0,
                    apply_to_humans INTEGER DEFAULT 1,
                    created_at TEXT,
                    UNIQUE(guild_id, role_id)
                )"""
            )
            await db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000
        )
        for key, value in kwargs.items():
            if value:
                embed.add_field(name=key, value=value, inline=False)
        return embed

    @commands.group(name="autorole", invoke_without_command=True)
    @commands.has_permissions(manage_roles=True)
    @blacklist_check()
    @ignore_check()
    async def autorole(self, ctx):
        """Manage automatic role assignment"""
        await ctx.send_help(ctx.command)

    @autorole.command(name="add")
    @commands.has_permissions(manage_roles=True)
    async def autorole_add(self, ctx, role: discord.Role, apply_to_bots: bool = False):
        """Add a role to be automatically assigned"""
        if role.position >= ctx.guild.me.top_role.position:
            embed = self.create_embed(
                "❌ Role Too High",
                "I cannot assign roles higher than my own role."
            )
            return await ctx.reply(embed=embed)

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO autorole_config 
                    (guild_id, role_id, apply_to_bots, apply_to_humans, created_at)
                    VALUES (?, ?, ?, 1, datetime('now'))""",
                    (ctx.guild.id, role.id, 1 if apply_to_bots else 0)
                )
                await db.commit()

            apply_text = "bots and humans" if apply_to_bots else "humans only"
            embed = self.create_embed(
                "✅ Role Added",
                f"{role.mention} will be automatically assigned to {apply_text}."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to add role: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @autorole.command(name="remove")
    @commands.has_permissions(manage_roles=True)
    async def autorole_remove(self, ctx, role: discord.Role):
        """Remove a role from auto-assignment"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM autorole_config WHERE guild_id = ? AND role_id = ?",
                    (ctx.guild.id, role.id)
                )
                existing = await cursor.fetchone()

                if not existing:
                    embed = self.create_embed(
                        "❌ Role Not Found",
                        f"{role.mention} is not in the auto-role list."
                    )
                    return await ctx.reply(embed=embed)

                await db.execute(
                    "DELETE FROM autorole_config WHERE guild_id = ? AND role_id = ?",
                    (ctx.guild.id, role.id)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Role Removed",
                f"{role.mention} has been removed from auto-role."
# Dev: Trusty X Ayaan
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to remove role: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @autorole.command(name="list")
    @commands.has_permissions(manage_roles=True)
    async def autorole_list(self, ctx):
        """List all auto-roles"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    "SELECT * FROM autorole_config WHERE guild_id = ? ORDER BY created_at DESC",
                    (ctx.guild.id,)
                )
                roles = await cursor.fetchall()

            if not roles:
                embed = self.create_embed(
                    "📋 Auto-Roles",
                    "No auto-roles configured."
                )
                return await ctx.reply(embed=embed)

            role_text = ""
            for idx, role_entry in enumerate(roles, 1):
                role = ctx.guild.get_role(role_entry['role_id'])
                role_mention = role.mention if role else f"Unknown ({role_entry['role_id']})"
                apply_to = "Bots & Humans" if role_entry['apply_to_bots'] else "Humans Only"
                role_text += f"**{idx}.** {role_mention}\n   Apply to: {apply_to}\n"

            embed = self.create_embed(
                "📋 Auto-Roles",
                role_text
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to fetch roles: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @autorole.command(name="clear")
    @commands.has_permissions(manage_roles=True)
    async def autorole_clear(self, ctx):
        """Clear all auto-roles"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT COUNT(*) FROM autorole_config WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                count = await cursor.fetchone()

                if count[0] == 0:
                    embed = self.create_embed(
                        "❌ No Roles",
                        "There are no auto-roles to clear."
                    )
                    return await ctx.reply(embed=embed)

                await db.execute(
                    "DELETE FROM autorole_config WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Auto-Roles Cleared",
                f"Removed **{count[0]}** auto-roles."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to clear roles: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    "SELECT * FROM autorole_config WHERE guild_id = ?",
                    (member.guild.id,)
                )
                roles = await cursor.fetchall()

                for role_entry in roles:
                    # Check if should apply to this member
                    if member.bot and not role_entry['apply_to_bots']:
                        continue
                    if not member.bot and not role_entry['apply_to_humans']:
                        continue

                    role = member.guild.get_role(role_entry['role_id'])
                    if role:
                        try:
                            await member.add_roles(role)
                        except:
                            pass
        except:
            pass


async def setup(bot):
    await bot.add_cog(AutoRole(bot))
