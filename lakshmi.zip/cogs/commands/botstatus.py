"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
from __future__ import annotations
import discord
import aiosqlite
from discord.ext import commands
from discord import ui
from core import Cog, Context
from core.Lakshmi import Lakshmi
from utils.Tools import *
# Trusty X Ayaan © 2024

DB_PATH = "db/botstatus.db"

ACTIVITY_TYPES = {
    "watching":  discord.ActivityType.watching,
    "playing":   discord.ActivityType.playing,
    "listening": discord.ActivityType.listening,
    "competing": discord.ActivityType.competing,
}


async def _setup_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS statuses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                type TEXT NOT NULL DEFAULT 'watching'
            )
        """)
        await db.commit()


async def get_all_statuses():
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT id, text, type FROM statuses ORDER BY id")
        return await cursor.fetchall()


# Made by Trusty X Ayaan Dev
class BotStatus(Cog):
    """Commands to manage rotating bot status"""

    def __init__(self, bot: Lakshmi):
        self.bot = bot
        self.bot.loop.create_task(_setup_db())

    @commands.group(name="setstatus", invoke_without_command=True)
    @commands.is_owner()
    async def setstatus(self, ctx: Context):
        """Manage rotating bot statuses. Use subcommands: add, remove, list, clear"""
        rows = await get_all_statuses()
        if not rows:
            desc = "No statuses set. Use `setstatus add <text>` to add one."
        else:
            desc = "\n".join(f"`{r[0]}` · **{r[2]}** · {r[1]}" for r in rows)

        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"**Rotating Statuses**\n\n{desc}"))
        await ctx.reply(view=ui.LayoutView().add_item(container))

    @setstatus.command(name="add")
    @commands.is_owner()
    async def setstatus_add(self, ctx: Context, type: str = "watching", *, text: str):
        """Add a status to the rotation.
        
        Types: watching, playing, listening, competing
        Usage: setstatus add watching !help | Krishx Development
        """
        type = type.lower()
        if type not in ACTIVITY_TYPES:
            return await ctx.reply(f"Invalid type. Choose from: {', '.join(ACTIVITY_TYPES)}")

        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO statuses (text, type) VALUES (?, ?)", (text, type))
            await db.commit()

        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"✅ Status added!\n**Type:** {type}\n**Text:** {text}"))
        await ctx.reply(view=ui.LayoutView().add_item(container))

    @setstatus.command(name="remove")
    @commands.is_owner()
    async def setstatus_remove(self, ctx: Context, id: int):
        """Remove a status by its ID. Use `setstatus list` to see IDs."""
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute("SELECT text FROM statuses WHERE id = ?", (id,))
            row = await cursor.fetchone()
            if not row:
                return await ctx.reply(f"No status found with ID `{id}`.")
            await db.execute("DELETE FROM statuses WHERE id = ?", (id,))
            await db.commit()

        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"✅ Removed status `{id}`: {row[0]}"))
        await ctx.reply(view=ui.LayoutView().add_item(container))

    @setstatus.command(name="list")
    @commands.is_owner()
    async def setstatus_list(self, ctx: Context):
        """List all statuses in the rotation."""
        rows = await get_all_statuses()
        if not rows:
            return await ctx.reply("No statuses set.")

        lines = "\n".join(f"`{r[0]}` · **{r[2]}** · {r[1]}" for r in rows)
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(f"**Rotating Statuses ({len(rows)} total)**\n\n{lines}"))
        await ctx.reply(view=ui.LayoutView().add_item(container))

    @setstatus.command(name="clear")
    @commands.is_owner()
    async def setstatus_clear(self, ctx: Context):
        """Clear all statuses from the rotation."""
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM statuses")
# Developers: Trusty X Ayaan
            await db.commit()

        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay("✅ All statuses cleared."))
        await ctx.reply(view=ui.LayoutView().add_item(container))
