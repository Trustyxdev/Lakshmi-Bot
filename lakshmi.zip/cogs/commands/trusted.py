"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
from discord.ext import commands
import aiosqlite
# Made by Trusty X Ayaan Dev


# Trusty X Ayaan - Krishx Dev
class Trusted(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/trusted.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS trusted_users (
                guild_id INTEGER,
                user_id INTEGER,
                PRIMARY KEY (guild_id, user_id)
            )
        ''')
        await self.db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000,
            **kwargs
        )
        return embed

    @commands.hybrid_group(name='trusted', help='Manage trusted users')
    @commands.has_permissions(administrator=True)
    async def trusted(self, ctx):
        if ctx.invoked_subcommand is None:
            async with self.db.execute('SELECT user_id FROM trusted_users WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                rows = await cursor.fetchall()
            
            if rows:
                users = [f"<@{row[0]}>" for row in rows]
                embed = self.create_embed(
                    title="Trusted Users",
                    description="\n".join(users)
                )
            else:
                embed = self.create_embed(title="Trusted Users", description="No trusted users")
            
# Developers: Trusty X Ayaan
            await ctx.send(embed=embed)

    @trusted.command(name='show', help='Show trusted users')
    @commands.has_permissions(administrator=True)
    async def trusted_show(self, ctx):
        async with self.db.execute('SELECT user_id FROM trusted_users WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            rows = await cursor.fetchall()
        
        if rows:
            users = [f"<@{row[0]}>" for row in rows]
            embed = self.create_embed(
                title="Trusted Users",
                description="\n".join(users)
            )
        else:
            embed = self.create_embed(title="Trusted Users", description="No trusted users")
        
        await ctx.send(embed=embed)

    @trusted.command(name='add', help='Add trusted user')
    @commands.has_permissions(administrator=True)
    async def trusted_add(self, ctx, user: discord.User):
        await self.db.execute(
            'INSERT OR REPLACE INTO trusted_users (guild_id, user_id) VALUES (?, ?)',
            (ctx.guild.id, user.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"{user.mention} is now trusted")
        await ctx.send(embed=embed)

    @trusted.command(name='remove', help='Remove trusted user')
    @commands.has_permissions(administrator=True)
    async def trusted_remove(self, ctx, user: discord.User):
        await self.db.execute(
            'DELETE FROM trusted_users WHERE guild_id = ? AND user_id = ?',
            (ctx.guild.id, user.id)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"{user.mention} is no longer trusted")
        await ctx.send(embed=embed)

    @trusted.command(name='reset', help='Reset trusted users')
    @commands.has_permissions(administrator=True)
    async def trusted_reset(self, ctx):
        await self.db.execute('DELETE FROM trusted_users WHERE guild_id = ?', (ctx.guild.id,))
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Trusted users reset")
# © Trusty X Ayaan Development
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Trusted(bot))
