"""
Giveaway UI System - Custom Emoji Style
Uses custom animated emojis for modern look

Author: Trusty + Ayaan
Community: discord.gg/ibadat
"""

import discord
from discord import ui


# Developers: Trusty X Ayaan
class GiveawayUIGenerator:
    """Generate giveaway embeds with custom emojis"""
    
    @staticmethod
    def create_giveaway_preview_view(giveaway_data, author, guild):
        """Create giveaway embed with custom emojis"""
        
        prize = giveaway_data.get('prize', 'Example Prize')
        winners = giveaway_data.get('winners', 1)
        ends_at = giveaway_data.get('ends_at')
        thumbnail_url = giveaway_data.get('thumbnail')
        banner_url = giveaway_data.get('image')
        
        # Use provided ends_at or calculate preview time
        if not ends_at:
            import datetime
            ends_at = datetime.datetime.now().timestamp() + 3600
        
        # Create embed with custom emoji title
        embed = discord.Embed(
            title="<:pankh_haveli:1497856147510788128> +",
            color=0x2f3136
        )
        
        # Description with custom emojis and format
        timestamp_r = round(ends_at)
        timestamp_f = round(ends_at)
        
        description = f"<a:hd_KASOOR_DOT:1497856029474422905> **Ended:** <t:{timestamp_r}:R>\n"
        description += f"<a:hd_KASOOR_DOT:1497856029474422905> **Hosted by:** {author.mention}\n"
        description += f"<a:hd_KASOOR_DOT:1497856029474422905> **Winners:** {winners}"
        
        # Add requirements if any
        requirements = []
        
        # Required roles
        required_roles = giveaway_data.get('required_roles', [])
        if isinstance(required_roles, str):
            try:
                required_roles = [int(required_roles)]
            except:
                required_roles = []
        elif not isinstance(required_roles, list):
            required_roles = []
        
        if giveaway_data.get('required_role'):
            try:
                required_roles.append(int(giveaway_data['required_role']))
            except:
                pass
        
        if required_roles:
            role_mentions = []
            for role_id in required_roles:
                try:
                    role = guild.get_role(int(role_id))
                    if role:
                        role_mentions.append(role.mention)
                    else:
                        role_mentions.append(f"<@&{role_id}>")
                except:
                    role_mentions.append(f"<@&{role_id}>")
            
            if role_mentions:
                requirements.append(f"<a:hd_KASOOR_DOT:1497856029474422905> **Required Role:** {', '.join(role_mentions)}")
        
        # Other requirements
        if giveaway_data.get('required_level'):
            requirements.append(f"<a:hd_KASOOR_DOT:1497856029474422905> **Required Level:** {giveaway_data['required_level']}+")
        
        if giveaway_data.get('required_total_messages'):
            requirements.append(f"<a:hd_KASOOR_DOT:1497856029474422905> **Required Messages:** {giveaway_data['required_total_messages']}+")
        
        # Bypass role
        bypass_role_id = giveaway_data.get('requirement_bypass_role') or giveaway_data.get('bypass_role') or giveaway_data.get('requirements_bypass_role')
        if bypass_role_id:
            try:
                bypass_role = guild.get_role(int(bypass_role_id))
                if bypass_role:
                    requirements.append(f"<a:hd_KASOOR_DOT:1497856029474422905> **Bypass Role:** {bypass_role.mention}")
                else:
                    requirements.append(f"<a:hd_KASOOR_DOT:1497856029474422905> **Bypass Role:** <@&{bypass_role_id}>")
            except:
                requirements.append(f"<a:hd_KASOOR_DOT:1497856029474422905> **Bypass Role:** <@&{bypass_role_id}>")
        
        # Extra entries
        extra_role_id = giveaway_data.get('extra_entries_role')
        extra_count = giveaway_data.get('extra_entries_count', 1)
        if extra_role_id and extra_count > 0:
            try:
                extra_role = guild.get_role(int(extra_role_id))
                if extra_role:
                    requirements.append(f"<a:hd_KASOOR_DOT:1497856029474422905> **Extra Entries:** {extra_role.mention} (+{extra_count})")
                else:
                    requirements.append(f"<a:hd_KASOOR_DOT:1497856029474422905> **Extra Entries:** <@&{extra_role_id}> (+{extra_count})")
            except:
                requirements.append(f"<a:hd_KASOOR_DOT:1497856029474422905> **Extra Entries:** <@&{extra_role_id}> (+{extra_count})")
        
        # Add requirements if any
        if requirements:
            description += "\n\n" + "\n".join(requirements)
        
        # Add ended line with heart emoji
        description += f"\n\n<a:heart:1497856050265591960> **Ended:** <t:{timestamp_f}:f>"
# Built by Trusty X Ayaan Dev
        
        embed.description = description
        
        # Set thumbnail (logo) if provided
        if thumbnail_url:
            embed.set_thumbnail(url=thumbnail_url)
        
        # Set image (banner) if provided
        if banner_url:
            embed.set_image(url=banner_url)
        
        # Footer with proper formatting
        import datetime
# Trusty X Ayaan - discord.gg/ibadat
        end_datetime = datetime.datetime.fromtimestamp(ends_at)
        footer_text = f"Ends at • {end_datetime.strftime('%d %B %Y %H:%M')}"
        embed.set_footer(text=footer_text)
        
        return embed
    
    @staticmethod
    def create_giveaway_ended_view(prize, winners_list, host_id, guild, config, message_id, end_time):
        """Create ended giveaway embed with custom emojis"""
        
        thumbnail_url = config.get('thumbnail') if config else None
        banner_url = config.get('image') if config else None
        
        embed = discord.Embed(
            title="<:pankh_haveli:1497856147510788128> +",
            color=0x2f3136
        )
        
        # Description with custom emojis
        timestamp_r = round(end_time)
        timestamp_f = round(end_time)
        
        description = f"<a:hd_KASOOR_DOT:1497856029474422905> **Ended:** <t:{timestamp_r}:R>\n"
        description += f"<a:hd_KASOOR_DOT:1497856029474422905> **Hosted by:** <@{host_id}>\n"
        description += f"<a:hd_KASOOR_DOT:1497856029474422905> **Winners:** {', '.join([f'<@{uid}>' for uid in winners_list]) if winners_list else 'No winners'}"
        
        # Add ended line with heart emoji
        description += f"\n\n<a:heart:1497856050265591960> **Ended:** <t:{timestamp_f}:f>"
        
        embed.description = description
        
        # Set thumbnail (logo) if provided
        if thumbnail_url:
            embed.set_thumbnail(url=thumbnail_url)
        
        # Set image (banner) if provided
        if banner_url:
            embed.set_image(url=banner_url)
        
        return embed
    
    @staticmethod
    def create_winner_announcement_view(winners_list, prize):
        """Create winner announcement embed"""
        
        embed = discord.Embed(
            title="🎉 Congratulations!",
            description=f"**Winners:** {', '.join([f'<@{uid}>' for uid in winners_list])}\n**Prize:** {prize}",
            color=0x00ff00
        )
        
        return embed
    
    @staticmethod
    def create_winner_dm_view(prize, guild_name, end_time, dm_message, guild_icon_url=None):
        """Create winner DM embed"""
        
        embed = discord.Embed(
            title="🎉 You Won a Giveaway!",
            color=0x00ff00
        )
        
        description = f"**Prize:** {prize}\n"
        description += f"**Server:** {guild_name}\n"
        description += f"**Won On:** <t:{round(end_time)}:f>\n\n"
        description += dm_message
        
        embed.description = description
        
        if guild_icon_url:
            embed.set_thumbnail(url=guild_icon_url)
        
        return embed
    
    @staticmethod
    def create_no_participants_view(prize, end_time, thumbnail_url=None, banner_url=None):
        """Create no participants embed with custom emojis"""
        
        embed = discord.Embed(
            title="<:pankh_haveli:1497856147510788128> +",
            color=0xff0000
        )
        
        timestamp_r = round(end_time)
        timestamp_f = round(end_time)
        
        description = f"<a:hd_KASOOR_DOT:1497856029474422905> **Ended:** <t:{timestamp_r}:R>\n"
        description += f"<a:hd_KASOOR_DOT:1497856029474422905> **Winners:** No participants"
        
        # Add ended line with heart emoji
        description += f"\n\n<a:heart:1497856050265591960> **Ended:** <t:{timestamp_f}:f>"
        
        embed.description = description
        
        # Set thumbnail (logo) if provided
        if thumbnail_url:
            embed.set_thumbnail(url=thumbnail_url)
        
# Created by Trusty X Ayaan
        # Set image (banner) if provided
        if banner_url:
            embed.set_image(url=banner_url)
        
        return embed
