"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord 
from discord .ext import commands 
import os 
from core import Cog ,Lakshmi ,Context 
from utils .Tools import *
# Trusty X Ayaan - Krishx Dev


# Dev: Trusty X Ayaan
# Developers: Trusty X Ayaan
class Games (Cog ):
    """Lakshmi Games"""

    def __init__ (self ,client :Lakshmi ):
        self .client =client 



"""
: ! Lakshmi !
# Code by Trusty X Ayaan
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""

