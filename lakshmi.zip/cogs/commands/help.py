﻿# -*- coding: utf-8 -*-
"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord 
from discord .ext import commands 
from discord import app_commands ,Interaction 
from difflib import get_close_matches 
from contextlib import suppress 
from core import Context 
from core .Lakshmi import Lakshmi 
from core .Cog import Cog 
from utils .Tools import getConfig 
from itertools import chain 
import json 
from utils import Paginator ,DescriptionEmbedPaginator ,FieldPagePaginator ,TextPaginator 
import asyncio 
from utils .config import serverLink, invite_link, website_link, support_link 
from utils .Tools import *
from discord import ui
from utils.logger import logger

color =0x000000 
client =Lakshmi ()

# Trusty X Ayaan - discord.gg/ibadat
class HelpLayout(ui.LayoutView):
    def __init__(self, help_cog, ctx, server_prefix=None):
        super().__init__(timeout=300.0)
        self.help_cog = help_cog
        self.ctx = ctx
        self.current_page = "main"
        self.server_prefix = server_prefix or getattr(ctx, 'prefix', '!')

        self.total_commands = len(set(self.ctx.bot.walk_commands()))

        self.filtered_mapping = self.create_Lakshmi_mapping()

        self.container = ui.Container(accent_color=None)

        self.setup_main_content()

        self.add_item(self.container)

    def create_Lakshmi_mapping(self):
        """Create a filtered mapping that only includes cogs from cogs/Lakshmi directories"""
        main_menu_classes = {
            '_general', '_voice', '_welcome', 'ticket', '__sticky'
        }

        extra_menu_classes = {
            '_automod', '_antinuke', '_extra', '_fun', '_moderation', '_giveaway',
            '_leveling', '_ai', '_server', 'RoleplayHelp', 'VerificationHelp',
            '_tracking', '_logging', '_counting', '_Backup', '_crew', '_ignore'
        }

        all_allowed_classes = main_menu_classes | extra_menu_classes
        Lakshmi_mapping = {}

        for cog in self.ctx.bot.cogs.values():
            if cog and hasattr(cog, '__class__'):
                cog_class_name = cog.__class__.__name__
                if cog_class_name in all_allowed_classes and hasattr(cog, 'help_custom'):
                    Lakshmi_mapping[cog] = cog.get_commands()

        return Lakshmi_mapping

    def create_select_options(self, menu_type):
        """No select options - empty"""
        return []

    def setup_main_content(self):
        """Set up the main help content following Lakshmi style"""
        self.container.clear_items()

        prefix = getattr(self.ctx, 'prefix', '!')
        display_prefix = prefix
        if prefix.strip().startswith('<@'):
            display_prefix = f"@{self.ctx.me.display_name} "

        # Header with bot name and salute emoji
        self.container.add_item(
            ui.TextDisplay(f"# Hey, I'm Lakshmi <:0Salute:1488950898368708689>")
        )

        # Description
        self.container.add_item(
            ui.TextDisplay(
                f"A multipurpose useful bot to setup your dream community"
            )
        )

        # Server info
        self.container.add_item(
            ui.TextDisplay(
                f"My prefix for this server is `{display_prefix}`\n"
                f"Type `.help` to get details\n"
                f"Total commands: **581**"
            )
        )

        self.container.add_item(ui.Separator())

        # Main Features/Modules with custom emojis - 2 column layout
        features_text = (
            "#       **Main Features:**\n"
            "> <a:liv_glass:1491702186177204256> <:Sal_arrow2:1491702229583921162> ** Security**           <a:gawrgurafingerguns:1491702274362310676>  <:Sal_arrow2:1491702229583921162>** AI**\n"
            "> <:redglow:1491702218825531462> <:Sal_arrow2:1491702229583921162>  **Automod**          <a:male:1491702242712092682>  <:Sal_arrow2:1491702229583921162> **Backup**\n"
            ">  <a:emoji_1769409815206:1491702253394858054><:Sal_arrow2:1491702229583921162>  **Counting**           <a:ayehaye:1491702263952052264>  <:Sal_arrow2:1491702229583921162> ** Utility**\n"
            "> <a:gawrgurafingerguns:1491702209954451486> <:Sal_arrow2:1491702229583921162>   **Fun**                    <a:giveaway:1491454220442800138>   <:Sal_arrow2:1491702229583921162>  **Giveaway**\n"
            "> <a:Tickets:1491702292028592138> <:Sal_arrow2:1491702229583921162> **Tickets**               <a:crz_music:1491702314116059238>   <:Sal_arrow2:1491702229583921162> **Voice**\n"
            "> <a:FakeNitroEmoji:1491702303231840306> <:Sal_arrow2:1491702229583921162> **Leveling**             <a:fightsu:1491697136977317909>   <:Sal_arrow2:1491702229583921162>  **ignore**\n"
            "> <a:sal_cute_baby:1489101120293834972> <:Sal_arrow2:1491702229583921162> **Sticky Notes**     <a:AM_gengarBlue:1491697156439019602>  <:Sal_arrow2:1491702229583921162> **General**\n"
            "> <a:baby_swag_entry:1491702374400786503> <:Sal_arrow2:1491702229583921162> **Tracking**              <:sal_loveu:1491697181458173980>  <:Sal_arrow2:1491702229583921162> **Server**\n"
            "> <:Cute_girl_with_crown:1491697192409501847> <:Sal_arrow2:1491702229583921162> **Roleplay**              <a:sal_devilgurly:1491702405933301902>  <:Sal_arrow2:1491702229583921162>  **Guild Profile**\n"
            "> <a:Bachhii:1491702427395559525> <:Sal_arrow2:1491702229583921162> **Pfps**                     <a:sal_skull360:1491707164828373095>    <:Sal_arrow2:1491702229583921162> **<a:0demonwings:1491702437839634432>More!<a:0demonwings2:1491702447658238015>**"
        )
        self.container.add_item(ui.TextDisplay(features_text))

        self.container.add_item(ui.Separator())

        # Pro Tip section
        pro_tip_text = (
            "# <a:0demonwings:1491702437839634432>Premium<a:0demonwings2:1491702447658238015> **Pro Tip**\n"
            "Imagine with Lakshmi AI!"
        )
        self.container.add_item(
            ui.TextDisplay(pro_tip_text)
        )

        self.container.add_item(ui.Separator())

        # Links section
        invite_link = "https://discord.com/oauth2/authorize?client_id=1488832375637938227&permissions=8&integration_type=0&scope=bot"
        support_link = "https://discord.gg/ibadat"
        website_link = "https://discord.gg/ibadat"
        
        links_text = (
            "**Links**\n"
            f"[Invite me]({invite_link}) | [Support]({support_link}) | [Vote]({website_link}) | [Website]({website_link})"
        )
        self.container.add_item(ui.TextDisplay(links_text))

        self.container.add_item(ui.Separator())

        # Category dropdowns
        self.main_categories_select = ui.ActionRow(
            ui.Select(
                placeholder="📚 Select a Category",
                options=[
                    discord.SelectOption(
                        label="Welcomer",
                        value="welcomer",
                        emoji="👋"
                    ),
                    discord.SelectOption(
                        label="Security",
                        value="security",
                        emoji="<a:liv_glass:1491702186177204256>"
                    ),
                    discord.SelectOption(
                        label="AI",
                        value="ai",
                        emoji="<a:gawrgurafingerguns:1491702274362310676>"
                    ),
                    discord.SelectOption(
                        label="Automod",
                        value="automod",
                        emoji="<:redglow:1491702218825531462>"
                    ),
                    discord.SelectOption(
                        label="Backup",
                        value="backup",
                        emoji="<a:male:1491702242712092682>"
                    ),
                    discord.SelectOption(
                        label="Counting",
                        value="counting",
                        emoji="<a:emoji_1769409815206:1491702253394858054>"
                    ),
                    discord.SelectOption(
                        label="Utility",
                        value="utility",
                        emoji="<a:ayehaye:1491702263952052264>"
                    ),
                    discord.SelectOption(
                        label="Fun",
                        value="fun",
                        emoji="<a:gawrgurafingerguns:1491702209954451486>"
                    ),
                    discord.SelectOption(
                        label="Giveaway",
                        value="giveaway",
                        emoji="<a:giveaway:1491454220442800138>"
                    ),
                    discord.SelectOption(
                        label="Tickets",
                        value="tickets",
                        emoji="<a:Tickets:1491702292028592138>"
                    ),
                    discord.SelectOption(
                        label="Leveling",
                        value="leveling",
                        emoji="<a:FakeNitroEmoji:1491702303231840306>"
                    ),
                    discord.SelectOption(
                        label="Voice",
                        value="voice",
                        emoji="<a:crz_music:1491702314116059238>"
                    ),
                    discord.SelectOption(
                        label="Music",
                        value="music",
                        emoji="<a:crz_music:1491702314116059238>"
                    ),
                    discord.SelectOption(
                        label="Permit",
                        value="permit",
                        emoji="<a:fightsu:1491697136977317909>"
                    ),
                    discord.SelectOption(
                        label="Sticky Notes",
                        value="stickynotes",
                        emoji="<a:sal_cute_baby:1489101120293834972>"
                    ),
                    discord.SelectOption(
                        label="General",
                        value="general",
                        emoji="<a:AM_gengarBlue:1491697156439019602>"
                    ),
                    discord.SelectOption(
                        label="Tracking",
                        value="tracking",
                        emoji="<a:baby_swag_entry:1491702374400786503>"
                    ),
                    discord.SelectOption(
                        label="Server",
                        value="server",
                        emoji="<:sal_loveu:1491697181458173980>"
                    ),
                    discord.SelectOption(
                        label="Roleplay",
                        value="roleplay",
                        emoji="<:Cute_girl_with_crown:1491697192409501847>"
                    ),
                    discord.SelectOption(
                        label="Guild Profile",
                        value="guildprofile",
                        emoji="<a:sal_devilgurly:1491702405933301902>"
                    ),
                    discord.SelectOption(
                        label="Profile Pictures",
                        value="pfps",
                        emoji="<a:Bachhii:1491702427395559525>"
                    ),
                    discord.SelectOption(
                        label="Premium",
                        value="premium",
                        emoji="<a:sal_skull360:1491707164828373095>"
                    )
                ]
            )
        )
        self.main_categories_select.children[0].callback = self.main_category_callback
        self.container.add_item(self.main_categories_select)

        self.container.add_item(ui.Separator())

        # Footer
        self.container.add_item(
            ui.TextDisplay("Powered By Krishx Development")
        )

    async def select_callback(self, interaction: discord.Interaction):
        """No select menu - does nothing"""
        pass

    async def main_category_callback(self, interaction: discord.Interaction):
        """Handle main category selection (following stats.py pattern)"""
        if interaction.user != self.ctx.author:
            await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            return

        choice = getattr(interaction, 'data', {}).get('values', ['welcomer'])[0] if hasattr(interaction, 'data') and interaction.data else 'welcomer'

        if choice == "welcomer":
            await self.show_welcomer_content(interaction)
        elif choice == "security":
            await self.show_security_content(interaction)
        elif choice == "ai":
            await self.show_ai_content(interaction)
        elif choice == "automod":
            await self.show_automod_content(interaction)
        elif choice == "backup":
            await self.show_backup_content(interaction)
        elif choice == "counting":
            await self.show_counting_content(interaction)
        elif choice == "utility":
            await self.show_utility_content(interaction)
        elif choice == "fun":
            await self.show_fun_content(interaction)
        elif choice == "giveaway":
            await self.show_giveaway_content(interaction)
        elif choice == "tickets":
            await self.show_tickets_content(interaction)
        elif choice == "leveling":
            await self.show_leveling_content(interaction)
        elif choice == "guildprofile":
            await self.show_guildprofile_content(interaction)
        elif choice == "crypto":
            await self.show_crypto_content(interaction)
        elif choice == "premium":
            await self.show_premium_content(interaction)
        elif choice == "voice":
            await self.show_voice_content(interaction)
        elif choice == "music":
            await self.show_music_content(interaction)
        elif choice == "permit":
            await self.show_permit_content(interaction)
        elif choice == "stickynotes":
            await self.show_stickynotes_content(interaction)
        elif choice == "general":
            await self.show_general_content(interaction)
        elif choice == "tracking":
            await self.show_tracking_content(interaction)
        elif choice == "server":
            await self.show_server_content(interaction)
        elif choice == "roleplay":
            await self.show_roleplay_content(interaction)
        elif choice == "pfps":
            await self.show_pfps_content(interaction)
        elif choice == "todo":
            await self.show_todo_content(interaction)
        else:
            await interaction.response.send_message("Category not found.", ephemeral=True)

    async def extra_category_callback(self, interaction: discord.Interaction):
        """Handle extra category selection"""
        if interaction.user != self.ctx.author:
            await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            return

        choice = getattr(interaction, 'data', {}).get('values', ['home'])[0] if hasattr(interaction, 'data') and interaction.data else 'home'

        if choice == "home":
            self.setup_main_content()
            view = ui.LayoutView()
            view.add_item(self.container)
            await interaction.response.send_message(view=view, ephemeral=True)
        elif choice == "voice":
            await self.show_voice_content(interaction)
        elif choice == "permit":
            await self.show_permit_content(interaction)
        elif choice == "stickynotes":
            await self.show_stickynotes_content(interaction)
        elif choice == "general":
            await self.show_general_content(interaction)
        elif choice == "tracking":
            await self.show_tracking_content(interaction)
        elif choice == "server":
            await self.show_server_content(interaction)
        elif choice == "roleplay":
            await self.show_roleplay_content(interaction)
        elif choice == "pfps":
            await self.show_pfps_content(interaction)
        elif choice == "todo":
            await self.show_todo_content(interaction)
        else:
            await interaction.response.send_message("Category not found.", ephemeral=True)

    def setup_category_content(self, category_name):
        """Setup category content with consistent formatting"""
        self.container.clear_items()

        self.container.add_item(
            ui.TextDisplay(f"# {category_name}")
        )

        self.container.add_item(ui.Separator())

    async def show_welcomer_content(self, interaction: discord.Interaction):
        """Show the welcomer category content"""
        try:
            self.container.clear_items()

            self.container.add_item(
                ui.TextDisplay("# Greetings")
            )

            self.container.add_item(ui.Separator())

            # Greet Commands
            greet_cmds = "`greet setup`, `greet reset`, `greet channel`, `greet edit`, `greet test`, `greet config`"
            self.container.add_item(
                ui.TextDisplay(f"**Greet Commands**\n{greet_cmds}")
            )

            self.container.add_item(ui.Separator())

            self.container.add_item(
                ui.TextDisplay("Powered By Krishx Development")
            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)

        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_welcomer_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message(
                        "An error occurred while loading welcomer content.", ephemeral=True
                    )
                except:
                    pass

    async def show_security_content(self, interaction: discord.Interaction):
        """Show the security category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Security Modules"))
            self.container.add_item(ui.Separator())

            antinuke_cmds = "`antinuke`, `antinuke wallon`, `antinuke autorecovery`, `antinuke walloff`, `antinuke manage`, `antinuke wizard`, `antinuke logging`, `antinuke whitelist`, `antinuke betrayalguard`, `antinuke logdisable`, `antinuke zplus`, `antinuke limit`, `antinuke enable`, `antinuke reset`, `antinuke trustlimit`, `antinuke disable`"
            self.container.add_item(ui.TextDisplay(f"**Antinuke**\n{antinuke_cmds}"))

            mainrole_cmds = "`mainrole`, `mainrole add`, `mainrole show`, `mainrole reset`, `mainrole remove`"
            self.container.add_item(ui.TextDisplay(f"**Mainrole**\n{mainrole_cmds}"))

            panicmode_cmds = "`panicmode`, `panicmode enable`, `panicmode disable`, `panicmode reset`, `panicmode set`"
            self.container.add_item(ui.TextDisplay(f"**Panicmode**\n{panicmode_cmds}"))

            self.container.add_item(ui.Separator())
            self.container.add_item(ui.TextDisplay("Powered By Krishx Development"))

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)

        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_security_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading security content.", ephemeral=True)
                except:
                    pass

    async def show_ai_content(self, interaction: discord.Interaction):
        """Show the AI category content"""
        try:
            self.container.clear_items()

            self.container.add_item(
                ui.TextDisplay("# AI Commands")
            )

            self.container.add_item(ui.Separator())

            commands_text = "`ai activate`, `ai deactivate`, `ai conversation-clear`, `ai personality`, `ai conversation-stats`, `ai ask`, `ai database-clear`, `ai roleplay-enable`, `ai roleplay-disable`"
            self.container.add_item(
                ui.TextDisplay(commands_text)
            )

            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)

        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_ai_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message(
                        "An error occurred while loading AI content.", ephemeral=True
                    )
                except:
                    pass

    async def show_automod_content(self, interaction: discord.Interaction):
        """Show the automod category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Automod"))
            self.container.add_item(ui.Separator())

            automod_cmds = "`automod`, `automod unignore`, `automod unignore role`, `automod unignore channel`, `automod unignore user`, `automod wizard`, `automod manage`, `automod punishment`, `automod disable`, `automod automute`, `automod automute disable`, `automod automute set`, `automod logging`, `automod reset`, `automod heat`, `automod heat filters`, `automod heat set`, `automod ignore`, `automod ignore reset`, `automod ignore channel`, `automod ignore show`, `automod ignore role`, `automod ignore user`, `automod config`, `automod enable`"
            self.container.add_item(ui.TextDisplay(f"**Automod**\n{automod_cmds}"))

            blword_cmds = "`blword`, `blword add`, `blword remove`, `blword wlchannel`, `blword wlchannel remove`, `blword wlchannel add`, `blword wlchannel reset`, `blword wlchannel show`, `blword show`, `blword wlrole`, `blword wlrole remove`, `blword wlrole add`, `blword wlrole reset`, `blword wlrole show`, `blword punish`, `blword punish show`, `blword punish kick`, `blword punish reset`, `blword punish ban`, `blword punish mute`, `blword reset`"
            self.container.add_item(ui.TextDisplay(f"**Word Blacklist**\n{blword_cmds}"))

            self.container.add_item(ui.Separator())
            self.container.add_item(ui.TextDisplay("Powered By Krishx Development"))

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)

        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_automod_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading automod content.", ephemeral=True)
                except:
                    pass

    async def show_permit_content(self, interaction: discord.Interaction):
        """Show the permit category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Permit Commands"))
            self.container.add_item(ui.Separator())

            extraowner_cmds = "`extraowner`, `extraowner add`, `extraowner reset`, `extraowner show`, `extraowner remove`"
            self.container.add_item(ui.TextDisplay(f"**Extraowner**\n{extraowner_cmds}"))

            trusted_cmds = "`trusted`, `trusted show`, `trusted remove`, `trusted add`, `trusted reset`"
            self.container.add_item(ui.TextDisplay(f"**Trusted**\n{trusted_cmds}"))

            topcheck_cmds = "`topcheck`, `topcheck enable`, `topcheck disable`"
            self.container.add_item(ui.TextDisplay(f"**Topcheck**\n{topcheck_cmds}"))

            ignore_cmds = "`ignore`, `ignore user`, `ignore user add`, `ignore user reset`, `ignore user show`, `ignore user remove`, `ignore bypass`, `ignore bypass reset`, `ignore bypass add`, `ignore bypass remove`, `ignore bypass show`, `ignore role`, `ignore role show`, `ignore role remove`, `ignore role add`, `ignore role reset`, `ignore command`, `ignore command show`, `ignore command add`, `ignore command remove`, `ignore command reset`, `ignore channel`, `ignore channel reset`, `ignore channel show`, `ignore channel remove`, `ignore channel add`"
            self.container.add_item(ui.TextDisplay(f"**Ignore**\n{ignore_cmds}"))

            self.container.add_item(ui.Separator())
            self.container.add_item(ui.TextDisplay("Powered By Krishx Development"))

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_permit_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading permit content.", ephemeral=True)
                except:
                    pass

    async def show_general_content(self, interaction: discord.Interaction):
        """Show the general category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# General Commands"))
            self.container.add_item(ui.Separator())

            basic_cmds = "`afk`, `membercount`, `boostcount`, `joinedat`, `serverinfo`, `userinfo`, `channelinfo`, `roleinfo`, `avatar`, `banner`, `servericon`, `serverbanner`, `profile`, `vote`"
            self.container.add_item(ui.TextDisplay(f"**Basic Commands**\n{basic_cmds}"))

            bot_stats_cmds = "`stats`, `ping`, `dbstats`, `uptime`, `users`"
            self.container.add_item(ui.TextDisplay(f"**Bot Stats**\n{bot_stats_cmds}"))

            list_cmds = "`list`, `list inrole`, `list users`, `list allusers`, `list activedeveloper`, `list emojis`, `list invoice`, `list bans`, `list bots`, `list admins`, `list early`, `list joinedat`, `list servers`, `list mods`, `list createdat`, `list roles`, `list boosters`"
            self.container.add_item(ui.TextDisplay(f"**List Commands**\n{list_cmds}"))

            self.container.add_item(ui.Separator())
            self.container.add_item(ui.TextDisplay("Powered By Krishx Development"))

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_general_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading general content.", ephemeral=True)
                except:
                    pass

    async def show_backup_content(self, interaction: discord.Interaction):
        """Show the backup category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Backup Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`backup`, `backup create`, `backup list`, `backup delete`, `backup info`, `backup transfer`, `backup preview`, `backup export`, `backup import`, `backup verify`, `backup stats`, `backup load`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_backup_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading backup content.", ephemeral=True)
                except:
                    pass

    async def show_counting_content(self, interaction: discord.Interaction):
        """Show the counting category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Counting Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`counting config`, `counting enable`, `counting disable`, `counting channel`, `counting reset`, `counting leaderboard`, `counting global`, `counting stats`, `counting achievements`, `counting info`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_counting_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading counting content.", ephemeral=True)
                except:
                    pass

    async def show_utility_content(self, interaction: discord.Interaction):
        """Show the utility category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Utility Commands"))
            self.container.add_item(ui.Separator())

            media_cmds = "`media`, `media show`, `media bypass`, `media bypass reset`, `media bypass show`, `media bypass add`, `media bypass remove`, `media reset`, `media remove`, `media add`"
            self.container.add_item(ui.TextDisplay(f"**Media Commands**\n{media_cmds}"))

            sticky_cmds = "`sticky`, `sticky add`, `sticky remove`, `sticky bump`, `sticky channel`, `sticky channel remove`, `sticky channel add`, `sticky show`, `sticky reset`"
            self.container.add_item(ui.TextDisplay(f"**Sticky Message**\n{sticky_cmds}"))

            giveaway_cmds = "`gcreate`, `gend`, `greroll`, `glist`, `gdelete`"
            self.container.add_item(ui.TextDisplay(f"**Giveaways**\n{giveaway_cmds}"))

            self.container.add_item(ui.Separator())
            self.container.add_item(ui.TextDisplay("Powered By Krishx Development"))

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_utility_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading utility content.", ephemeral=True)
                except:
                    pass

    async def show_fun_content(self, interaction: discord.Interaction):
        """Show the fun category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Fun Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`compliment`, `translate`, `howgay`, `lesbian`, `cute`, `intelligence`, `horny`, `gif`, `iplookup`, `weather`, `spank`, `8ball`, `truth`, `dare`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_fun_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading fun content.", ephemeral=True)
                except:
                    pass

    async def show_giveaway_content(self, interaction: discord.Interaction):
        """Show the giveaway category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Giveaway Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`gstart`, `gend`, `greroll`, `gwya`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_giveaway_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading giveaway content.", ephemeral=True)
                except:
                    pass

    async def show_tickets_content(self, interaction: discord.Interaction):
        """Show the tickets category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Tickets Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`ticket`, `ticket setup`, `ticket reset`, `ticket close`, `ticket transcript`, `ticket add`, `ticket remove`, `ticket rename`, `ticket category-add`, `ticket category-remove`, `ticket category-list`, `ticket category-default`, `ticket panel-send`, `ticket claim`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_tickets_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading tickets content.", ephemeral=True)
                except:
                    pass

    async def show_leveling_content(self, interaction: discord.Interaction):
        """Show the leveling category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Leveling Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`level status`, `level channel`, `level message`, `level desc`, `level color`, `level thumbnail`, `level image`, `level clearimage`, `level xprange`, `level multiplier`, `level addreward`, `level removereward`, `level rewards`, `level setxp`, `level preview`, `level xpboost`, `level xpboost add`, `level xpboost remove`, `level xpboost list`, `level blacklist`, `level blacklist channel`, `level blacklist role`, `level unblacklist`, `level unblacklist channel`, `level unblacklist role`, `level stats`, `level leaderboard`, `level reset`, `level reset user`, `level reset all`, `level placeholders`, `level rank`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_leveling_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading leveling content.", ephemeral=True)
                except:
                    pass

    async def show_voice_content(self, interaction: discord.Interaction):
        """Show the voice category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Voice Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`voice`, `voice kick`, `voice kickall`, `voice mute`, `voice muteall`, `voice unmute`, `voice unmuteall`, `voice deafen`, `voice deafenall`, `voice undeafen`, `voice undeafenall`, `voice move`, `voice moveall`, `voice pull`, `voice pullall`, `voice lock`, `voice unlock`, `voice private`, `voice unprivate`, `vcrole add`, `vcrole remove`, `vcrole config`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_voice_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading voice content.", ephemeral=True)
                except:
                    pass

    async def show_music_content(self, interaction: discord.Interaction):
        """Show the music category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# 🎵 Music Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`play`, `nowplaying`, `pause`, `resume`, `skip`, `stop`, `queue`, `clear`, `volume`, `join`, `leave`, `loop`, `shuffle`, `seek`, `remove`, `grab`, `lyrics`, `search`, `previous`, `rejoin`, `similar`, `autoplay`, `musicstatus`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())
# Built by Trusty X Ayaan Dev

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_music_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading music content.", ephemeral=True)
                except:
                    pass

    async def show_ignore_content(self, interaction: discord.Interaction):
        """Show the ignore category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Ignore Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`ignore`, `ignore command add`, `ignore command remove`, `ignore command show`, `ignore channel add`, `ignore channel remove`, `ignore channel show`, `ignore user add`, `ignore user remove`, `ignore user show`, `ignore bypass add`, `ignore bypass show`, `ignore bypass remove`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_ignore_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading ignore content.", ephemeral=True)
                except:
                    pass

    async def show_stickynotes_content(self, interaction: discord.Interaction):
        """Show the stickynotes category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# StickyNotes Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`sticky setup`, `sticky remove`, `sticky list`, `sticky toggle`, `sticky edit`, `sticky config`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_stickynotes_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading stickynotes content.", ephemeral=True)
                except:
                    pass

    async def show_general_content(self, interaction: discord.Interaction):
        """Show the general category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# General Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`status`, `afk`, `avatar`, `banner`, `servericon`, `membercount`, `poll`, `hack`, `token`, `users`, `wizz`, `urban`, `rickroll`, `hash`, `snipe`, `editsnipe`, `list inrole`, `list emojis`, `list bots`, `list admins`, `list invoice`, `list mods`, `list early`, `list activedeveloper`, `list createpos`, `list roles`, `calc`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_general_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading general content.", ephemeral=True)
                except:
                    pass

    async def show_tracking_content(self, interaction: discord.Interaction):
        """Show the tracking category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Tracking Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`tracking`, `tracking enable`, `tracking disable`, `tracking status`, `tracking setup`, `tracking wipe`, `tracking export`, `tracking import`, `tracking messages`, `tracking invites`, `tracking leaderboard`, `tracking messagelb`, `tracking dailylb`, `tracking invitelb`, `tracking addmessages`, `tracking resetmessages`, `tracking addinvites`, `tracking resetinvites`, `tracking setlogchannel`, `tracking myinvites`, `tracking resetall`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_tracking_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading tracking content.", ephemeral=True)
                except:
                    pass

    async def show_server_content(self, interaction: discord.Interaction):
        """Show the server category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Server Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`setup`, `setup create <name>`, `setup delete <name>`, `setup list`, `setup girl`, `setup friend`, `setup vip`, `setup guest`, `setup config`, `setup reset`, `girl`, `friend`, `vip`, `guest`, `autorole bots add`, `autorole bots remove`, `autorole bots`, `autorole config`, `autorole humans add`, `autorole humans remove`, `autorole humans`, `autorole reset all`, `autorole reset bots`, `autorole reset humans`, `autorole`, `autoresponder`, `autoresponder create`, `autoresponder delete`, `autoresponder edit`, `autoresponder config`, `react`, `react add`, `react remove`, `react list`, `react reset`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )

            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_server_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading server content.", ephemeral=True)
                except:
                    pass

                    pass

    async def show_roleplay_content(self, interaction: discord.Interaction):
        """Show the roleplay category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Roleplay Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`hug`, `kiss`, `cuddle`, `pat`, `slap`, `tickle`, `poke`, `wave`, `dance`, `cry`, `laugh`, `smile`, `blush`, `wink`, `thumbsup`, `clap`, `bow`, `salute`, `facepalm`, `shrug`, `sleep`, `eat`, `drink`, `run`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )
            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_roleplay_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading roleplay content.", ephemeral=True)
                except:
                    pass

    async def show_guildprofile_content(self, interaction: discord.Interaction):
        """Show the bot guildprofile category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Bot GuildProfile Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`lovsetbio`, `lovsetavatar`, `lovsetbanner`, `lovsetname`, `lovsetclear`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )
            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_guildprofile_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading guildprofile content.", ephemeral=True)
                except:
                    pass

    async def show_guildtag_content(self, interaction: discord.Interaction):
        """Show the guildtag category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# GuildTag Commands"))
            self.container.add_item(ui.Separator())

            description = "**Manage Discord Guild Tags and reward users who adopt your server's tag!**\n\n**Main Commands:**"
            self.container.add_item(ui.TextDisplay(description))

            commands_text = (
                "`guildtag enable` - Enable the guild tag system\n"
                "`guildtag disable` - Disable the guild tag system\n"
                "`guildtag config` - Show current configuration\n"
                "`guildtag channel set <channel>` - Set welcome message channel\n"
                "`guildtag channel remove` - Remove welcome channel\n"
                "`guildtag role add <role>` - Add a reward role\n"
                "`guildtag role remove <role>` - Remove a reward role\n"
                "`guildtag role list` - List all reward roles\n"
                "`guildtag message <text>` - Set welcome message\n"
                "`guildtag test [user]` - Test guild tag detection\n"
                "`guildtag grant [user]` - Manually grant rewards\n"
                "`guildtag list` - List users with guild tag\n"
                "`guildtag check` - Check all members for tags"
            )
            self.container.add_item(ui.TextDisplay(commands_text))

            self.container.add_item(ui.Separator())

            aliases_text = "**Aliases:** `gt`"
            self.container.add_item(ui.TextDisplay(aliases_text))

            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )
            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_guildtag_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading guildtag content.", ephemeral=True)
                except:
                    pass

    async def show_pfps_content(self, interaction: discord.Interaction):
        """Show the profile pictures category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Profile Pictures Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`pfp female`, `pfp male`, `pfp matching`, `pfp anime`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )
            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_pfps_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading pfps content.", ephemeral=True)
                except:
                    pass

    async def show_todo_content(self, interaction: discord.Interaction):
        """Show the todo category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# ToDo Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`todo list`, `todo clear`, `todo add`, `todo remove`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )
            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_todo_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading todo content.", ephemeral=True)
                except:
                    pass

    async def show_crypto_content(self, interaction: discord.Interaction):
        """Show the crypto category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Crypto Commands"))
            self.container.add_item(ui.Separator())
            commands_text = "`crypto balance`, `crypto convert`, `crypto transaction`, `crypto news`, `crypto price`, `crypto gainers`, `crypto losers`"
            self.container.add_item(ui.TextDisplay(commands_text))
            self.container.add_item(ui.Separator())

            self.container.add_item(

                ui.TextDisplay("Powered By Krishx Development")

            )
            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_crypto_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading crypto content.", ephemeral=True)
                except:
                    pass

    async def show_premium_content(self, interaction: discord.Interaction):
        """Show the premium category content"""
        try:
            self.container.clear_items()
            self.container.add_item(ui.TextDisplay("# Premium Commands"))
            self.container.add_item(ui.Separator())
            
            # Premium Giveaway Commands
            premium_cmds = "`greactemoji`, `glist`, `gdelete`, `glastwin`, `glogo`, `gbanner`"
            self.container.add_item(
                ui.TextDisplay(f"**Premium Giveaway Commands**\n{premium_cmds}")
            )
            
            # Premium System Commands
            system_cmds = "`np add` (Owner only)"
            self.container.add_item(
                ui.TextDisplay(f"**Premium System Commands**\n{system_cmds}")
            )

            # Premium Bot Profile Commands
            profile_cmds = "`lovsetbio`, `lovsetavatar`, `lovsetbanner`, `lovsetname`, `lovsetclear`"
            self.container.add_item(
                ui.TextDisplay(f"**Premium Bot Profile Commands**\n{profile_cmds}\n*Requires `premiumguild` activation per server*")
            )
            
            self.container.add_item(ui.Separator())

            self.container.add_item(
                ui.TextDisplay("Powered By Krishx Development")
            )
            
            if not interaction.response.is_done():
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.response.send_message(view=view, ephemeral=True)
            else:
                view = ui.LayoutView()
                view.add_item(self.container)
                await interaction.followup.send(view=view, ephemeral=True)
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_premium_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message("An error occurred while loading premium content.", ephemeral=True)
                except:
                    pass

    def setup_category_content(self, category_name):
        """No category content - does nothing"""
        pass

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Check if the user can interact with this view"""
        return interaction.user == self.ctx.author

    async def on_timeout(self):
        """Handle timeout"""
        pass

    async def category_select_callback(self, interaction: discord.Interaction):
        """Handle category selection from dropdown."""
        try:
            if interaction.user != self.ctx.author:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        "You must run this command to interact with it.", ephemeral=True
                    )
                return

            if not interaction.data or 'values' not in interaction.data:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        "Invalid interaction data.", ephemeral=True
                    )
                return

            selected_category = interaction.data['values'][0]

            target_cog = None
            for cog_name, cog in self.bot.cogs.items():
                try:
                    if hasattr(cog, 'help_custom'):
                        _, label, _ = cog.help_custom()
                        if label == selected_category:
                            target_cog = cog
                            break
                except Exception:
                    continue

            if target_cog:
                await self.show_category_content(interaction, target_cog, selected_category)
            else:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        "Category not found.", ephemeral=True
                    )
        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Select menu interaction error: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message(
                        "An error occurred while processing your selection.", ephemeral=True
                    )
                except:
                    pass

    async def show_category_content(self, interaction: discord.Interaction, cog, category_name):
        """Show the content for a selected category."""
        try:
            emoji, label, description = cog.help_custom()

            commands = []
            if hasattr(cog, 'get_commands'):
                try:
                    commands = cog.get_commands()
                except Exception:
                    commands = []
            else:
                try:
                    commands = [cmd for cmd in cog.get_commands() if not cmd.hidden]
                except Exception:
                    commands = []

            self.container.clear()

            self.container.add_item(
                ui.TextDisplay(f"**{emoji} {label}**")
            )

            self.container.add_item(ui.Separator())

            if commands:
                commands_list = []
                for cmd in commands:
                    try:
                        if cmd.name.startswith('__') and cmd.name.endswith('__'):
                            continue

                        cmd_help = getattr(cmd, 'help', None) or getattr(cmd, 'description', None) or "No description available"

                        if hasattr(cmd, 'commands') and cmd.commands:
                            subcommands = [subcmd.name for subcmd in cmd.commands if not subcmd.name.startswith('__')]
                            if subcommands:
                                subcmd_text = ", ".join(subcommands[:5])  # Show first 5 subcommands
                                if len(cmd.commands) > 5:
                                    subcmd_text += f" (+{len(cmd.commands) - 5} more)"
                                commands_list.append(f"`{cmd.name}` - {subcmd_text}")
                            else:
                                commands_list.append(f"`{cmd.name}` - {cmd_help[:60]}...")
                        else:
                            if len(cmd_help) > 60:
                                cmd_help = cmd_help[:57] + "..."
                            commands_list.append(f"`{cmd.name}` - {cmd_help}")
                    except Exception:
                        continue

                commands_text = "\n".join(commands_list) if commands_list else "No commands available for this category."
            else:
                commands_text = "No commands available for this category."

            self.container.add_item(
                ui.TextDisplay(commands_text)
            )

            embed = discord.Embed(
                title="Help - Category Details",
                description="",
                color=0x000000
            )

            if not interaction.response.is_done():
                await interaction.response.edit_message(embed=embed, view=self)
            else:
                await interaction.edit_original_response(embed=embed, view=self)

        except discord.NotFound:
            pass
        except discord.InteractionResponded:
            pass
        except Exception as e:
            logger.error("HELP", f"Error in show_category_content: {e}")
            if not interaction.response.is_done():
                try:
                    await interaction.response.send_message(
                        "An error occurred while loading category content.", ephemeral=True
                    )
                except:
                    pass

class HelpCommand (commands .HelpCommand ):

  async def send_ignore_message (self ,ctx ,ignore_type :str ):

    if ignore_type =="channel":
      await ctx .reply (f"This channel is ignored.",mention_author =False )
    elif ignore_type =="command":
      await ctx .reply (f"{ctx.author.mention} This Command, Channel, or You have been ignored here.",delete_after =6 )
    elif ignore_type =="user":
      await ctx .reply (f"You are ignored.",mention_author =False )

  async def on_help_command_error (self ,ctx ,error ):
    if isinstance (error ,commands .CommandNotFound ):
      embed =discord .Embed (
      color =0x000000 ,
      description =f"No command or category named `{ctx.invoked_with}` found."
      )
      embed .set_author (name ="Command Not Found",icon_url =ctx .bot .user .avatar .url )
      embed .set_footer (text =f"Use {ctx.prefix}help to see all commands")
      await ctx .reply (embed =embed ,delete_after =10 )
    else :

      await ctx .reply ("An error occurred while processing the help command.",delete_after =10 )

  def command_not_found (self ,string :str )->str :
    return f"No command called `{string}` found."

  def create_Lakshmi_mapping (self ,mapping ):
    """Create a filtered mapping that only includes cogs from cogs/Lakshmi directories"""
    Lakshmi_mapping ={}

    allowed_cog_classes ={

    '_general','_voice','_welcome','ticket','__sticky','__boost',
    '_automod','_antinuke','_music','_extra','_fun','_moderation','_giveaway',

    '_leveling','_ai','_server','RoleplayHelp','VerificationHelp',
    '_tracking','_logging','_counting','_Backup','_crew','_ignore'
    }

    for cog ,commands in mapping .items ():
      if cog and hasattr (cog ,'__class__'):
        cog_class_name =cog .__class__ .__name__ 

        if cog_class_name in allowed_cog_classes and hasattr (cog ,'help_custom'):
          Lakshmi_mapping [cog ]=commands 

    return Lakshmi_mapping 

  async def send_bot_help (self ,mapping ):
    ctx =self .context 
    check_ignore =await ignore_check ().predicate (ctx )
    check_blacklist =await blacklist_check ().predicate (ctx )

    if not check_blacklist :
      return 

    if not check_ignore :
      await self .send_ignore_message (ctx ,"command")
      return 

    from utils.Tools import getConfig
# © Trusty X Ayaan Development
    server_data = await getConfig(ctx.guild.id) if ctx.guild else {}
    server_prefix = server_data.get('prefix', getattr(ctx, 'prefix', '!')) if ctx.guild else '!'

    view = HelpLayout(self, ctx, server_prefix)
    await ctx.send(view=view)

  async def send_command_help (self ,command ):
    ctx =self .context 
    check_ignore =await ignore_check ().predicate (ctx )
    check_blacklist =await blacklist_check ().predicate (ctx )

    if not check_blacklist :
      return 

    if not check_ignore :
      self .send_ignore_message (ctx ,"command")
      return 

    view = ui.LayoutView()
    container = ui.Container(accent_color=None)

    container.add_item(ui.TextDisplay(f"**{command.qualified_name.title()}**"))

    description = command.help or command.description or "No description available"
    container.add_item(ui.TextDisplay(f"```xml\n<[] = optional | �� = required\nDon't type these while using Commands>```\n>>> {description}"))

    if command.aliases:
      aliases_text = ", ".join(command.aliases)
      container.add_item(ui.TextDisplay(f"**Aliases:** {aliases_text}"))

    usage_args = command.signature if command.signature else ""
    container.add_item(ui.TextDisplay(f"**Usage:** {command.qualified_name} {usage_args}"))

    view.add_item(container)
    await self .context .reply (view=view ,mention_author =False )

  def get_command_signature (self ,command ):
    parent =command .full_parent_name 
    if len (command .aliases )>0 :
      aliases =' | '.join (command .aliases )
      fmt =f'[{command.name} | {aliases}]'
      if parent :
        fmt =f'{parent}'
      alias =f'[{command.name} | {aliases}]'
    else :
      alias =command .name if not parent else f'{parent} {command.name}'
    return f'{alias} {command.signature}'

  def common_command_formatting (self ,embed_like ,command ):
    embed_like .title =self .get_command_signature (command )
    if command .description :
      embed_like .description =f'{command.description}\n\n{command.help}'
    else :
      embed_like .description =command .help or 'No help found...'

  async def send_group_help (self ,group ):
    ctx =self .context 
    check_ignore =await ignore_check ().predicate (ctx )
    check_blacklist =await blacklist_check ().predicate (ctx )

    if not check_blacklist :
      return 

    if not check_ignore :
      await self .send_ignore_message (ctx ,"command")
      return 

    commands_list =[f"? **{self.context.prefix}{cmd.qualified_name}**" for cmd in group .commands ]

    if not commands_list :
      return 

    items_per_page =10 
    total_pages =(len (commands_list )+items_per_page -1 )//items_per_page 
    current_page =1 

    async def create_page_view (page :int ):
      start_index =(page -1 )*items_per_page 
      end_index =min (start_index +items_per_page ,len (commands_list ))
      page_commands =commands_list [start_index :end_index ]

      layout_view =ui .LayoutView (timeout =300.0 )
      container =ui .Container (accent_color =None )

      container .add_item (ui .TextDisplay (f"# **{group.qualified_name.title()} Commands [{len(commands_list)}]**"))
      container .add_item (ui .Separator ())

      commands_text ="\n".join (page_commands )
      container .add_item (ui .TextDisplay (commands_text ))

      if total_pages >1 :
        container .add_item (ui .Separator ())
        container .add_item (ui .TextDisplay (f"**Page {page} of {total_pages}**"))

        button_row =ui .ActionRow (
          ui .Button (
            label ="",
            emoji ="⏮️",
            custom_id ="help_first",
            style =discord .ButtonStyle .secondary ,
            disabled =(page ==1 )
          ),
          ui .Button (
            label ="",
            emoji ="◀️",
            custom_id ="help_back",
            style =discord .ButtonStyle .secondary ,
            disabled =(page ==1 )
          ),
          ui .Button (
            label ="",
            emoji ="▶️",
            custom_id ="help_next",
            style =discord .ButtonStyle .secondary ,
            disabled =(page ==total_pages )
          ),
          ui .Button (
            label ="",
            emoji ="⏭️",
            custom_id ="help_last",
            style =discord .ButtonStyle .secondary ,
            disabled =(page ==total_pages )
          )
        )
        container .add_item (button_row )

      layout_view .add_item (container )
      return layout_view 

    initial_view =await create_page_view (current_page )
    msg =await ctx .reply (view =initial_view ,mention_author =False )

    if total_pages >1 :
      def check (interaction :discord .Interaction ):
        return (interaction .user .id ==ctx .author .id and 
                interaction .message and 
                interaction .message .id ==msg .id )

      while True :
        try :
          interaction =await self .context .bot .wait_for ('interaction',timeout =300.0 ,check =check )
          await interaction .response .defer ()

          custom_id =interaction .data .get ('custom_id')

          if custom_id =='help_first':
            current_page =1 
          elif custom_id =='help_back':
            if current_page >1 :
              current_page -=1 
          elif custom_id =='help_next':
            if current_page <total_pages :
              current_page +=1 
          elif custom_id =='help_last':
            current_page =total_pages 

          updated_view =await create_page_view (current_page )
          await interaction .edit_original_response (view =updated_view )

        except :
          try :
            expired_view =ui .LayoutView ()
            expired_container =ui .Container (accent_color =None )
            expired_container .add_item (ui .TextDisplay ("# Container Expired\nPlease use the command again"))
            expired_view .add_item (expired_container )
            await msg .edit (view =expired_view )
          except :
            pass 
          break

  async def send_cog_help (self ,cog ):
    ctx =self .context 
    check_ignore =await ignore_check ().predicate (ctx )
    check_blacklist =await blacklist_check ().predicate (ctx )

    if not check_blacklist :
      return 

    if not check_ignore :
      await self .send_ignore_message (ctx ,"command")
      return 

    entries =[(
    f"? `{self.context.prefix}{cmd.qualified_name}`",
    f"{cmd.description or cmd.short_doc or 'No description provided...'}\n\u200b"
    )for cmd in cog .get_commands ()]
    paginator =Paginator (source =FieldPagePaginator (
    entries =entries ,
    title =f"{cog.qualified_name.title()} ({len(cog.get_commands())})",
    description ="< > Duty | [ ] Optional\n\n",
    color =color ,
    per_page =4 ),
    ctx =self .context )
    await paginator .paginate ()

class Help (Cog ,name ="help"):

  def __init__ (self ,client :Lakshmi ):
    self .bot =client 
    self ._original_help_command =client .help_command 
    attributes ={
    'name':"help",
    'aliases':['h'],
    'help':'Shows help about bot, a command or a category'
    }
    client .help_command =HelpCommand (command_attrs =attributes )
    client .help_command .cog =self 

  async def cog_unload (self ):
    self .help_command =self ._original_help_command 

"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""









