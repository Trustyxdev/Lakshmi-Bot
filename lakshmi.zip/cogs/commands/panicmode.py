"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
from discord.ext import commands
import aiosqlite
# Code by Trusty X Ayaan


# Built by Trusty X Ayaan Dev
class PanicMode(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/panicmode.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS panicmode (
                guild_id INTEGER PRIMARY KEY,
                enabled BOOLEAN DEFAULT 0,
                action TEXT DEFAULT 'lockdown'
            )
        ''')
        await self.db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000,
            **kwargs
        )
        return embed

    @commands.hybrid_group(name='panicmode', help='Manage panic mode')
    @commands.has_permissions(administrator=True)
    async def panicmode(self, ctx):
        if ctx.invoked_subcommand is None:
            async with self.db.execute('SELECT enabled, action FROM panicmode WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                row = await cursor.fetchone()
            
            enabled = row[0] if row else False
            action = row[1] if row else 'lockdown'
            
            embed = self.create_embed(
                title="Panic Mode",
                description=f"Status: {'Enabled' if enabled else 'Disabled'}\nAction: {action}"
            )
            await ctx.send(embed=embed)

    @panicmode.command(name='set', help='Set panic mode action')
    @commands.has_permissions(administrator=True)
    async def panicmode_set(self, ctx, action: str):
        if action not in ['lockdown', 'mute', 'ban']:
            embed = self.create_embed(title="Error", description="Action must be: lockdown, mute, or ban")
            return await ctx.send(embed=embed)
        
        await self.db.execute(
            'INSERT OR REPLACE INTO panicmode (guild_id, action) VALUES (?, ?)',
            (ctx.guild.id, action)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description=f"Panic mode action set to {action}")
        await ctx.send(embed=embed)

    @panicmode.command(name='enable', help='Enable panic mode')
    @commands.has_permissions(administrator=True)
    async def panicmode_enable(self, ctx):
        await self.db.execute(
            'INSERT OR REPLACE INTO panicmode (guild_id, enabled) VALUES (?, ?)',
            (ctx.guild.id, True)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Panic mode enabled")
        await ctx.send(embed=embed)

    @panicmode.command(name='disable', help='Disable panic mode')
    @commands.has_permissions(administrator=True)
    async def panicmode_disable(self, ctx):
        await self.db.execute(
            'INSERT OR REPLACE INTO panicmode (guild_id, enabled) VALUES (?, ?)',
            (ctx.guild.id, False)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Panic mode disabled")
        await ctx.send(embed=embed)

    @panicmode.command(name='reset', help='Reset panic mode')
    @commands.has_permissions(administrator=True)
    async def panicmode_reset(self, ctx):
        await self.db.execute('DELETE FROM panicmode WHERE guild_id = ?', (ctx.guild.id,))
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Panic mode reset")
# Developers: Trusty X Ayaan
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(PanicMode(bot))
