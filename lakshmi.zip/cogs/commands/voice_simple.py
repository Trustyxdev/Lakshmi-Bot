"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import asyncio
import yt_dlp
import os
from discord.ext import commands
from core import Cog, Context


# Trusty X Ayaan - discord.gg/ibadat
class MusicView(discord.ui.View):
    """Clean music player buttons — ⏮ ⏸ ⏭ ❤ ⏹"""

    def __init__(self, cog, ctx, song: dict):
        super().__init__(timeout=300)
        self.cog  = cog
        self.ctx  = ctx
        self.song = song

    def _check(self, interaction: discord.Interaction) -> bool:
        return interaction.user == self.ctx.author

    @discord.ui.button(label="⏮", style=discord.ButtonStyle.secondary)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self._check(interaction):
            return await interaction.response.send_message("❌ Only the requester can use this!", ephemeral=True)
        vc = self.ctx.voice_client
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
            await interaction.response.send_message("⏮ Restarting...", ephemeral=True)
            await self.cog._play_song(self.ctx, self.song)
        else:
            await interaction.response.send_message("❌ Nothing is playing!", ephemeral=True)

    @discord.ui.button(label="⏸", style=discord.ButtonStyle.secondary)
    async def pause_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self._check(interaction):
            return await interaction.response.send_message("❌ Only the requester can use this!", ephemeral=True)
        vc = self.ctx.voice_client
        if vc and vc.is_playing():
            vc.pause()
            button.label = "▶"
            await interaction.response.edit_message(view=self)
        elif vc and vc.is_paused():
            vc.resume()
            button.label = "⏸"
            await interaction.response.edit_message(view=self)
        else:
            await interaction.response.send_message("❌ Nothing is playing!", ephemeral=True)

    @discord.ui.button(label="⏭", style=discord.ButtonStyle.secondary)
    async def skip_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self._check(interaction):
            return await interaction.response.send_message("❌ Only the requester can use this!", ephemeral=True)
        vc = self.ctx.voice_client
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
            await interaction.response.send_message("⏭ Skipped!", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Nothing is playing!", ephemeral=True)

    @discord.ui.button(label="❤", style=discord.ButtonStyle.danger)
    async def like_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        _, title = self.cog._split(self.song["full_title"])
        await interaction.response.send_message(f"❤ **{title}** saved to favourites!", ephemeral=True)

    @discord.ui.button(label="⏹", style=discord.ButtonStyle.secondary)
    async def stop_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self._check(interaction):
            return await interaction.response.send_message("❌ Only the requester can use this!", ephemeral=True)
        vc = self.ctx.voice_client
        if vc:
            self.cog.queue.clear()
            self.cog.current = None
            vc.stop()
            # Send stopped layout
            layout = MusicStoppedLayout()
            await interaction.response.edit_message(view=layout)
        else:
            await interaction.response.send_message("❌ Not in voice!", ephemeral=True)


class MusicStoppedLayout(discord.ui.LayoutView):
    """Stopped state layout"""
    def __init__(self):
        super().__init__(timeout=60)
        container = discord.ui.Container(accent_color=None)
        container.add_item(discord.ui.TextDisplay("## ⏹ Stopped"))
        container.add_item(discord.ui.TextDisplay("Playback stopped and queue cleared."))
        self.add_item(container)


class SimilarSongsView(discord.ui.View):
    """Paginated view for similar songs with selection"""
    
    def __init__(self, cog, ctx, songs_list: list, artist: str):
        super().__init__(timeout=300)
        self.cog = cog
        self.ctx = ctx
        self.songs = songs_list
        self.artist = artist
        self.page = 0
        self.per_page = 10
        self.max_pages = (len(songs_list) - 1) // self.per_page + 1
        
        self.update_buttons()
    
    def update_buttons(self):
        """Update button states based on current page"""
        # Disable prev button on first page
        self.prev_button.disabled = (self.page == 0)
        # Disable next button on last page
        self.next_button.disabled = (self.page >= self.max_pages - 1)
    
    def get_current_songs(self):
        """Get songs for current page"""
        start = self.page * self.per_page
        end = start + self.per_page
        return self.songs[start:end]
    
    def create_embed(self) -> discord.Embed:
        """Create embed showing current page of songs - DEPRECATED, use create_layout_view"""
        # Keeping for compatibility but not used
        pass
    
    def create_layout_view(self) -> discord.ui.LayoutView:
        """Create LayoutView showing current page of songs (like help UI)"""
        layout_view = discord.ui.LayoutView(timeout=300)
        container = discord.ui.Container(accent_color=None)
        
        container.add_item(discord.ui.TextDisplay(f"# Similar Songs - {self.artist}"))
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay(f"Select a song to play • Page {self.page + 1}/{self.max_pages}"))
        container.add_item(discord.ui.Separator())
        
        current_songs = self.get_current_songs()
        
        songs_text = ""
        for i, song in enumerate(current_songs, start=1):
            song_num = (self.page * self.per_page) + i
            title = song.get('title', 'Unknown')[:80]
            duration = self.cog._fmt(song.get('duration', 0))
            songs_text += f"**{song_num}.** {title}\n> **Duration:** `{duration}`\n\n"
        
        container.add_item(discord.ui.TextDisplay(songs_text.strip()))
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay(f"Total {len(self.songs)} songs found"))
        
        layout_view.add_item(container)
        return layout_view
    
    def create_select_menu(self):
        """Create select menu for current page songs"""
        current_songs = self.get_current_songs()
        options = []
        
        for i, song in enumerate(current_songs):
            song_num = (self.page * self.per_page) + i + 1
            title = song.get('title', 'Unknown')[:90]
            duration = self.cog._fmt(song.get('duration', 0))
            
            options.append(
                discord.SelectOption(
                    label=f"{song_num}. {title[:90]}",
                    description=f"Duration: {duration}",
                    value=str(i)
                )
            )
        
        # Remove old select menu if exists
        for item in self.children[:]:
            if isinstance(item, discord.ui.Select):
                self.remove_item(item)
        
        # Add new select menu at position 0
        select = discord.ui.Select(
            placeholder="Select a song to play...",
            options=options,
            row=0
        )
        select.callback = self.song_select_callback
        self.add_item(select)
    
    async def song_select_callback(self, interaction: discord.Interaction):
        """Handle song selection"""
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Only the requester can select!", ephemeral=True)
        
        try:
            # Get selected song
            select = interaction.data.get('values', ['0'])[0]
            song_index = int(select)
            current_songs = self.get_current_songs()
            
            if song_index >= len(current_songs):
                return await interaction.response.send_message("Invalid selection!", ephemeral=True)
            
            selected_song = current_songs[song_index]
            
            await interaction.response.defer(ephemeral=True)
            
            # Create song dict with safe access
            song = {
                "full_title": selected_song.get("title", "Unknown"),
                "artist": selected_song.get("uploader") or selected_song.get("channel") or "Unknown Artist",
                "url": selected_song.get("url", ""),
                "duration": selected_song.get("duration", 0),
                "thumbnail": selected_song.get("thumbnail", ""),
                "requester": self.ctx.author,
            }
            
            # Validate URL exists
            if not song["url"]:
                return await interaction.followup.send("Error: Song URL not found!", ephemeral=True)
            
            # Add to queue or play
            vc = self.ctx.voice_client
            if vc and (vc.is_playing() or vc.is_paused()):
                self.cog.queue.append(song)
                await interaction.followup.send(f"Added **{song['full_title'][:50]}** to queue!", ephemeral=True)
            else:
                await self.cog._play_song(self.ctx, song)
                await interaction.followup.send(f"Now playing **{song['full_title'][:50]}**!", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)
    
    @discord.ui.button(label="◀ Previous", style=discord.ButtonStyle.secondary, row=1)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Only the requester can navigate!", ephemeral=True)
        
        self.page = max(0, self.page - 1)
        self.update_buttons()
        self.create_select_menu()
        
        layout_view = self.create_layout_view()
        
        # Add select menu
        for item in self.children:
            if isinstance(item, discord.ui.Select):
                layout_view.add_item(discord.ui.ActionRow(item))
        
        # Add navigation buttons
        layout_view.add_item(discord.ui.ActionRow(self.prev_button, self.next_button))
        
        await interaction.response.edit_message(view=layout_view)
    
    @discord.ui.button(label="Next ▶", style=discord.ButtonStyle.secondary, row=1)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Only the requester can navigate!", ephemeral=True)
        
        self.page = min(self.max_pages - 1, self.page + 1)
        self.update_buttons()
        self.create_select_menu()
        
        layout_view = self.create_layout_view()
        
        # Add select menu
        for item in self.children:
            if isinstance(item, discord.ui.Select):
                layout_view.add_item(discord.ui.ActionRow(item))
        
        # Add navigation buttons
        layout_view.add_item(discord.ui.ActionRow(self.prev_button, self.next_button))
        
        await interaction.response.edit_message(view=layout_view)


class MusicLayout(discord.ui.View):
    """Now Playing layout with thumbnail and select menu"""

    def __init__(self, cog, ctx, song: dict, is_queued: bool = False):
        super().__init__(timeout=300)
        self.cog = cog
        self.ctx = ctx
        self.song = song
        self.is_queued = is_queued

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user == self.ctx.author

    # Music control buttons
    @discord.ui.button(label="⏮", style=discord.ButtonStyle.secondary, row=0)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = self.ctx.voice_client
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
            await interaction.response.send_message("Restarting...", ephemeral=True)
            await self.cog._play_song(self.ctx, self.song)
        else:
            await interaction.response.send_message("Nothing is playing!", ephemeral=True)

    @discord.ui.button(label="⏸", style=discord.ButtonStyle.secondary, row=0)
    async def pause_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = self.ctx.voice_client
        if vc and vc.is_playing():
            vc.pause()
            button.label = "▶"
            # Recreate the layout view with updated button
            layout_view = self.create_layout_view()
            layout_view.add_item(discord.ui.ActionRow(self.music_select))
            layout_view.add_item(discord.ui.ActionRow(
                self.prev_button,
                self.pause_button,
                self.skip_button,
                self.like_button,
                self.stop_button
            ))
            await interaction.response.edit_message(view=layout_view)
        elif vc and vc.is_paused():
            vc.resume()
            button.label = "⏸"
            # Recreate the layout view with updated button
            layout_view = self.create_layout_view()
            layout_view.add_item(discord.ui.ActionRow(self.music_select))
            layout_view.add_item(discord.ui.ActionRow(
                self.prev_button,
                self.pause_button,
                self.skip_button,
                self.like_button,
                self.stop_button
            ))
            await interaction.response.edit_message(view=layout_view)
        else:
            await interaction.response.send_message("Nothing is playing!", ephemeral=True)

    @discord.ui.button(label="⏭", style=discord.ButtonStyle.secondary, row=0)
    async def skip_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = self.ctx.voice_client
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
            await interaction.response.send_message("Skipped!", ephemeral=True)
        else:
            await interaction.response.send_message("Nothing is playing!", ephemeral=True)

    @discord.ui.button(emoji="<a:Dil_heart2:1497856082301685793>", style=discord.ButtonStyle.danger, row=0)
    async def like_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Smart playlist save - checks user's playlists and acts accordingly"""
        await interaction.response.defer(ephemeral=True)
        
        try:
            import aiosqlite
            
            # Get user's playlists
            async with aiosqlite.connect('db/playlists.db') as db:
                cursor = await db.execute("""
                    SELECT playlist_id, name
                    FROM playlists
                    WHERE user_id = ?
                    ORDER BY created_at DESC
                """, (interaction.user.id,))
                playlists = await cursor.fetchall()
            
            # Case 1: No playlists - show create command
            if not playlists:
                no_pl_view = discord.ui.LayoutView(timeout=60.0)
                no_pl_container = discord.ui.Container(accent_color=None)
                no_pl_container.add_item(discord.ui.TextDisplay("# 📋 No Playlists Found"))
                no_pl_container.add_item(discord.ui.Separator())
                no_pl_container.add_item(discord.ui.TextDisplay(
                    "You don't have any playlists yet!\n\n"
                    f"Create one with `.playlist create <name>`"
                ))
                no_pl_view.add_item(no_pl_container)
                return await interaction.followup.send(view=no_pl_view, ephemeral=True)
            
            # Case 2: Exactly 1 playlist - auto add
            elif len(playlists) == 1:
                playlist_id, playlist_name = playlists[0]
                
                # Add song to the playlist
                async with aiosqlite.connect('db/playlists.db') as db:
                    await db.execute(
                        "INSERT INTO playlist_songs (playlist_id, song_title, song_url, artist, duration) VALUES (?, ?, ?, ?, ?)",
                        (playlist_id, self.song['full_title'], self.song['url'], self.song.get('artist', 'Unknown'), self.song['duration'])
                    )
                    await db.commit()
                
                # Success message
                success_view = discord.ui.LayoutView(timeout=60.0)
                success_container = discord.ui.Container(accent_color=None)
                success_container.add_item(discord.ui.TextDisplay("# ✅ Added to Playlist"))
                success_container.add_item(discord.ui.Separator())
                
                _, title = self.cog._split(self.song["full_title"])
                success_container.add_item(discord.ui.TextDisplay(
                    f"**Song:** {title}\n"
                    f"**Playlist:** {playlist_name}"
                ))
                success_container.add_item(discord.ui.Separator())
                success_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
                success_view.add_item(success_container)
                
                await interaction.followup.send(view=success_view, ephemeral=True)
            
            # Case 3: Multiple playlists - ask user to choose
            else:
                # Create select menu with playlists
                class PlaylistSelectView(discord.ui.View):
                    def __init__(self, song_data, playlists_data, cog_ref):
                        super().__init__(timeout=60)
                        self.song = song_data
                        self.playlists = playlists_data
                        self.cog = cog_ref
                        
                        # Create select menu
                        options = []
                        for pl_id, pl_name in playlists_data[:25]:  # Discord limit 25 options
                            options.append(
                                discord.SelectOption(
                                    label=pl_name[:100],
                                    description=f"ID: {pl_id}",
                                    value=str(pl_id),
                                    emoji="📋"
                                )
                            )
                        
                        select = discord.ui.Select(
                            placeholder="Select a playlist to add this song...",
                            options=options
                        )
                        select.callback = self.playlist_callback
                        self.add_item(select)
                    
                    async def playlist_callback(self, inter: discord.Interaction):
                        await inter.response.defer(ephemeral=True)
                        
                        playlist_id = int(inter.data['values'][0])
                        
                        # Add song to playlist
                        async with aiosqlite.connect('db/playlists.db') as db:
                            # Get playlist name
                            cursor = await db.execute(
                                "SELECT name FROM playlists WHERE playlist_id = ?",
                                (playlist_id,)
                            )
                            playlist = await cursor.fetchone()
                            
                            # Add song
                            await db.execute(
                                "INSERT INTO playlist_songs (playlist_id, song_title, song_url, artist, duration) VALUES (?, ?, ?, ?, ?)",
                                (playlist_id, self.song['full_title'], self.song['url'], self.song.get('artist', 'Unknown'), self.song['duration'])
                            )
                            await db.commit()
                        
                        # Success message
                        success_view = discord.ui.LayoutView(timeout=60.0)
                        success_container = discord.ui.Container(accent_color=None)
                        success_container.add_item(discord.ui.TextDisplay("# ✅ Added to Playlist"))
                        success_container.add_item(discord.ui.Separator())
                        
                        _, title = self.cog._split(self.song["full_title"])
                        success_container.add_item(discord.ui.TextDisplay(
                            f"**Song:** {title}\n"
                            f"**Playlist:** {playlist[0]}"
                        ))
                        success_container.add_item(discord.ui.Separator())
                        success_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
                        success_view.add_item(success_container)
                        
                        await inter.followup.send(view=success_view, ephemeral=True)
                
                # Show playlist selection
                pl_view = PlaylistSelectView(self.song, playlists, self.cog)
                await interaction.followup.send("Select a playlist to add this song:", view=pl_view, ephemeral=True)
                
        except Exception as e:
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)

    @discord.ui.button(label="⏹", style=discord.ButtonStyle.secondary, row=0)
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = self.ctx.voice_client
        if vc:
            self.cog.queue.clear()
            self.cog.current = None
            vc.stop()
            await interaction.response.send_message("Stopped and cleared queue!", ephemeral=True)
        else:
            await interaction.response.send_message("Not in voice!", ephemeral=True)

    @discord.ui.select(
        placeholder="Select an option...",
        options=[
            discord.SelectOption(label="Search for similar songs", value="similar"),
            discord.SelectOption(label="My Playlists", value="my_playlists"),
            discord.SelectOption(label="Spotify Playlists", value="spotify_playlists"),
        ],
        row=1
    )
    async def music_select(self, interaction: discord.Interaction, select: discord.ui.Select):
        # Store the selected value
        selected_value = select.values[0]
        
        if selected_value == "similar":
            # Search for similar songs based on current song
            await interaction.response.defer(ephemeral=True)
            
            try:
                # Get artist from current song
                if "artist" in self.song:
                    artist = self.song["artist"]
                else:
                    artist, _ = self.cog._split(self.song["full_title"])
                
                # Search for multiple songs by same artist
                search_query = f"{artist} songs"
                
                # Show searching embed first (LayoutView format like help UI)
                searching_view = discord.ui.LayoutView(timeout=60.0)
                searching_container = discord.ui.Container(accent_color=None)
                searching_container.add_item(discord.ui.TextDisplay("# <a:pol_dance_haveli:1497856158009004172> Searching..."))
                searching_container.add_item(discord.ui.Separator())
                searching_container.add_item(discord.ui.TextDisplay(f"**Artist:** {artist}"))
                searching_container.add_item(discord.ui.Separator())
                searching_container.add_item(discord.ui.TextDisplay("Please wait while we find similar songs..."))
                searching_container.add_item(discord.ui.Separator())
                searching_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
                searching_view.add_item(searching_container)
                
                search_msg = await interaction.followup.send(view=searching_view, ephemeral=True)
                
                # Get multiple results (20 for faster search)
                loop = asyncio.get_event_loop()
                data = await loop.run_in_executor(
                    None, lambda: self.cog.ytdl.extract_info(f"ytsearch20:{search_query}", download=False)
                )
                
                if not data:
                    # No data returned (LayoutView format)
                    no_view = discord.ui.LayoutView(timeout=60.0)
                    no_container = discord.ui.Container(accent_color=None)
                    no_container.add_item(discord.ui.TextDisplay("# <a:wrong_time:1497855966727897179> No Similar Songs Found"))
                    no_container.add_item(discord.ui.Separator())
                    no_container.add_item(discord.ui.TextDisplay(f"**Artist:** {artist}"))
                    no_container.add_item(discord.ui.Separator())
                    no_container.add_item(discord.ui.TextDisplay("Try playing a different song first"))
                    no_container.add_item(discord.ui.Separator())
                    no_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
                    no_view.add_item(no_container)
                    
                    return await search_msg.edit(view=no_view)
                
                entries = data.get("entries", []) if isinstance(data, dict) else []
                
                if entries:
                    # Create paginated view and edit the searching message
                    view = SimilarSongsView(self.cog, self.ctx, entries, artist)
                    view.create_select_menu()
                    layout_view = view.create_layout_view()
                    
                    # Add select menu and navigation buttons to layout
                    for item in view.children:
                        if isinstance(item, discord.ui.Select):
                            layout_view.add_item(discord.ui.ActionRow(item))
                        elif isinstance(item, discord.ui.Button):
                            # Buttons are already in the view, we'll add them as action rows
                            pass
                    
                    # Add navigation buttons
                    layout_view.add_item(discord.ui.ActionRow(view.prev_button, view.next_button))
                    
                    await search_msg.edit(view=layout_view)
                else:
                    # Create "No similar songs found" embed (LayoutView format)
                    no_view = discord.ui.LayoutView(timeout=60.0)
                    no_container = discord.ui.Container(accent_color=None)
                    no_container.add_item(discord.ui.TextDisplay("# <a:wrong_time:1497855966727897179> No Similar Songs Found"))
                    no_container.add_item(discord.ui.Separator())
                    no_container.add_item(discord.ui.TextDisplay(f"**Artist:** {artist}"))
                    no_container.add_item(discord.ui.Separator())
                    no_container.add_item(discord.ui.TextDisplay("Try playing a different song first"))
                    no_container.add_item(discord.ui.Separator())
                    no_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
                    no_view.add_item(no_container)
                    
                    await search_msg.edit(view=no_view)
            except Exception as e:
                await interaction.followup.send(f"Error searching: {str(e)}", ephemeral=True)
        
        elif selected_value == "my_playlists":
            # Show user's bot playlists to PLAY
            await interaction.response.defer(ephemeral=True)
            
            try:
                import aiosqlite
                
                # Get user's playlists
                async with aiosqlite.connect('db/playlists.db') as db:
                    cursor = await db.execute("""
                        SELECT p.playlist_id, p.name, COUNT(ps.id) as song_count
                        FROM playlists p
                        LEFT JOIN playlist_songs ps ON p.playlist_id = ps.playlist_id
                        WHERE p.user_id = ?
                        GROUP BY p.playlist_id
                        ORDER BY p.created_at DESC
                        LIMIT 10
                    """, (interaction.user.id,))
                    playlists = await cursor.fetchall()
                
                if not playlists:
                    # No playlists found
                    no_pl_view = discord.ui.LayoutView(timeout=60.0)
                    no_pl_container = discord.ui.Container(accent_color=None)
                    no_pl_container.add_item(discord.ui.TextDisplay("# 📋 No Playlists Found"))
                    no_pl_container.add_item(discord.ui.Separator())
                    no_pl_container.add_item(discord.ui.TextDisplay("You don't have any playlists yet!"))
                    no_pl_container.add_item(discord.ui.Separator())
                    no_pl_container.add_item(discord.ui.TextDisplay("Create one with `.playlist create <name>`"))
                    no_pl_view.add_item(no_pl_container)
                    return await interaction.followup.send(view=no_pl_view, ephemeral=True)
                
                # Create select menu with playlists to PLAY
                class PlaylistPlayView(discord.ui.View):
                    def __init__(self, cog_ref, ctx_ref, playlists_data):
                        super().__init__(timeout=60)
                        self.cog = cog_ref
                        self.ctx = ctx_ref
                        self.playlists = playlists_data
                        
                        # Create select menu
                        options = []
                        for pl_id, pl_name, song_count in playlists_data:
                            options.append(
                                discord.SelectOption(
                                    label=pl_name[:100],
                                    description=f"{song_count} songs • Play this playlist",
                                    value=str(pl_id),
                                    emoji="▶"
                                )
                            )
                        
                        select = discord.ui.Select(
                            placeholder="Select a playlist to play...",
                            options=options
                        )
                        select.callback = self.playlist_callback
                        self.add_item(select)
                    
                    async def playlist_callback(self, inter: discord.Interaction):
                        await inter.response.defer(ephemeral=True)
                        
                        playlist_id = int(inter.data['values'][0])
                        
                        # Get all songs from playlist
                        async with aiosqlite.connect('db/playlists.db') as db:
                            # Get playlist name
                            cursor = await db.execute(
                                "SELECT name FROM playlists WHERE playlist_id = ?",
                                (playlist_id,)
                            )
                            playlist = await cursor.fetchone()
                            
                            # Get all songs (limit to 20 for performance)
                            cursor = await db.execute(
                                "SELECT song_title, artist, duration FROM playlist_songs WHERE playlist_id = ? ORDER BY id LIMIT 20",
                                (playlist_id,)
                            )
                            songs = await cursor.fetchall()
                        
                        if not songs:
                            # Empty playlist
                            empty_view = discord.ui.LayoutView(timeout=60.0)
                            empty_container = discord.ui.Container(accent_color=None)
                            empty_container.add_item(discord.ui.TextDisplay("# 📋 Empty Playlist"))
                            empty_container.add_item(discord.ui.Separator())
                            empty_container.add_item(discord.ui.TextDisplay(
                                f"**Playlist:** {playlist[0]}\n\n"
                                f"This playlist has no songs yet!"
                            ))
                            empty_view.add_item(empty_container)
                            return await inter.followup.send(view=empty_view, ephemeral=True)
                        
                        # Check if bot is in voice
                        vc = self.ctx.voice_client
                        if not vc:
                            return await inter.followup.send("❌ Bot is not in voice channel!", ephemeral=True)
                        
                        # Show loading message ONCE
                        loading_view = discord.ui.LayoutView(timeout=60.0)
                        loading_container = discord.ui.Container(accent_color=None)
                        loading_container.add_item(discord.ui.TextDisplay("# <a:pol_dance_haveli:1497856158009004172> Loading Playlist"))
                        loading_container.add_item(discord.ui.Separator())
                        loading_container.add_item(discord.ui.TextDisplay(
                            f"**Playlist:** {playlist[0]}\n"
                            f"**Songs:** {len(songs)} tracks\n\n"
                            f"Please wait..."
                        ))
                        loading_view.add_item(loading_container)
                        loading_msg = await inter.followup.send(view=loading_view, ephemeral=True)
                        
                        # Search songs in parallel for SPEED (limit to first 5 for quick start)
                        import asyncio
                        
                        async def search_song(song_title, artist, duration):
                            try:
                                info = await self.cog._search(song_title)
                                if info:
                                    return {
                                        "full_title": info.get("title", song_title),
                                        "artist": info.get("uploader") or info.get("channel") or artist or "Unknown Artist",
                                        "url": info["url"],
                                        "duration": info.get("duration", duration or 0),
                                        "thumbnail": info.get("thumbnail", ""),
                                        "requester": inter.user,
                                    }
                            except:
                                pass
                            return None
                        
                        # Search first 5 songs in parallel for quick start
                        quick_songs = songs[:5]
                        remaining_songs = songs[5:]
                        
                        # Parallel search for first 5
                        tasks = [search_song(title, artist, dur) for title, artist, dur in quick_songs]
                        results = await asyncio.gather(*tasks)
                        
                        added_count = 0
                        failed_count = 0
                        
                        # Add first batch
                        for song_dict in results:
                            if song_dict:
                                if not vc.is_playing() and not vc.is_paused() and not self.cog.queue:
                                    await self.cog._play_song(self.ctx, song_dict)
                                else:
                                    self.cog.queue.append(song_dict)
                                added_count += 1
                            else:
                                failed_count += 1
                        
                        # Add remaining songs in background (don't wait)
                        async def add_remaining():
                            nonlocal added_count, failed_count
                            for song_title, artist, duration in remaining_songs:
                                song_dict = await search_song(song_title, artist, duration)
                                if song_dict:
                                    self.cog.queue.append(song_dict)
                                    added_count += 1
                                else:
                                    failed_count += 1
                        
                        # Start background task
                        if remaining_songs:
                            asyncio.create_task(add_remaining())
                        
                        # Update loading message to success IMMEDIATELY
                        success_view = discord.ui.LayoutView(timeout=60.0)
                        success_container = discord.ui.Container(accent_color=None)
                        success_container.add_item(discord.ui.TextDisplay("# ▶ Playing Playlist"))
                        success_container.add_item(discord.ui.Separator())
                        
                        status_text = f"**Playlist:** {playlist[0]}\n**Added:** {added_count} tracks"
                        if remaining_songs:
                            status_text += f"\n**Loading:** {len(remaining_songs)} more in background..."
                        if failed_count > 0:
                            status_text += f"\n**Failed:** {failed_count} tracks"
                        
                        success_container.add_item(discord.ui.TextDisplay(status_text))
                        success_container.add_item(discord.ui.Separator())
                        success_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
                        success_view.add_item(success_container)
                        
                        await loading_msg.edit(view=success_view)
                        success_container.add_item(discord.ui.TextDisplay("# ▶ Playing Playlist"))
                        success_container.add_item(discord.ui.Separator())
                        success_container.add_item(discord.ui.TextDisplay(
                            f"**Playlist:** {playlist[0]}\n"
                            f"**Songs:** {len(songs)} tracks\n\n"
                            f"All songs added to queue!"
                        ))
                        success_container.add_item(discord.ui.Separator())
                        success_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
                        success_view.add_item(success_container)
                        
                        await inter.followup.send(view=success_view, ephemeral=True)
                
                # Show playlist selection
                pl_view = PlaylistPlayView(self.cog, self.ctx, playlists)
                await interaction.followup.send("Select a playlist to play:", view=pl_view, ephemeral=True)
                
            except Exception as e:
                await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)
        
        elif selected_value == "spotify_playlists":
            # Show user's Spotify playlists
            await interaction.response.defer(ephemeral=True)
            
            try:
                import aiosqlite
                
                # Check if user has linked Spotify
                async with aiosqlite.connect('db/spotify.db') as db:
                    cursor = await db.execute(
                        "SELECT spotify_username FROM spotify_users WHERE user_id = ?",
                        (interaction.user.id,)
                    )
                    user_data = await cursor.fetchone()
                    
                    if not user_data:
                        # Not linked
                        link_view = discord.ui.LayoutView(timeout=60.0)
                        link_container = discord.ui.Container(accent_color=None)
                        link_container.add_item(discord.ui.TextDisplay("# 🎵 Link Spotify"))
                        link_container.add_item(discord.ui.Separator())
                        link_container.add_item(discord.ui.TextDisplay(
                            "Link your Spotify account first!\n\n"
                            f"Use: `.spotify link <username>`"
                        ))
                        link_container.add_item(discord.ui.Separator())
                        link_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
                        link_view.add_item(link_container)
                        return await interaction.followup.send(view=link_view, ephemeral=True)
                    
                    # Get Spotify playlists
                    cursor = await db.execute("""
                        SELECT id, playlist_name, playlist_id
                        FROM spotify_playlists
                        WHERE user_id = ?
                        ORDER BY added_at DESC
                        LIMIT 10
                    """, (interaction.user.id,))
                    playlists = await cursor.fetchall()
                
                if not playlists:
                    # No playlists
                    no_pl_view = discord.ui.LayoutView(timeout=60.0)
                    no_pl_container = discord.ui.Container(accent_color=None)
                    no_pl_container.add_item(discord.ui.TextDisplay("# 📋 No Spotify Playlists"))
                    no_pl_container.add_item(discord.ui.Separator())
                    no_pl_container.add_item(discord.ui.TextDisplay(
                        "You haven't added any Spotify playlists yet!\n\n"
                        f"Add one with `.spotify add <playlist_url>`"
                    ))
# © Trusty X Ayaan Development
                    no_pl_container.add_item(discord.ui.Separator())
                    no_pl_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
                    no_pl_view.add_item(no_pl_container)
                    return await interaction.followup.send(view=no_pl_view, ephemeral=True)
                
                # Show Spotify playlists
                sp_view = discord.ui.LayoutView(timeout=60.0)
                sp_container = discord.ui.Container(accent_color=None)
                sp_container.add_item(discord.ui.TextDisplay("# 🎵 Your Spotify Playlists"))
                sp_container.add_item(discord.ui.Separator())
                
                playlists_text = ""
                for i, (db_id, name, sp_id) in enumerate(playlists, start=1):
                    playlists_text += f"**{i}.** {name}\n> **ID:** `{db_id}` • **Play:** `.spotify play {db_id}`\n\n"
                
                sp_container.add_item(discord.ui.TextDisplay(playlists_text.strip()))
                sp_container.add_item(discord.ui.Separator())
                sp_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
                sp_view.add_item(sp_container)
                
                await interaction.followup.send(view=sp_view, ephemeral=True)
                
            except Exception as e:
                await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)

    def create_embed(self) -> discord.Embed:
        """Create the music embed using LayoutView"""
        # This method is no longer used, keeping for compatibility
        pass
    
    def create_layout_view(self) -> discord.ui.LayoutView:
        """Create LayoutView for music display (like help UI)"""
        # Get artist from song dict if available, otherwise split from title
        if "artist" in self.song and self.song["artist"] != "Unknown Artist":
            artist = self.song["artist"]
            title = self.song["full_title"]
        else:
            artist, title = self.cog._split(self.song["full_title"])
        
        duration_str = self.cog._fmt(self.song["duration"])
        queue_count = len(self.cog.queue)

        # Create LayoutView with Container (like help UI)
        layout_view = discord.ui.LayoutView(timeout=300)
        container = discord.ui.Container(accent_color=None)
        
        # Get song thumbnail (YouTube video thumbnail)
        song_thumbnail = self.song.get("thumbnail", "")
        
        if self.is_queued:
            # Track Added
            container.add_item(discord.ui.TextDisplay("# Track Added"))
            container.add_item(discord.ui.Separator())
            
            # Add Section with song thumbnail (YouTube video image)
            if song_thumbnail:
                section = discord.ui.Section(
                    discord.ui.TextDisplay(
                        f"**[{title}]({self.song['url']})**\n"
                        f"> <a:GH_dot:1497855948306513982> **Author:** {artist}\n"
                        f"> <a:GH_dot:1497855948306513982> **Duration:** `{duration_str}`\n"
                        f"> <a:GH_dot:1497855948306513982> **Requester:** {self.song['requester'].mention}\n"
                        f"> <a:GH_dot:1497855948306513982> **Position in Queue:** #{queue_count}"
                    ),
                    accessory=discord.ui.Thumbnail(song_thumbnail)
                )
            else:
                section = discord.ui.Section(
                    discord.ui.TextDisplay(
                        f"**[{title}]({self.song['url']})**\n"
                        f"> <a:GH_dot:1497855948306513982> **Author:** {artist}\n"
                        f"> <a:GH_dot:1497855948306513982> **Duration:** `{duration_str}`\n"
                        f"> <a:GH_dot:1497855948306513982> **Requester:** {self.song['requester'].mention}\n"
                        f"> <a:GH_dot:1497855948306513982> **Position in Queue:** #{queue_count}"
                    )
                )
            container.add_item(section)
        else:
            # Now Playing
            container.add_item(discord.ui.TextDisplay(f"# {title}"))
            container.add_item(discord.ui.Separator())
            
            # Add Section with song thumbnail (YouTube video image)
            if song_thumbnail:
                section = discord.ui.Section(
                    discord.ui.TextDisplay(
                        f"> <a:GH_dot:1497855948306513982> **Author:** {artist}\n"
                        f"> <a:GH_dot:1497855948306513982> **Duration:** `{duration_str}`\n"
                        f"> <a:GH_dot:1497855948306513982> **Requester:** {self.song['requester'].mention}"
                    ),
                    accessory=discord.ui.Thumbnail(song_thumbnail)
                )
            else:
                section = discord.ui.Section(
                    discord.ui.TextDisplay(
                        f"> <a:GH_dot:1497855948306513982> **Author:** {artist}\n"
                        f"> <a:GH_dot:1497855948306513982> **Duration:** `{duration_str}`\n"
                        f"> <a:GH_dot:1497855948306513982> **Requester:** {self.song['requester'].mention}"
                    )
                )
            container.add_item(section)
        
        container.add_item(discord.ui.Separator())
        
        # Show queue count differently based on context
        if self.is_queued:
            container.add_item(discord.ui.TextDisplay(f"Lakshmi Music  •  Position #{queue_count} in queue"))
        else:
            # For now playing, show current queue size
            container.add_item(discord.ui.TextDisplay(f"Lakshmi Music  •  {queue_count} songs waiting"))
        
        layout_view.add_item(container)
        return layout_view


class SimpleVoice(Cog):
    """Voice & Music commands"""

    def __init__(self, bot):
        self.bot     = bot
        self.queue   = []
        self.current = None
        self.now_playing_msg = None  # Store the now playing message to update it
        self.loop_mode = "off"  # off, one, all
        self.volume = 1.0  # 0.0 to 2.0
        self._setup_ytdl()
        # Initialize 24/7 database on startup
        self.bot.loop.create_task(self._init_247_db())
        # Initialize 24/7 database
        self.bot.loop.create_task(self._init_247_db())

    async def _init_247_db(self):
        """Initialize 24/7 voice database"""
        import aiosqlite
        async with aiosqlite.connect('db/voice247.db') as db:
            await db.execute('''
                CREATE TABLE IF NOT EXISTS voice_247 (
                    guild_id INTEGER PRIMARY KEY,
                    channel_id INTEGER NOT NULL
                )
            ''')
            await db.commit()

    # ── setup ────────────────────────────────────────────────────────────

    async def _init_247_db(self):
        """Initialize 24/7 database table"""
        import aiosqlite
        try:
            async with aiosqlite.connect('db/voice247.db') as db:
                await db.execute('''
                    CREATE TABLE IF NOT EXISTS voice_247 (
                        guild_id INTEGER PRIMARY KEY,
                        channel_id INTEGER NOT NULL
                    )
                ''')
                await db.commit()
        except Exception as e:
            print(f"Error initializing 24/7 database: {e}")

    def _setup_ytdl(self):
        username = os.environ.get("USERNAME", "ayaan")
        path = (
            f"C:\\Users\\{username}\\AppData\\Local\\Microsoft\\WinGet\\Packages\\"
            f"Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\\ffmpeg-8.1-full_build\\bin\\ffmpeg.exe"
        )
        self.ffmpeg = path if os.path.exists(path) else "ffmpeg"
        self.ytdl = yt_dlp.YoutubeDL({
            "format": "bestaudio/best",
            "restrictfilenames": True,
            "noplaylist": True,
            "nocheckcertificate": True,
            "ignoreerrors": False,
            "quiet": True,
            "no_warnings": True,
            "default_search": "auto",
            "source_address": "0.0.0.0",
            "age_limit": None,
            "extractor_args": {
                "youtube": {
                    "skip": ["dash", "hls"],
                }
            },
        })

    # ── helpers ──────────────────────────────────────────────────────────

    def _fmt(self, secs: int) -> str:
        m, s = divmod(secs or 0, 60)
        return f"{m:02d}:{s:02d}"

    def _split(self, raw: str):
        if " - " in raw:
            a, t = raw.split(" - ", 1)
            return a.strip(), t.strip()
        return "Unknown", raw.strip()

    async def _search(self, query: str):
        loop = asyncio.get_event_loop()
        try:
            data = await loop.run_in_executor(
                None, lambda: self.ytdl.extract_info(f"ytsearch1:{query}", download=False)
            )
            entries = data.get("entries") or []
            return entries[0] if entries else None
        except Exception as e:
            error_msg = str(e)
            if "Sign in to confirm your age" in error_msg or "age" in error_msg.lower():
                print(f"[YTDL] Age-restricted video, trying alternative search...")
                # Try searching for a different version
                try:
                    data = await loop.run_in_executor(
                        None, lambda: self.ytdl.extract_info(f"ytsearch2:{query}", download=False)
                    )
                    entries = data.get("entries") or []
                    # Return second result if first is age-restricted
                    return entries[1] if len(entries) > 1 else (entries[0] if entries else None)
                except:
                    pass
            print(f"[YTDL] {e}")
            return None

    async def _get_thumbnail_type(self, url: str) -> str:
        """Returns 'banner' if wide image, 'thumb' if square/small"""
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.head(url, timeout=aiohttp.ClientTimeout(total=3)) as r:
                    # YouTube maxresdefault thumbnails are 1280x720 (banner)
                    # hqdefault are 480x360 (banner)
                    # mqdefault are 320x180 (banner)
                    if "maxresdefault" in url or "hqdefault" in url or "mqdefault" in url or "sddefault" in url:
                        return "banner"
                    return "thumb"
        except:
            # Default: if it's a YouTube thumbnail URL, treat as banner
            if "ytimg.com" in url:
                return "banner"
            return "thumb"

    async def _update_now_playing(self, ctx: Context):
        """Update the now playing message with current queue count"""
        if not self.now_playing_msg or not self.current:
            return
        
        try:
            layout = MusicLayout(self, ctx, self.current, is_queued=False)
            layout_view = layout.create_layout_view()
            
            # Add select menu as ActionRow
            layout_view.add_item(discord.ui.ActionRow(layout.music_select))
            
            # Add music control buttons
            layout_view.add_item(discord.ui.ActionRow(
                layout.prev_button,
                layout.pause_button,
                layout.skip_button,
                layout.like_button,
                layout.stop_button
            ))
            
            await self.now_playing_msg.edit(view=layout_view)
        except:
            # Message might be deleted or inaccessible
            pass

    async def _play_song(self, ctx: Context, song: dict):
        vc = ctx.voice_client
        if not vc:
            return
        
        # Check if voice client is properly connected
        if not vc.is_connected():
            try:
                # Try to reconnect only if not already connected
                if ctx.author.voice:
                    ch = ctx.author.voice.channel
                    # Check if already connected to avoid error
                    if not ctx.voice_client or not ctx.voice_client.is_connected():
                        vc = await ch.connect(self_deaf=False, self_mute=False)
                        ctx.guild.voice_client = vc
                else:
                    await ctx.send("❌ Voice connection lost! Please rejoin a voice channel.")
                    return
            except discord.ClientException as e:
                # Already connected error - just use existing connection
                if "already connected" in str(e).lower():
                    vc = ctx.voice_client
                else:
                    await ctx.send(f"❌ Failed to connect to voice: {str(e)}")
                    return
            except Exception as e:
                await ctx.send(f"❌ Failed to connect to voice: {str(e)}")
                return
        
        if vc.is_playing() or vc.is_paused():
            vc.stop()
        self.current = song

        try:
            source = discord.FFmpegPCMAudio(
                song["url"],
                executable=self.ffmpeg,
                before_options="-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
                options="-vn -loglevel quiet",
            )
            
            # Apply volume
            source = discord.PCMVolumeTransformer(source, volume=self.volume)

            def _after(err):
                if err:
                    print(f"[Player] {err}")
                
                # Handle loop modes
                if self.loop_mode == "one":
                    # Repeat current song
                    asyncio.run_coroutine_threadsafe(self._play_song(ctx, song), self.bot.loop)
                elif self.loop_mode == "all":
                    # Add current song back to queue and play next
                    self.queue.append(song)
                    if self.queue:
                        asyncio.run_coroutine_threadsafe(self._play_next(ctx), self.bot.loop)
                elif self.queue:
                    # Normal: play next song
                    asyncio.run_coroutine_threadsafe(self._play_next(ctx), self.bot.loop)
                else:
                    # Queue is empty - send notification
                    self.current = None
                    asyncio.run_coroutine_threadsafe(self._send_queue_finished(ctx), self.bot.loop)

            vc.play(source, after=_after)

            # Send music embed with thumbnail and select menu
            layout = MusicLayout(self, ctx, song, is_queued=False)
            layout_view = layout.create_layout_view()
            
            # Add select menu as ActionRow
            layout_view.add_item(discord.ui.ActionRow(layout.music_select))
            
            # Add music control buttons
            layout_view.add_item(discord.ui.ActionRow(
                layout.prev_button,
                layout.pause_button,
                layout.skip_button,
                layout.like_button,
                layout.stop_button
            ))
            
            # Store the message so we can update it later
            self.now_playing_msg = await ctx.send(view=layout_view)
            
        except discord.ClientException as e:
            await ctx.send(f"❌ Voice connection error: {str(e)}\nPlease use `/leave` and try again.")
        except Exception as e:
            await ctx.send(f"❌ Error playing song: {str(e)}")

    async def _play_next(self, ctx: Context):
        if not self.queue or not ctx.voice_client:
            self.current = None
            
            # Send queue finished notification
            if ctx.voice_client:  # Only if still connected
                try:
                    view = discord.ui.LayoutView(timeout=60.0)
                    container = discord.ui.Container(accent_color=None)
                    
                    container.add_item(discord.ui.TextDisplay("# 🎵 Queue Khatam Ho Gaya"))
                    container.add_item(discord.ui.Separator())
                    container.add_item(discord.ui.TextDisplay(
                        "**Sab gaane khatam ho gaye! 🎶**\n\n"
                        "Queue me ab koi gaana nahi bacha hai.\n\n"
                        "Naye gaane bajane ke liye `.play <song name>` use karo!"
                    ))
                    container.add_item(discord.ui.Separator())
                    container.add_item(discord.ui.TextDisplay(
                        "**Quick Commands:**\n"
                        "• `.play <song>` - Naya gaana bajao\n"
                        "• `.queue` - Queue dekho\n"
                        "• `.leave` - Voice se disconnect karo"
                    ))
                    
                    view.add_item(container)
                    await ctx.send(view=view)
                except Exception as e:
                    print(f"Error sending queue finished notification: {e}")
            
            return
        await self._play_song(ctx, self.queue.pop(0))
    
    async def _send_queue_finished(self, ctx: Context):
        """Send queue finished notification"""
        try:
            view = discord.ui.LayoutView(timeout=60.0)
            container = discord.ui.Container(accent_color=None)
            
            container.add_item(discord.ui.TextDisplay("There are no more tracks"))
            
            view.add_item(container)
            await ctx.send(view=view)
            # Removed console print - notification sent silently
        except Exception as e:
            # Only print errors
            print(f"❌ Error sending queue finished notification: {e}")

    def help_custom(self):
        return ("🔊", "Voice & Music", "Voice and music commands")

    # ── commands ─────────────────────────────────────────────────────────

    @commands.command(name="join")
    async def join_voice(self, ctx: Context):
        """Join your voice channel"""
        if not ctx.author.voice:
            return await ctx.send("❌ You need to be in a voice channel!")
        ch = ctx.author.voice.channel
        if ctx.voice_client:
            if ctx.voice_client.channel.id == ch.id:
                # Already connected layout
                view = discord.ui.LayoutView(timeout=300.0)
                container = discord.ui.Container(accent_color=None)
                container.add_item(discord.ui.TextDisplay("# <:2076pastelgothheart:1489100768106512495> Already Connected"))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay(f"**Joined • {ch.name} • !!**"))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay("Bot is already in your voice channel"))
                view.add_item(container)
                return await ctx.send(view=view)
            await ctx.voice_client.disconnect()
        
        await ch.connect(self_deaf=False, self_mute=False)
        
        # Connected layout
        view = discord.ui.LayoutView(timeout=300.0)
        container = discord.ui.Container(accent_color=None)
        container.add_item(discord.ui.TextDisplay("# <:2076pastelgothheart:1489100768106512495> Connected"))
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay(f"**Joined • {ch.name} • !!**"))
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay("Successfully connected to voice channel"))
        view.add_item(container)
        await ctx.send(view=view)

    @commands.command(name="leave")
    async def leave_voice(self, ctx: Context):
        """Leave voice channel"""
        if not ctx.voice_client:
            return await ctx.send("❌ Not connected to any voice channel!")
        await ctx.voice_client.disconnect()
        await ctx.send("👋 Left voice channel!")

    @commands.command(name="247", aliases=["24/7", "stay"])
    @commands.has_permissions(manage_guild=True)
    async def stay_247(self, ctx: Context):
        """🔒 Keep bot in voice channel 24/7 (Admin only)
        
        Bot will automatically rejoin if disconnected
        Use again to toggle off
        """
        import aiosqlite
        
        if not ctx.author.voice:
            # Error view
            error_view = discord.ui.LayoutView(timeout=60.0)
            error_container = discord.ui.Container(accent_color=None)
            error_container.add_item(discord.ui.TextDisplay("# ❌ Not in Voice"))
            error_container.add_item(discord.ui.Separator())
            error_container.add_item(discord.ui.TextDisplay("You need to be in a voice channel to set 24/7 mode"))
            error_view.add_item(error_container)
            return await ctx.send(view=error_view)
        
        channel = ctx.author.voice.channel
        
        # Check if 24/7 is already enabled for this guild
        async with aiosqlite.connect('db/voice247.db') as db:
            await db.execute('''
                CREATE TABLE IF NOT EXISTS voice_247 (
                    guild_id INTEGER PRIMARY KEY,
                    channel_id INTEGER NOT NULL
                )
            ''')
            
            cursor = await db.execute(
                "SELECT channel_id FROM voice_247 WHERE guild_id = ?",
                (ctx.guild.id,)
            )
            result = await cursor.fetchone()
            
            if result:
                # 24/7 is enabled, disable it
                await db.execute("DELETE FROM voice_247 WHERE guild_id = ?", (ctx.guild.id,))
                await db.commit()
                
                # Disabled view
                view = discord.ui.LayoutView(timeout=60.0)
                container = discord.ui.Container(accent_color=None)
                container.add_item(discord.ui.TextDisplay("# 🔓 24/7 Mode Disabled"))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay(f"**Channel:** {channel.name}"))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay("Bot will no longer stay in voice channel permanently"))
                view.add_item(container)
                await ctx.send(view=view)
            else:
                # Enable 24/7
                await db.execute(
                    "INSERT OR REPLACE INTO voice_247 (guild_id, channel_id) VALUES (?, ?)",
                    (ctx.guild.id, channel.id)
                )
                await db.commit()
                
                # Connect to voice if not already
                if not ctx.voice_client:
                    await channel.connect(self_deaf=False, self_mute=False)
                elif ctx.voice_client.channel.id != channel.id:
                    await ctx.voice_client.move_to(channel)
                
                # Enabled view
                view = discord.ui.LayoutView(timeout=60.0)
                container = discord.ui.Container(accent_color=None)
                container.add_item(discord.ui.TextDisplay("# 🔒 24/7 Mode Enabled"))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay(f"**Channel:** {channel.name}"))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay("Bot will stay in this voice channel permanently\nUse this command again to disable"))
                view.add_item(container)
                await ctx.send(view=view)

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        """Auto-rejoin voice channel if 24/7 is enabled"""
        # Only handle bot disconnects
        if member.id != self.bot.user.id:
            return
        
        # Bot was disconnected
        if before.channel and not after.channel:
            import aiosqlite
            
            try:
                # Check if 24/7 is enabled for this guild
                async with aiosqlite.connect('db/voice247.db') as db:
                    # Ensure table exists
                    await db.execute('''
                        CREATE TABLE IF NOT EXISTS voice_247 (
                            guild_id INTEGER PRIMARY KEY,
                            channel_id INTEGER NOT NULL
                        )
                    ''')
                    
                    cursor = await db.execute(
                        "SELECT channel_id FROM voice_247 WHERE guild_id = ?",
                        (before.channel.guild.id,)
                    )
                    result = await cursor.fetchone()
                    
                    if result:
                        channel_id = result[0]
                        channel = self.bot.get_channel(channel_id)
                        
                        if channel:
                            try:
                                # Wait a bit before reconnecting
                                await asyncio.sleep(2)
                                await channel.connect(self_deaf=False, self_mute=False)
                            except:
                                pass
            except Exception:
                # Silently ignore any database errors
                pass

    @commands.command(name="play", aliases=["p"])
    async def play(self, ctx: Context, *, query: str = None):
        """🎵 Play a song from YouTube"""
        if not query:
            return await ctx.send("❌ Please provide a song name!")
        if not ctx.author.voice:
            return await ctx.send("❌ You need to be in a voice channel!")

        # Check if it's a Spotify playlist link
        if "spotify.com/playlist/" in query:
            # Create message that Spotify playlists are not supported
            spotify_view = discord.ui.LayoutView(timeout=60.0)
            spotify_container = discord.ui.Container(accent_color=None)
            spotify_container.add_item(discord.ui.TextDisplay("# ❌ Spotify Playlists Not Supported"))
            spotify_container.add_item(discord.ui.Separator())
            spotify_container.add_item(discord.ui.TextDisplay(
                "**Spotify playlists cannot be played directly.**\n\n"
                "**Alternatives:**\n"
                "> • Play individual songs from the playlist\n"
                "> • Use YouTube playlist instead\n"
                "> • Search by song name: `p song name`"
            ))
            spotify_container.add_item(discord.ui.Separator())
            spotify_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
            spotify_view.add_item(spotify_container)
            return await ctx.send(view=spotify_view)

        # Check if it's a Spotify track link and extract song info
        if "spotify.com/track/" in query:
            try:
                # Extract Spotify track ID
                import re
# Created by Trusty X Ayaan
                track_match = re.search(r'spotify\.com/track/([a-zA-Z0-9]+)', query)
                if track_match:
                    # For now, we'll search on YouTube using the Spotify URL
                    # In production, you'd use Spotify API to get track name
                    msg = await ctx.send(f"<a:pol_dance_haveli:1497856158009004172> Converting Spotify link to YouTube...")
                    
                    # Try to extract info from yt-dlp (it can handle some Spotify links)
                    try:
                        loop = asyncio.get_event_loop()
                        data = await loop.run_in_executor(
                            None, lambda: self.ytdl.extract_info(query, download=False)
                        )
                        if data:
                            # Use the extracted title to search on YouTube
                            title = data.get('title', '')
                            artist = data.get('artist', '') or data.get('uploader', '')
                            search_query = f"{artist} {title}" if artist else title
                            query = search_query
                            await msg.edit(content=f"<a:pol_dance_haveli:1497856158009004172> Searching YouTube for **{search_query}**...")
                    except:
                        # If extraction fails, just search with the URL
                        await msg.edit(content=f"<a:pol_dance_haveli:1497856158009004172> Searching for Spotify track on YouTube...")
            except:
                pass

        if not ctx.voice_client:
            ch = ctx.author.voice.channel
            await ch.connect(self_deaf=False, self_mute=False)
            
            # Connected layout
            view = discord.ui.LayoutView(timeout=300.0)
            container = discord.ui.Container(accent_color=None)
            container.add_item(discord.ui.TextDisplay("# <:2076pastelgothheart:1489100768106512495> Connected"))
            container.add_item(discord.ui.Separator())
            container.add_item(discord.ui.TextDisplay(f"**Joined • {ch.name} • !!**"))
            container.add_item(discord.ui.Separator())
            container.add_item(discord.ui.TextDisplay("Ready for music playback"))
            view.add_item(container)
            await ctx.send(view=view)
        elif ctx.voice_client and not ctx.voice_client.is_connected():
            # Reconnect if disconnected
            try:
                ch = ctx.author.voice.channel
                await ch.connect(self_deaf=False, self_mute=False)
            except Exception as e:
                await ctx.send(f"❌ Failed to reconnect: {str(e)}")

        if "spotify.com/track/" not in query:
            msg = await ctx.send(f"<a:pol_dance_haveli:1497856158009004172> Searching for **{query}**...")
        
        info = await self._search(query)
        if not info:
            # Create "No results found" LayoutView (like help UI)
            no_view = discord.ui.LayoutView(timeout=60.0)
            no_container = discord.ui.Container(accent_color=None)
            no_container.add_item(discord.ui.TextDisplay("# <a:wrong_time:1497855966727897179> No Results Found"))
            no_container.add_item(discord.ui.Separator())
            no_container.add_item(discord.ui.TextDisplay(f"**Search Query:** {query[:100]}"))
            no_container.add_item(discord.ui.Separator())
            no_container.add_item(discord.ui.TextDisplay("Try searching with different keywords"))
            no_container.add_item(discord.ui.Separator())
            no_container.add_item(discord.ui.TextDisplay("Lakshmi Music"))
            no_view.add_item(no_container)
            
            return await msg.edit(content="", view=no_view)

        song = {
            "full_title": info.get("title", "Unknown"),
            "artist":     info.get("uploader") or info.get("channel") or "Unknown Artist",
            "url":        info["url"],
            "duration":   info.get("duration", 0),
            "thumbnail":  info.get("thumbnail", ""),
            "requester":  ctx.author,
        }

        if ctx.voice_client.is_playing() or ctx.voice_client.is_paused():
            self.queue.append(song)
            
            # Update the now playing message with new queue count
            await self._update_now_playing(ctx)
            
            layout = MusicLayout(self, ctx, song, is_queued=True)
            layout_view = layout.create_layout_view()
            
            # Add select menu as ActionRow
            layout_view.add_item(discord.ui.ActionRow(layout.music_select))
            
            # Add music control buttons
            layout_view.add_item(discord.ui.ActionRow(
                layout.prev_button,
                layout.pause_button,
                layout.skip_button,
                layout.like_button,
                layout.stop_button
            ))
            
            return await msg.edit(content="", view=layout_view)

        await msg.delete()
        await self._play_song(ctx, song)

    @commands.command(name="skip", aliases=["s"])
    async def skip(self, ctx: Context):
        """⏭ Skip current song"""
        if not ctx.voice_client or not (ctx.voice_client.is_playing() or ctx.voice_client.is_paused()):
            return await ctx.send("❌ Nothing is playing!")
        ctx.voice_client.stop()
        await ctx.send("⏭ Skipped!")

    @commands.command(name="stop")
    async def stop(self, ctx: Context):
        """⏹ Stop music and clear queue"""
        if not ctx.voice_client:
            return await ctx.send("❌ Not connected to voice!")
        self.queue.clear()
        self.current = None
        ctx.voice_client.stop()
        await ctx.send("⏹ Stopped and cleared queue!")

    @commands.command(name="pause")
    async def pause(self, ctx: Context):
        """⏸ Pause playback"""
        if ctx.voice_client and ctx.voice_client.is_playing():
            ctx.voice_client.pause()
            await ctx.send("⏸ Paused!")
        else:
            await ctx.send("❌ Nothing is playing!")

    @commands.command(name="resume")
    async def resume(self, ctx: Context):
        """▶ Resume playback"""
        if ctx.voice_client and ctx.voice_client.is_paused():
            ctx.voice_client.resume()
            await ctx.send("▶ Resumed!")
        else:
            await ctx.send("❌ Nothing is paused!")

    @commands.command(name="queue", aliases=["q"])
    async def show_queue(self, ctx: Context):
        """📋 Show the music queue"""
        embed = discord.Embed(title="📋 Music Queue", color=0x5865f2)
        if self.current:
            artist, title = self._split(self.current["full_title"])
            embed.add_field(
                name="🎵 Now Playing",
                value=f"**{title}** by {artist}\nRequested by {self.current['requester'].mention}",
                inline=False,
            )
        if self.queue:
            lines = ""
            for i, s in enumerate(self.queue[:10], 1):
                _, t = self._split(s["full_title"])
                lines += f"`{i}.` **{t}** `{self._fmt(s['duration'])}`\n"
            if len(self.queue) > 10:
                lines += f"... and {len(self.queue) - 10} more"
            embed.add_field(name="📋 Up Next", value=lines, inline=False)
        else:
            embed.add_field(name="📋 Up Next", value="Queue is empty", inline=False)
        embed.set_footer(text=f"{len(self.queue)} songs in queue")
        await ctx.send(embed=embed)

    @commands.command(name="nowplaying", aliases=["nowplay"])
    async def nowplaying(self, ctx: Context):
        """🎵 Show current song with controls"""
        if not self.current:
            return await ctx.send("❌ Nothing is playing!")
        layout = MusicLayout(self, ctx, self.current, is_queued=False)
        layout_view = layout.create_layout_view()
        
        # Add select menu as ActionRow
        layout_view.add_item(discord.ui.ActionRow(layout.music_select))
        
        # Add music control buttons
        layout_view.add_item(discord.ui.ActionRow(
            layout.prev_button,
            layout.pause_button,
            layout.skip_button,
            layout.like_button,
            layout.stop_button
        ))
        
        await ctx.send(view=layout_view)

    @commands.command(name="clear")
    async def clear_queue(self, ctx: Context):
        """🗑 Clear the queue"""
        if not self.queue:
            return await ctx.send("❌ Queue is already empty!")
        n = len(self.queue)
        self.queue.clear()
        await ctx.send(f"🗑 Cleared {n} songs from queue!")

    @commands.command(name="botdeafen")
    async def deafen_bot_command(self, ctx: Context):
        """Deafen the bot"""
        if not ctx.voice_client:
            return await ctx.send("❌ Not connected to any voice channel!")
        m = ctx.guild.get_member(self.bot.user.id)
        if m and m.voice:
            await m.edit(deafen=True)
            await ctx.send("🔇 Bot deafened!")
        else:
            await ctx.send("❌ Bot is not in a voice channel!")

    @commands.command(name="undeafen")
    async def undeafen_bot_command(self, ctx: Context):
        """Undeafen the bot"""
        if not ctx.voice_client:
            return await ctx.send("❌ Not connected to any voice channel!")
        m = ctx.guild.get_member(self.bot.user.id)
        if m and m.voice:
            await m.edit(deafen=False)
            await ctx.send("🔊 Bot undeafened!")
        else:
            await ctx.send("❌ Bot is not in a voice channel!")

    @commands.command(name="vcstatus")
    async def vcstatus(self, ctx: Context):
        """Check voice connection status"""
        if ctx.voice_client:
            ch = ctx.voice_client.channel
            await ctx.send(f"🔊 Connected to **{ch.name}** ({len(ch.members)} members)")
        else:
            await ctx.send("❌ Not connected to any voice channel")

    @commands.command(name="test")
    async def test_cmd(self, ctx: Context):
        """Test if bot is responding"""
        await ctx.send("✅ Bot is working!")
    
    @commands.command(name="testqueuefinish")
    async def test_queue_finish(self, ctx: Context):
        """Test queue finished notification"""
        await self._send_queue_finished(ctx)


    @commands.command(name="volume", aliases=["vol"])
    async def volume_cmd(self, ctx: Context, volume: int = None):
        """🔊 Set volume (0-200)"""
        if volume is None:
            current_vol = int(self.volume * 100)
            return await ctx.send(f"🔊 Current volume: **{current_vol}%**")
        
        if not 0 <= volume <= 200:
            return await ctx.send("❌ Volume must be between 0 and 200!")
        
        self.volume = volume / 100
        
        # Update current playing song volume
        vc = ctx.voice_client
        if vc and vc.source:
            vc.source.volume = self.volume
        
        await ctx.send(f"🔊 Volume set to **{volume}%**")

    @commands.command(name="loop", aliases=["repeat"])
    async def loop_cmd(self, ctx: Context, mode: str = None):
        """🔁 Loop mode: off, one, all"""
        if mode is None:
            modes = {"off": "❌ Off", "one": "🔂 Repeat One", "all": "🔁 Repeat All"}
            return await ctx.send(f"Current loop mode: **{modes.get(self.loop_mode, 'Off')}**")
        
        mode = mode.lower()
        if mode not in ["off", "one", "all", "single", "queue"]:
            return await ctx.send("❌ Invalid mode! Use: `off`, `one`, or `all`")
        
        # Aliases
        if mode == "single":
            mode = "one"
        elif mode == "queue":
            mode = "all"
        
        self.loop_mode = mode
        
        modes_display = {
            "off": "❌ Loop disabled",
            "one": "🔂 Repeating current song",
            "all": "🔁 Repeating entire queue"
        }
        
# Made by Trusty X Ayaan Dev
        await ctx.send(modes_display[mode])


async def setup(bot):
    await bot.add_cog(SimpleVoice(bot))
