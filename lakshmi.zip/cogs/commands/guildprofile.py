"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
from __future__ import annotations
from discord.ext import commands
from discord import ui
import discord
import aiosqlite
from core import Cog, Lakshmi, Context
from utils.Tools import *


async def _check_guild_premium(guild_id: int, user_id: int) -> bool:
    """Returns True if this guild has premium AND the user is the registered owner for it."""
    from utils import config
# Made by Trusty X Ayaan Dev
    if user_id in config.OWNER_IDS:
        return True
    async with aiosqlite.connect('db/premium.db') as db:
        cursor = await db.execute(
            "SELECT owner_id FROM premium_guilds WHERE guild_id = ?", (guild_id,)
        )
        row = await cursor.fetchone()
    if row is None:
        return False
    return row[0] == user_id


def _premium_denied():
    container = ui.Container(accent_color=0xFF3E8A)
    container.add_item(ui.TextDisplay(
        "**Premium Required**\n"
        "This server doesn't have `lovset` access, or you're not the authorized user.\n"
        "Ask the bot owner to run `premiumguild {guild_id} {your_id}`."
    ))
    return ui.LayoutView().add_item(container)


# Created by Trusty X Ayaan
class GuildProfile(Cog):
    """Commands to customize the bot's guild-specific profile"""

    def __init__(self, bot: Lakshmi):
        self.bot = bot

    @commands.command(
        name="lovsetavatar",
        help="Set the bot's avatar for this server only",
        aliases=["setguildpfp", "setguildavatar"]
    )
    @commands.has_permissions(administrator=True)
    async def lovsetavatar(self, ctx: Context):
        """Set bot's guild-specific avatar"""
        if not await _check_guild_premium(ctx.guild.id, ctx.author.id):
            return await ctx.send(view=_premium_denied())

        if not ctx.message.attachments:
            return await ctx.send("Please attach an image while using this command.")

        attachment = ctx.message.attachments[0]
        if not attachment.content_type or not attachment.content_type.startswith('image/'):
            return await ctx.send("Please attach a valid image file.")

        try:
            avatar_bytes = await attachment.read()
            await ctx.guild.me.edit(avatar=avatar_bytes)
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay("Bot's guild avatar has been updated successfully."))
            await ctx.send(view=ui.LayoutView().add_item(container))
        except discord.HTTPException as e:
            await ctx.send(f"Failed to update avatar: {str(e)}")
        except Exception as e:
            await ctx.send(f"An error occurred: {str(e)}")

    @commands.command(
        name="lovsetbanner",
        help="Set the bot's banner for this server only",
        aliases=["setguildbanner"]
    )
    @commands.has_permissions(administrator=True)
    async def lovsetbanner(self, ctx: Context):
        """Set bot's guild-specific banner"""
        if not await _check_guild_premium(ctx.guild.id, ctx.author.id):
            return await ctx.send(view=_premium_denied())
# Trusty X Ayaan - Krishx Dev

        if not ctx.message.attachments:
            return await ctx.send("Please attach an image while using this command.")

        attachment = ctx.message.attachments[0]
        if not attachment.content_type or not attachment.content_type.startswith('image/'):
            return await ctx.send("Please attach a valid image file.")

        try:
            banner_bytes = await attachment.read()
            await ctx.guild.me.edit(banner=banner_bytes)
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay("Bot's guild banner has been updated successfully."))
            await ctx.send(view=ui.LayoutView().add_item(container))
        except discord.HTTPException as e:
            await ctx.send(f"Failed to update banner: {str(e)}")
        except Exception as e:
            await ctx.send(f"An error occurred: {str(e)}")

    @commands.command(
        name="lovsetbio",
        help="Set the bot's bio for this server only",
        aliases=["setguildbio"]
    )
    @commands.has_permissions(administrator=True)
    async def lovsetbio(self, ctx: Context, *, bio: str):
        """Set bot's guild-specific bio"""
        if not await _check_guild_premium(ctx.guild.id, ctx.author.id):
            return await ctx.send(view=_premium_denied())

        if len(bio) > 190:
            return await ctx.send("Bio must be 190 characters or less.")

        try:
            await ctx.guild.me.edit(bio=bio)
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay("Bot's guild bio has been updated successfully."))
            await ctx.send(view=ui.LayoutView().add_item(container))
        except discord.HTTPException as e:
            await ctx.send(f"Failed to update bio: {str(e)}")
        except Exception as e:
            await ctx.send(f"An error occurred: {str(e)}")

    @commands.command(
        name="lovsetname",
        help="Set the bot's nickname for this server only",
        aliases=["setguildname", "setguildnick", "setguildnickname"]
    )
    @commands.has_permissions(administrator=True)
    async def lovsetname(self, ctx: Context, *, nickname: str):
        """Set bot's guild-specific nickname"""
        if not await _check_guild_premium(ctx.guild.id, ctx.author.id):
            return await ctx.send(view=_premium_denied())

        if len(nickname) > 32:
            return await ctx.send("Nickname must be 32 characters or less.")

        try:
            await ctx.guild.me.edit(nick=nickname)
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay(f"Bot's guild nickname has been set to: {nickname}"))
            await ctx.send(view=ui.LayoutView().add_item(container))
        except discord.HTTPException as e:
            await ctx.send(f"Failed to update nickname: {str(e)}")
        except Exception as e:
            await ctx.send(f"An error occurred: {str(e)}")

    @commands.command(
        name="lovsetclear",
        help="Reset the bot's guild profile to default (avatar, banner, bio, nickname)",
        aliases=["setguildclear", "clearguildprofile", "resetguildprofile"]
    )
    @commands.has_permissions(administrator=True)
    async def lovsetclear(self, ctx: Context):
        """Reset bot's guild-specific profile to default"""
        if not await _check_guild_premium(ctx.guild.id, ctx.author.id):
            return await ctx.send(view=_premium_denied())

        try:
            await ctx.guild.me.edit(avatar=None, banner=None, bio=None, nick=None)
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay("Bot's guild profile has been reset to default successfully."))
            await ctx.send(view=ui.LayoutView().add_item(container))
        except discord.HTTPException as e:
            await ctx.send(f"Failed to reset profile: {str(e)}")
        except Exception as e:
            await ctx.send(f"An error occurred: {str(e)}")
