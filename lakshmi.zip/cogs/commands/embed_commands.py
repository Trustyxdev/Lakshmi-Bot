"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
import json
from discord import ui
from discord.ext import commands
from utils.Tools import blacklist_check, ignore_check
# Made by Trusty X Ayaan Dev


# Code by Trusty X Ayaan
class EmbedModal(ui.Modal, title="Create Embed"):
    def __init__(self, ctx, embed_cog):
        super().__init__()
        self.ctx = ctx
        self.embed_cog = embed_cog

        self.title_input = ui.TextInput(
            label="Title",
            placeholder="Enter embed title",
            required=False,
            max_length=256
        )
        self.add_item(self.title_input)

        self.description_input = ui.TextInput(
            label="Description",
            placeholder="Enter embed description",
            style=discord.TextStyle.paragraph,
            required=False,
            max_length=4000
        )
        self.add_item(self.description_input)

        self.color_input = ui.TextInput(
            label="Color (hex code, e.g., 000000)",
            placeholder="000000",
            required=False,
            max_length=6
        )
        self.add_item(self.color_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            color = 0x000000
            if self.color_input.value:
                color = int(self.color_input.value, 16)

            embed = discord.Embed(
                title=self.title_input.value or None,
                description=self.description_input.value or None,
                color=color
            )

            await self.ctx.reply(embed=embed)
            await interaction.response.defer()
        except ValueError:
            await interaction.response.send_message(
                "Invalid color code. Use hex format (e.g., FF0000)",
                ephemeral=True
            )


class EmbedBuilder(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/bot_database.db") as db:
            await db.execute(
                """CREATE TABLE IF NOT EXISTS saved_embeds (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER,
                    name TEXT,
                    embed_data TEXT,
                    created_by INTEGER,
                    created_at TEXT,
                    UNIQUE(guild_id, name)
                )"""
            )
            await db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000
        )
        for key, value in kwargs.items():
            if value:
                embed.add_field(name=key, value=value, inline=False)
        return embed

    @commands.group(name="embed", invoke_without_command=True)
    @commands.has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def embed(self, ctx):
        """Create and manage embeds"""
        await ctx.send_help(ctx.command)

    @embed.command(name="create")
    @commands.has_permissions(manage_messages=True)
    async def embed_create(self, ctx):
        """Create a new embed"""
        modal = EmbedModal(ctx, self)
        await ctx.interaction.response.send_modal(modal) if hasattr(ctx, 'interaction') else None

    @embed.command(name="send")
    @commands.has_permissions(manage_messages=True)
    async def embed_send(self, ctx, *, embed_json: str):
        """Send an embed from JSON"""
        try:
            embed_data = json.loads(embed_json)
            embed = discord.Embed.from_dict(embed_data)
            embed.color = 0x000000
            await ctx.send(embed=embed)
        except json.JSONDecodeError:
            embed = self.create_embed(
                "❌ Invalid JSON",
                "Please provide valid JSON for the embed."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to send embed: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @embed.command(name="save")
    @commands.has_permissions(manage_messages=True)
    async def embed_save(self, ctx, name: str, *, embed_json: str):
# Trusty X Ayaan - discord.gg/ibadat
        """Save an embed for later use"""
        try:
            embed_data = json.loads(embed_json)
            
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO saved_embeds 
                    (guild_id, name, embed_data, created_by, created_at)
                    VALUES (?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, name.lower(), embed_json, ctx.author.id)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Embed Saved",
                f"Embed '{name}' has been saved."
            )
            await ctx.reply(embed=embed)
        except json.JSONDecodeError:
            embed = self.create_embed(
                "❌ Invalid JSON",
                "Please provide valid JSON for the embed."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to save embed: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @embed.command(name="load")
    @commands.has_permissions(manage_messages=True)
    async def embed_load(self, ctx, name: str):
        """Load and send a saved embed"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT embed_data FROM saved_embeds WHERE guild_id = ? AND name = ?",
                    (ctx.guild.id, name.lower())
                )
                row = await cursor.fetchone()

                if not row:
                    embed = self.create_embed(
                        "❌ Embed Not Found",
                        f"No saved embed named '{name}'."
                    )
                    return await ctx.reply(embed=embed)

                embed_data = json.loads(row[0])
                embed = discord.Embed.from_dict(embed_data)
                embed.color = 0x000000
                await ctx.send(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to load embed: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @embed.command(name="list")
    @commands.has_permissions(manage_messages=True)
    async def embed_list(self, ctx):
        """List all saved embeds"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    "SELECT * FROM saved_embeds WHERE guild_id = ? ORDER BY created_at DESC",
                    (ctx.guild.id,)
                )
                embeds = await cursor.fetchall()

            if not embeds:
                embed = self.create_embed(
                    "📋 Saved Embeds",
                    "No saved embeds found."
                )
                return await ctx.reply(embed=embed)

            embed_text = ""
            for idx, saved_embed in enumerate(embeds, 1):
                creator = self.bot.get_user(saved_embed['created_by'])
                creator_name = creator.mention if creator else f"Unknown ({saved_embed['created_by']})"
                embed_text += f"**{idx}.** `{saved_embed['name']}`\n"
                embed_text += f"   Created by: {creator_name}\n"

            embed = self.create_embed(
                "📋 Saved Embeds",
                embed_text
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to fetch embeds: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @embed.command(name="delete")
    @commands.has_permissions(manage_messages=True)
    async def embed_delete(self, ctx, name: str):
        """Delete a saved embed"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM saved_embeds WHERE guild_id = ? AND name = ?",
                    (ctx.guild.id, name.lower())
                )
                existing = await cursor.fetchone()

                if not existing:
                    embed = self.create_embed(
                        "❌ Embed Not Found",
                        f"No saved embed named '{name}'."
                    )
                    return await ctx.reply(embed=embed)

                await db.execute(
                    "DELETE FROM saved_embeds WHERE guild_id = ? AND name = ?",
                    (ctx.guild.id, name.lower())
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Embed Deleted",
                f"Embed '{name}' has been deleted."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to delete embed: {str(e)}"
            )
            await ctx.reply(embed=embed)


async def setup(bot):
    await bot.add_cog(EmbedBuilder(bot))
