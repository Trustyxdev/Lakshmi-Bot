# -*- coding: utf-8 -*-
"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""

import discord
from discord.ext import commands
from discord import ui, app_commands
import datetime
import aiosqlite
from core import Context
from core.Cog import Cog
from utils.logger import logger

# Made by Trusty X Ayaan Dev
class Premium(Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect('db/premium.db') as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS premium_users (
                    user_id INTEGER PRIMARY KEY,
                    guild_id INTEGER,
                    expiry_date INTEGER,
                    duration TEXT
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS premium_guilds (
                    guild_id INTEGER PRIMARY KEY,
                    owner_id INTEGER NOT NULL,
                    added_by INTEGER,
                    added_at INTEGER
                )
            """)
            await db.commit()

    async def is_premium(self, user_id: int) -> bool:
        """Check if user is premium"""
        async with aiosqlite.connect('db/premium.db') as db:
            cursor = await db.execute(
                "SELECT expiry_date FROM premium_users WHERE user_id = ?",
                (user_id,)
            )
            result = await cursor.fetchone()
            
            if result:
                expiry = result[0]
                if expiry > int(datetime.datetime.now().timestamp()):
                    return True
                else:
                    # Remove expired premium
                    await db.execute("DELETE FROM premium_users WHERE user_id = ?", (user_id,))
                    await db.commit()
            
            return False



    @commands.hybrid_command(name="padd", aliases=["premiumadd"])
    @commands.is_owner()
    @app_commands.describe(
        user="User to add premium",
        guild_id="Guild ID (optional, for guild-specific premium)",
        duration="Duration (1m, 2m, 3m, 6m, 1y, permanent)"
    )
    async def padd(self, ctx: Context, user: discord.User, guild_id: str = None, duration: str = "permanent"):
        """Add premium to a user (Owner only)
        
        Usage: padd @user [guild_id] [duration]
        Durations: 1m, 2m, 3m, 6m, 1y, permanent
        """
        import os
        try:
            from dotenv import load_dotenv
            load_dotenv()
        except ImportError:
            pass  # Environment variables already loaded
        
        # Parse duration
        duration_lower = duration.lower()
        duration_map = {
            "1m": 30 * 24 * 3600,      # 30 days
            "2m": 60 * 24 * 3600,      # 60 days
            "3m": 90 * 24 * 3600,      # 90 days
            "6m": 180 * 24 * 3600,     # 180 days
            "1y": 365 * 24 * 3600,     # 365 days
            "permanent": 999999999999  # Very large number
        }
        
        if duration_lower not in duration_map:
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay(
                f"Invalid Duration!\n\n"
                f"Valid options: 1m, 2m, 3m, 6m, 1y, permanent"
            ))
            view = ui.LayoutView()
            view.add_item(container)
            return await ctx.reply(view=view)
        
        seconds = duration_map[duration_lower]
        expiry_timestamp = int(datetime.datetime.now().timestamp()) + seconds
        
        # Use provided guild_id or current guild
        target_guild_id = int(guild_id) if guild_id else (ctx.guild.id if ctx.guild else 0)
        
        # Add to database
        async with aiosqlite.connect('db/premium.db') as db:
            await db.execute(
                "INSERT OR REPLACE INTO premium_users (user_id, guild_id, expiry_date, duration) VALUES (?, ?, ?, ?)",
                (user.id, target_guild_id, expiry_timestamp, duration_lower)
            )
            await db.commit()
        
        # Update .env file
        env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), '.env')
        
        try:
            # Read current .env
            with open(env_path, 'r') as f:
                env_content = f.read()
            
            # Check if PREMIUM_IDS exists
            if 'PREMIUM_IDS=' in env_content:
                # Extract current IDs
                import re
                match = re.search(r'PREMIUM_IDS=(.+?)(?:\n|$)', env_content)
                if match:
                    current_ids = match.group(1).strip()
                    if str(user.id) not in current_ids:
                        new_ids = f"{current_ids},{user.id}" if current_ids else str(user.id)
                        env_content = re.sub(r'PREMIUM_IDS=.+?(?=\n|$)', f'PREMIUM_IDS={new_ids}', env_content)
            else:
                # Add PREMIUM_IDS if it doesn't exist
                env_content += f"\n\nPREMIUM_IDS={user.id}"
            
            # Write back to .env
            with open(env_path, 'w') as f:
                f.write(env_content)
            
            # Reload environment variables
            load_dotenv(env_path, override=True)
            
            # Update config module
            from utils import config
            config.PREMIUM_IDS = [int(id.strip()) for id in os.getenv('PREMIUM_IDS', '').split(',') if id.strip()]
            
        except Exception as e:
            logger.error(f"Error updating .env: {e}")
        
        guild_info = f" (Guild: {target_guild_id})" if guild_id else ""
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(
            f"✅ Premium Added!\n\n"
            f"**User:** {user.mention}\n"
            f"**Duration:** {duration_lower}{guild_info}\n"
# Trusty X Ayaan - discord.gg/ibadat
            f"**Status:** Active"
        ))
        view = ui.LayoutView()
        view.add_item(container)
        await ctx.reply(view=view)

    @commands.hybrid_command(name="pstatus")
    async def pstatus(self, ctx: Context):
        """Check your premium status"""
        from utils.config import OWNER_IDS, PREMIUM_IDS
        is_owner = ctx.author.id in OWNER_IDS
        is_premium = ctx.author.id in PREMIUM_IDS
        
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(
            f"**Your Status:**\n"
            f"Owner: {'✅ Yes' if is_owner else '❌ No'}\n"
            f"Premium: {'✅ Yes' if is_premium else '❌ No'}\n"
            f"Your ID: {ctx.author.id}"
        ))
        view = ui.LayoutView()
        view.add_item(container)
        await ctx.reply(view=view)

    @commands.hybrid_command(name="premove", aliases=["premiumremove"])
    @commands.is_owner()
    @app_commands.describe(user="User to remove premium")
    async def premove(self, ctx: Context, user: discord.User):
        """Remove premium from a user (Owner only)
        
        Usage: premove @user
        """
        import os
        import re
        try:
            from dotenv import load_dotenv
            load_dotenv()
        except ImportError:
            pass  # Environment variables already loaded
        
        # Remove from database
        async with aiosqlite.connect('db/premium.db') as db:
            await db.execute("DELETE FROM premium_users WHERE user_id = ?", (user.id,))
            await db.commit()
        
        # Update .env file
        env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), '.env')
        
        try:
            # Read current .env
            with open(env_path, 'r') as f:
                env_content = f.read()
            
            # Remove user ID from PREMIUM_IDS
            if 'PREMIUM_IDS=' in env_content:
                match = re.search(r'PREMIUM_IDS=(.+?)(?:\n|$)', env_content)
                if match:
                    current_ids = match.group(1).strip()
                    ids_list = [id.strip() for id in current_ids.split(',') if id.strip() and id.strip() != str(user.id)]
                    new_ids = ','.join(ids_list)
                    env_content = re.sub(r'PREMIUM_IDS=.+?(?=\n|$)', f'PREMIUM_IDS={new_ids}', env_content)
            
            # Write back to .env
            with open(env_path, 'w') as f:
                f.write(env_content)
            
            # Reload environment variables
            load_dotenv(env_path, override=True)
            
            # Update config module
            from utils import config
            config.PREMIUM_IDS = [int(id.strip()) for id in os.getenv('PREMIUM_IDS', '').split(',') if id.strip()]
            
        except Exception as e:
            logger.error(f"Error updating .env: {e}")
        
        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(
            f"✅ Premium Removed!\n\n"
            f"**User:** {user.mention}\n"
            f"**Status:** Inactive"
        ))
        view = ui.LayoutView()
        view.add_item(container)
        await ctx.reply(view=view)

    @commands.command(name="premiumguild", aliases=["pguild"])
    @commands.is_owner()
    async def premiumguild(self, ctx: Context, guild_id: int = None, owner_id: int = None):
        """Grant a specific guild access to lovset commands (Owner only)
        
        Usage: premiumguild {guild_id} {owner_id}
        Only the registered owner_id can use lovset commands in that guild.
        """
        if guild_id is None or owner_id is None:
            container = ui.Container(accent_color=0xFF3E8A)
            container.add_item(ui.TextDisplay(
                "**Missing Arguments**\n\n"
                "Usage: `premiumguild <guild_id> <owner_id>`\n\n"
                "Example: `premiumguild 123456789012345678 987654321098765432`"
            ))
            return await ctx.reply(view=ui.LayoutView().add_item(container))

        import datetime as dt
# © Trusty X Ayaan Development
        async with aiosqlite.connect('db/premium.db') as db:
            await db.execute(
                "INSERT OR REPLACE INTO premium_guilds (guild_id, owner_id, added_by, added_at) VALUES (?, ?, ?, ?)",
                (guild_id, owner_id, ctx.author.id, int(dt.datetime.now().timestamp()))
            )
            await db.commit()

        guild = self.bot.get_guild(guild_id)
        guild_name = guild.name if guild else str(guild_id)

        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(
            f"✅ **Premium Guild Added!**\n\n"
            f"**Guild:** {guild_name} (`{guild_id}`)\n"
            f"**Authorized Owner:** `{owner_id}`\n\n"
            f"That user can now use `lovset*` commands in that server only."
        ))
        await ctx.reply(view=ui.LayoutView().add_item(container))

    @commands.command(name="premiumguildremove", aliases=["pguildremove"])
    @commands.is_owner()
    async def premiumguildremove(self, ctx: Context, guild_id: int):
        """Remove a guild's lovset premium access (Owner only)"""
        async with aiosqlite.connect('db/premium.db') as db:
            await db.execute("DELETE FROM premium_guilds WHERE guild_id = ?", (guild_id,))
            await db.commit()

        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay(
            f"✅ **Premium Guild Removed!**\n\n"
            f"Guild `{guild_id}` no longer has `lovset*` access."
        ))
        await ctx.reply(view=ui.LayoutView().add_item(container))

    @commands.command(name="pguildlist")
    @commands.is_owner()
    async def pguildlist(self, ctx: Context):
        """List all premium guilds (Owner only)"""
        async with aiosqlite.connect('db/premium.db') as db:
            cursor = await db.execute("SELECT guild_id, owner_id FROM premium_guilds")
            rows = await cursor.fetchall()

        if not rows:
            return await ctx.reply("No premium guilds registered.")

        lines = []
        for guild_id, owner_id in rows:
            guild = self.bot.get_guild(guild_id)
            name = guild.name if guild else "Unknown"
            lines.append(f"• **{name}** (`{guild_id}`) — owner `{owner_id}`")

        container = ui.Container(accent_color=None)
        container.add_item(ui.TextDisplay("**Premium Guilds**\n\n" + "\n".join(lines)))
        await ctx.reply(view=ui.LayoutView().add_item(container))


async def setup(bot):
    await bot.add_cog(Premium(bot))
