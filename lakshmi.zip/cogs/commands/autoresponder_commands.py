"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
from discord.ext import commands
from utils.Tools import blacklist_check, ignore_check
# Dev: Trusty X Ayaan


# Trusty X Ayaan © 2024
class AutoResponder(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/bot_database.db") as db:
            await db.execute(
                """CREATE TABLE IF NOT EXISTS auto_responses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER,
                    trigger TEXT,
                    response TEXT,
                    case_sensitive INTEGER DEFAULT 0,
                    created_by INTEGER,
                    created_at TEXT,
                    UNIQUE(guild_id, trigger)
                )"""
            )
            await db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000
        )
        for key, value in kwargs.items():
            if value:
                embed.add_field(name=key, value=value, inline=False)
        return embed

    @commands.group(name="autorespond", invoke_without_command=True)
    @commands.has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def autorespond(self, ctx):
        """Manage auto-responses"""
        await ctx.send_help(ctx.command)

    @autorespond.command(name="add")
    @commands.has_permissions(manage_messages=True)
    async def autorespond_add(self, ctx, trigger: str, *, response: str):
        """Add an auto-response"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO auto_responses 
                    (guild_id, trigger, response, created_by, created_at)
                    VALUES (?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, trigger.lower(), response, ctx.author.id)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Auto-Response Added",
                f"Trigger: `{trigger}`\nResponse: {response[:100]}{'...' if len(response) > 100 else ''}"
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to add auto-response: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @autorespond.command(name="remove")
    @commands.has_permissions(manage_messages=True)
    async def autorespond_remove(self, ctx, trigger: str):
        """Remove an auto-response"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM auto_responses WHERE guild_id = ? AND trigger = ?",
                    (ctx.guild.id, trigger.lower())
                )
                existing = await cursor.fetchone()

                if not existing:
                    embed = self.create_embed(
                        "❌ Not Found",
                        f"No auto-response found for trigger: `{trigger}`"
                    )
                    return await ctx.reply(embed=embed)

                await db.execute(
                    "DELETE FROM auto_responses WHERE guild_id = ? AND trigger = ?",
                    (ctx.guild.id, trigger.lower())
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Auto-Response Removed",
                f"Removed auto-response for trigger: `{trigger}`"
            )
            await ctx.reply(embed=embed)
        except Exception as e:
# Created by Trusty X Ayaan
            embed = self.create_embed(
                "❌ Error",
                f"Failed to remove auto-response: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @autorespond.command(name="list")
    @commands.has_permissions(manage_messages=True)
    async def autorespond_list(self, ctx):
        """List all auto-responses"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    "SELECT * FROM auto_responses WHERE guild_id = ? ORDER BY created_at DESC",
                    (ctx.guild.id,)
                )
                responses = await cursor.fetchall()

            if not responses:
                embed = self.create_embed(
                    "📋 Auto-Responses",
                    "No auto-responses configured."
                )
                return await ctx.reply(embed=embed)

            response_text = ""
            for idx, resp in enumerate(responses, 1):
                response_preview = resp['response'][:50] + "..." if len(resp['response']) > 50 else resp['response']
                response_text += f"**{idx}.** Trigger: `{resp['trigger']}`\n"
                response_text += f"   Response: {response_preview}\n"

            embed = self.create_embed(
                "📋 Auto-Responses",
                response_text
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to fetch auto-responses: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @autorespond.command(name="clear")
    @commands.has_permissions(manage_messages=True)
    async def autorespond_clear(self, ctx):
        """Clear all auto-responses"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT COUNT(*) FROM auto_responses WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                count = await cursor.fetchone()

                if count[0] == 0:
                    embed = self.create_embed(
                        "❌ No Responses",
                        "There are no auto-responses to clear."
                    )
                    return await ctx.reply(embed=embed)

                await db.execute(
                    "DELETE FROM auto_responses WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Auto-Responses Cleared",
                f"Removed **{count[0]}** auto-responses."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to clear auto-responses: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    "SELECT * FROM auto_responses WHERE guild_id = ?",
                    (message.guild.id,)
                )
                responses = await cursor.fetchall()

                for resp in responses:
                    trigger = resp['trigger']
                    content = message.content.lower() if not resp['case_sensitive'] else message.content
                    
                    if trigger in content:
                        try:
                            await message.reply(resp['response'], mention_author=False)
                        except:
                            pass
                        break
        except:
# Trusty X Ayaan - discord.gg/ibadat
            pass


async def setup(bot):
    await bot.add_cog(AutoResponder(bot))
