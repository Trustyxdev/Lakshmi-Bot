"""
Owner Status Management - Bot Status & Activity Control
Only bot owners can use these commands
"""
import discord
from discord.ext import commands
from discord import ui
from core import Cog, Context


class OwnerStatus(Cog):
    """Owner-only commands for bot status management"""

    def __init__(self, bot):
        self.bot = bot
        # Define bot owners (add your Discord IDs here)
        self.owners = [1414058403202072688, 1442939274982068335]
        
        # Store current status and activity to persist across reconnects
        self.current_status = discord.Status.online  # Default to online
        self.current_activity = None

    def is_owner(self, user_id: int) -> bool:
        """Check if user is bot owner"""
        return user_id in self.owners
    
    @commands.Cog.listener()
    async def on_ready(self):
        """Restore status on reconnect"""
        # Restore the saved status and activity
        await self.bot.change_presence(status=self.current_status, activity=self.current_activity)
        print(f"✅ Status restored: {self.current_status.name}")
        if self.current_activity:
            print(f"✅ Activity restored: {self.current_activity.name}")

    @commands.command(name="own", aliases=["ownerhelp", "ownhelp"])
    async def owner_help(self, ctx: Context):
        """Show all owner-only commands"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        # Create beautiful embed with all owner commands
        view = ui.LayoutView(timeout=300.0)
        container = ui.Container(accent_color=None)
        
        arrow = "➜"
        
        container.add_item(ui.TextDisplay("# Owner Commands"))
        container.add_item(ui.Separator())
        
        # Status Commands
        status_cmds = (
            f"**Bot Status**\n"
            f"{arrow} `.setonline` - Set status to Online\n"
            f"{arrow} `.setidle` - Set status to Idle\n"
            f"{arrow} `.setdnd` - Set status to Do Not Disturb\n"
            f"{arrow} `.setinvisible` - Set status to Invisible"
        )
        container.add_item(ui.TextDisplay(status_cmds))
        container.add_item(ui.Separator())
        
        # Activity Commands
        activity_cmds = (
            f"**Bot Activity**\n"
            f"{arrow} `.setplaying <text>` - Playing\n"
            f"{arrow} `.setwatching <text>` - Watching\n"
            f"{arrow} `.setlistening <text>` - Listening to\n"
            f"{arrow} `.setstreaming <text>` - Streaming\n"
            f"{arrow} `.setcompeting <text>` - Competing in\n"
            f"{arrow} `.clearactivity` - Remove activity"
        )
        container.add_item(ui.TextDisplay(activity_cmds))
        container.add_item(ui.Separator())
        
        # Combined Commands
        combined_cmds = (
            f"**Quick Setup**\n"
            f"{arrow} `.setpresence <status> <type> <text>`\n\n"
            f"**Example:**\n"
            f"`setpresence online listening !help`"
        )
        container.add_item(ui.TextDisplay(combined_cmds))
        container.add_item(ui.Separator())
        
        container.add_item(ui.TextDisplay("**Owner Only** • Lakshmi Bot"))
        
        view.add_item(container)
        await ctx.send(view=view)

    # ═══════════════════════════════════════════════════════════
    # STATUS COMMANDS
    # ═══════════════════════════════════════════════════════════

    @commands.command(name="setonline")
    async def set_online(self, ctx: Context):
        """Set bot status to Online (Green)"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        self.current_status = discord.Status.online
        await self.bot.change_presence(status=self.current_status, activity=self.current_activity)
        await ctx.send("<:exquisite_angel_heart:1488945405663121561> Status set to **Online**")

    @commands.command(name="setidle")
    async def set_idle(self, ctx: Context):
        """Set bot status to Idle (Yellow)"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        self.current_status = discord.Status.idle
        await self.bot.change_presence(status=self.current_status, activity=self.current_activity)
        await ctx.send("<:Hellnah:1488950853837656084> Status set to **Idle**")

    @commands.command(name="setdnd")
    async def set_dnd(self, ctx: Context):
        """Set bot status to Do Not Disturb (Red)"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        self.current_status = discord.Status.dnd
        await self.bot.change_presence(status=self.current_status, activity=self.current_activity)
        await ctx.send("<:Kiri_love:1488950872607031449> Status set to **Do Not Disturb**")

    @commands.command(name="setinvisible")
    async def set_invisible(self, ctx: Context):
        """Set bot status to Invisible (Gray)"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        self.current_status = discord.Status.invisible
        await self.bot.change_presence(status=self.current_status, activity=self.current_activity)
        await ctx.send("<:11:1488950863186759710> Status set to **Invisible**")

    # ═══════════════════════════════════════════════════════════
    # ACTIVITY COMMANDS
    # ═══════════════════════════════════════════════════════════

    @commands.command(name="setplaying")
    async def set_playing(self, ctx: Context, *, text: str):
        """Set bot activity to Playing"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        self.current_activity = discord.Game(name=text)
        await self.bot.change_presence(status=self.current_status, activity=self.current_activity)
        await ctx.send(f"<:FanGirl:1488950858791256246> Now playing: **{text}**")

    @commands.command(name="setwatching")
    async def set_watching(self, ctx: Context, *, text: str):
        """Set bot activity to Watching"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        self.current_activity = discord.Activity(type=discord.ActivityType.watching, name=text)
        await self.bot.change_presence(status=self.current_status, activity=self.current_activity)
        await ctx.send(f"<:DSlay:1488950867733250229> Now watching: **{text}**")

    @commands.command(name="setlistening")
    async def set_listening(self, ctx: Context, *, text: str):
        """Set bot activity to Listening"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        self.current_activity = discord.Activity(type=discord.ActivityType.listening, name=text)
        await self.bot.change_presence(status=self.current_status, activity=self.current_activity)
        await ctx.send(f"<:Krishna_ji_c2h:1488950877430616086> Now listening to: **{text}**")

    @commands.command(name="setstreaming")
    async def set_streaming(self, ctx: Context, *, text: str):
        """Set bot activity to Streaming"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        self.current_activity = discord.Streaming(name=text, url="https://twitch.tv/placeholder")
        await self.bot.change_presence(status=self.current_status, activity=self.current_activity)
        await ctx.send(f"<a:Mingle:1488945411090677841> Now streaming: **{text}**")

    @commands.command(name="setcompeting")
    async def set_competing(self, ctx: Context, *, text: str):
        """Set bot activity to Competing"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        self.current_activity = discord.Activity(type=discord.ActivityType.competing, name=text)
        await self.bot.change_presence(status=self.current_status, activity=self.current_activity)
        await ctx.send(f"<a:c1_milkandmocha:1488945399837229078> Now competing in: **{text}**")

    @commands.command(name="clearactivity")
    async def clear_activity(self, ctx: Context):
        """Remove bot activity"""
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        self.current_activity = None
        await self.bot.change_presence(status=self.current_status, activity=None)
        await ctx.send("<:OSlay:1488950867733250229> Activity cleared")

    # ═══════════════════════════════════════════════════════════
    # COMBINED COMMAND
    # ═══════════════════════════════════════════════════════════

    @commands.command(name="setpresence")
    async def set_presence(self, ctx: Context, status: str, activity_type: str = None, *, text: str = None):
        """Set both status and activity at once
        
        Usage: .setpresence <status> <type> <text>
        Status: online, idle, dnd, invisible
        Type: playing, watching, listening, streaming, competing
        """
        if not self.is_owner(ctx.author.id):
            return await ctx.send("❌ This command is only for bot owners!")

        # Parse status
        status_map = {
            "online": discord.Status.online,
            "idle": discord.Status.idle,
            "dnd": discord.Status.dnd,
            "invisible": discord.Status.invisible
        }
        
        status_obj = status_map.get(status.lower())
        if not status_obj:
            return await ctx.send("❌ Invalid status! Use: online, idle, dnd, or invisible")

        # Parse activity
        activity = None
        if activity_type and text:
            activity_type = activity_type.lower()
            
            if activity_type == "playing":
                activity = discord.Game(name=text)
            elif activity_type == "watching":
                activity = discord.Activity(type=discord.ActivityType.watching, name=text)
            elif activity_type == "listening":
                activity = discord.Activity(type=discord.ActivityType.listening, name=text)
            elif activity_type == "streaming":
                activity = discord.Streaming(name=text, url="https://twitch.tv/placeholder")
            elif activity_type == "competing":
                activity = discord.Activity(type=discord.ActivityType.competing, name=text)
            else:
                return await ctx.send("❌ Invalid activity type! Use: playing, watching, listening, streaming, or competing")

        # Set presence
        await self.bot.change_presence(status=status_obj, activity=activity)
        
        status_emoji = {"online": "🟢", "idle": "🟡", "dnd": "🔴", "invisible": "⚫"}
        msg = f"{status_emoji.get(status.lower(), '✅')} Status: **{status.title()}**"
        if activity:
            msg += f"\n{activity_type.title()}: **{text}**"
        
        await ctx.send(msg)

    def help_custom(self):
        """Return help info for this cog"""
        return ("👑", "Owner Status", "Bot status and activity management (Owner only)")


async def setup(bot):
    await bot.add_cog(OwnerStatus(bot))
