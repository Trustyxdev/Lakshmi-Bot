"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import asyncio
import yt_dlp
from discord.ext import commands
from core import Cog, Context
from utils.Tools import *
import os
import json
from typing import Dict, List, Optional
import time


class Song:
    """Represents a song in the queue"""
    def __init__(self, url: str, title: str, duration: int, thumbnail: str, requester: discord.Member):
        self.url = url
        self.title = title
        self.duration = duration
        self.thumbnail = thumbnail
        self.requester = requester
        self.start_time = None

    def format_duration(self):
        """Format duration in MM:SS format"""
        if self.duration:
            minutes, seconds = divmod(self.duration, 60)
            return f"{minutes:02d}:{seconds:02d}"
        return "Unknown"


class MusicPlayer:
    """Music player for a guild"""
    def __init__(self, guild_id: int):
        self.guild_id = guild_id
        self.queue: List[Song] = []
        self.current_song: Optional[Song] = None
        self.is_looping = False
        self.is_queue_looping = False
        self.volume = 100
        self.is_paused = False
        self.message: Optional[discord.Message] = None
        self.last_activity = time.time()

    def add_song(self, song: Song):
        """Add a song to the queue"""
        self.queue.append(song)
        self.last_activity = time.time()

    def get_next_song(self) -> Optional[Song]:
        """Get the next song from queue"""
        if self.is_looping and self.current_song:
            return self.current_song
        
        if self.queue:
            song = self.queue.pop(0)
            if self.is_queue_looping and self.current_song:
                self.queue.append(self.current_song)
            return song
        return None

    def skip_song(self):
        """Skip current song"""
        if self.is_looping:
            self.is_looping = False
        self.last_activity = time.time()

    def toggle_loop(self):
        """Toggle loop for current song"""
        self.is_looping = not self.is_looping
        return self.is_looping

    def toggle_queue_loop(self):
        """Toggle loop for entire queue"""
        self.is_queue_looping = not self.is_queue_looping
        return self.is_queue_looping

    def clear_queue(self):
        """Clear the queue"""
        self.queue.clear()
        self.last_activity = time.time()


class MusicView(discord.ui.View):
    """Interactive music player view with buttons"""
    
    def __init__(self, music_cog, ctx):
        super().__init__(timeout=300)
        self.music_cog = music_cog
        self.ctx = ctx
        self.guild_id = ctx.guild.id

    @discord.ui.button(label="⏸️ Pause", style=discord.ButtonStyle.primary)
    async def pause_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("❌ Only the requester can control playback!", ephemeral=True)
        
        voice_client = self.ctx.voice_client
        if voice_client and voice_client.is_playing():
            voice_client.pause()
            button.label = "▶️ Resume"
            await interaction.response.edit_message(view=self)
        elif voice_client and voice_client.is_paused():
            voice_client.resume()
            button.label = "⏸️ Pause"
            await interaction.response.edit_message(view=self)
        else:
            await interaction.response.send_message("❌ Nothing is playing!", ephemeral=True)

    @discord.ui.button(label="⏭️ Skip", style=discord.ButtonStyle.primary)
    async def skip_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("❌ Only the requester can control playback!", ephemeral=True)
        
        voice_client = self.ctx.voice_client
        if voice_client and (voice_client.is_playing() or voice_client.is_paused()):
            player = self.music_cog.players.get(self.guild_id)
            if player:
                player.skip_song()
            voice_client.stop()
            await interaction.response.send_message("⏭️ Skipped!", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Nothing is playing!", ephemeral=True)

    @discord.ui.button(label="⏹️ Stop", style=discord.ButtonStyle.danger)
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("❌ Only the requester can control playback!", ephemeral=True)
        
        voice_client = self.ctx.voice_client
        if voice_client:
            player = self.music_cog.players.get(self.guild_id)
            if player:
                player.clear_queue()
                player.current_song = None
            voice_client.stop()
            await interaction.response.send_message("⏹️ Stopped and cleared queue!", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Not connected to voice!", ephemeral=True)

    @discord.ui.button(label="🔁 Loop", style=discord.ButtonStyle.secondary)
    async def loop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("❌ Only the requester can control playback!", ephemeral=True)
        
        player = self.music_cog.players.get(self.guild_id)
        if player and player.current_song:
            is_looping = player.toggle_loop()
            if is_looping:
                button.label = "🔁 Loop ON"
                button.style = discord.ButtonStyle.success
            else:
                button.label = "🔁 Loop"
                button.style = discord.ButtonStyle.secondary
            
            await interaction.response.edit_message(view=self)
            await self.music_cog.update_now_playing(self.ctx)
        else:
            await interaction.response.send_message("❌ No song is playing!", ephemeral=True)

    @discord.ui.button(label="🔀 Shuffle", style=discord.ButtonStyle.secondary)
    async def shuffle_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("❌ Only the requester can control playback!", ephemeral=True)
        
        player = self.music_cog.players.get(self.guild_id)
        if player and player.queue:
            import random
            random.shuffle(player.queue)
            await interaction.response.send_message("🔀 Queue shuffled!", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Queue is empty!", ephemeral=True)


class MusicYTDL(Cog):
    """YouTube-DL Music System - Advanced Player with Queue"""

    def __init__(self, bot):
        self.bot = bot
        self.players: Dict[int, MusicPlayer] = {}
        
        # FFmpeg executable path (Windows winget installation)
        import os
        username = os.environ.get('USERNAME', 'ayaan')
        self.ffmpeg_path = f"C:\\Users\\{username}\\AppData\\Local\\Microsoft\\WinGet\\Packages\\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\\ffmpeg-8.1-full_build\\bin\\ffmpeg.exe"
        
        # Fallback paths if the main one doesn't exist
        if not os.path.exists(self.ffmpeg_path):
            fallback_paths = [
                "ffmpeg",  # If in PATH
                "C:\\ffmpeg\\bin\\ffmpeg.exe",  # Common manual installation
                "ffmpeg.exe"  # Current directory
            ]
            for path in fallback_paths:
                try:
                    # Test if this path works
                    import subprocess
                    subprocess.run([path, "-version"], capture_output=True, timeout=5)
                    self.ffmpeg_path = path
                    break
                except:
                    continue
        
        # YouTube-DL options
        self.ytdl_format_options = {
            'format': 'bestaudio/best',
            'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
            'restrictfilenames': True,
            'noplaylist': True,
            'nocheckcertificate': True,
            'ignoreerrors': False,
            'logtostderr': False,
            'quiet': True,
            'no_warnings': True,
            'default_search': 'auto',
            'source_address': '0.0.0.0'
        }
        
        self.ffmpeg_options = {
            'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
            'options': '-vn'
        }
        
        self.ytdl = yt_dlp.YoutubeDL(self.ytdl_format_options)

    def get_player(self, guild_id: int) -> MusicPlayer:
        """Get or create a music player for a guild"""
        if guild_id not in self.players:
            self.players[guild_id] = MusicPlayer(guild_id)
        return self.players[guild_id]

    async def search_song(self, query: str) -> Optional[dict]:
        """Search for a song and return info"""
        try:
            loop = asyncio.get_event_loop()
            search_query = f"ytsearch1:{query}"
            data = await loop.run_in_executor(None, lambda: self.ytdl.extract_info(search_query, download=False))
            
            if 'entries' in data and len(data['entries']) > 0:
                return data['entries'][0]
            return None
        except Exception as e:
            print(f"Search error: {e}")
            return None

    async def play_next(self, ctx: Context):
        """Play the next song in queue"""
        player = self.get_player(ctx.guild.id)
        voice_client = ctx.voice_client
        
        if not voice_client:
            return
        
        next_song = player.get_next_song()
        if next_song:
            player.current_song = next_song
            next_song.start_time = time.time()
            
            try:
                # Create audio source
                audio_source = discord.FFmpegPCMAudio(
                    next_song.url,
                    executable=self.ffmpeg_path,
                    before_options='-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
                    options='-vn -loglevel quiet'
                )
                
                # Play with after callback for next song
                voice_client.play(audio_source, after=lambda e: asyncio.run_coroutine_threadsafe(self.play_next(ctx), self.bot.loop))
                
                # Update now playing message
                await self.update_now_playing(ctx)
                
            except Exception as e:
                await ctx.send(f"❌ Error playing song: {str(e)}")
                await self.play_next(ctx)  # Try next song
        else:
            # Queue is empty - send notification
            player.current_song = None
            
            try:
                # Create beautiful embed for queue finished
                view = discord.ui.LayoutView(timeout=60.0)
                container = discord.ui.Container(accent_color=None)
                
                container.add_item(discord.ui.TextDisplay("# 🎵 Queue Finished"))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay(
                    "**Sab gaane khatam ho gaye! 🎶**\n\n"
                    "Queue me koi aur gaana nahi hai.\n"
                    "Naye gaane add karne ke liye `.play <song name>` use karo!"
                ))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay(
                    "**Quick Commands:**\n"
                    "• `.play <song>` - Naya gaana bajao\n"
                    "• `.search <query>` - Gaane search karo\n"
                    "• `.stop` - Music band karo aur disconnect karo"
                ))
                
                view.add_item(container)
                await ctx.send(view=view)
                
            except Exception as e:
                print(f"Error sending queue finished message: {e}")
            
            # Clean up old message
            if player.message:
                try:
                    await player.message.delete()
                    player.message = None
                except:
                    pass

    async def update_now_playing(self, ctx: Context):
        """Update the now playing message"""
        player = self.get_player(ctx.guild.id)
        
        if not player.current_song:
            return
        
        song = player.current_song
        
        # Create component-based view
        view = discord.ui.LayoutView(timeout=300.0)
        container = discord.ui.Container(accent_color=None)
        
        container.add_item(discord.ui.TextDisplay("# 🎵 Now Playing"))
        container.add_item(discord.ui.Separator())
# Code by Trusty X Ayaan
        
        container.add_item(discord.ui.TextDisplay(f"**{song.title}**"))
        container.add_item(discord.ui.Separator())
        
        info_text = (
            f"• **Duration:** {song.format_duration()}\n"
            f"• **Requested by:** {song.requester.mention}"
        )
        container.add_item(discord.ui.TextDisplay(info_text))
        
        # Queue info
        queue_info = f"**Songs in queue:** {len(player.queue)}"
        if player.is_looping:
            queue_info += " • 🔁 **Loop:** ON"
        if player.is_queue_looping:
            queue_info += " • 🔁 **Queue Loop:** ON"
        
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay(queue_info))
        
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay("**Controls:**\n`pause` • `resume` • `skip` • `stop` • `loop` • `shuffle`"))
        
        view.add_item(container)
        
        # Update or send message
        try:
            if player.message:
                await player.message.edit(view=view)
            else:
                player.message = await ctx.send(view=view)
        except Exception as e:
            print(f"Error updating message: {e}")

    def help_custom(self):
        """Return help info for this cog"""
        return ("🎵", "Music Advanced", "Full-featured YouTube music player")

    @commands.command(name="play", aliases=["p"])
    @blacklist_check()
    @ignore_check()
    async def play_music(self, ctx: Context, *, search: str):
        """🎵 Play music from YouTube with advanced player"""
        try:
            # Check if user is in voice channel
            if not ctx.author.voice:
                return await ctx.send("❌ You need to be in a voice channel!")
            
            channel = ctx.author.voice.channel
            
            # Join voice channel if not connected
            if not ctx.voice_client:
                try:
                    voice_client = await channel.connect(self_deaf=False, self_mute=False)
                    # Create component-based view
                    view = discord.ui.LayoutView(timeout=300.0)
                    container = discord.ui.Container(accent_color=None)
                    
                    container.add_item(discord.ui.TextDisplay("# 🔊 Connected"))
                    container.add_item(discord.ui.Separator())
                    container.add_item(discord.ui.TextDisplay(f"**Joined • {channel.name} • !!**"))
                    container.add_item(discord.ui.Separator())
                    container.add_item(discord.ui.TextDisplay("Ready for music playback"))
                    
                    view.add_item(container)
                    await ctx.send(view=view)
                except Exception as e:
                    return await ctx.send(f"❌ Failed to join: {e}")
            else:
                voice_client = ctx.voice_client
            
            # Send searching message
            search_msg = await ctx.send(f"🔍 Searching for: **{search}**...")
            
            # Search for the song
            song_info = await self.search_song(search)
            
            if not song_info:
                return await search_msg.edit(content="❌ No results found!")
            
            # Create song object
            song = Song(
                url=song_info['url'],
                title=song_info.get('title', 'Unknown'),
                duration=song_info.get('duration', 0),
                thumbnail=song_info.get('thumbnail', ''),
                requester=ctx.author
            )
            
            # Get player and add song
            player = self.get_player(ctx.guild.id)
            
            # If nothing is playing, start immediately
            if not voice_client.is_playing() and not voice_client.is_paused():
                player.current_song = song
                song.start_time = time.time()
                
                try:
                    # Create audio source
                    audio_source = discord.FFmpegPCMAudio(
                        song.url,
                        executable=self.ffmpeg_path,
                        before_options='-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
                        options='-vn -loglevel quiet'
                    )
                    
                    # Play with callback for next song
                    voice_client.play(audio_source, after=lambda e: asyncio.run_coroutine_threadsafe(self.play_next(ctx), self.bot.loop))
                    
                    # Delete search message and update now playing
                    await search_msg.delete()
                    await self.update_now_playing(ctx)
                    
                except Exception as ffmpeg_error:
                    await search_msg.edit(content=f"❌ FFmpeg Error: {str(ffmpeg_error)}")
                    return
            else:
                # Add to queue
                player.add_song(song)
                
                # Create component-based view
                view = discord.ui.LayoutView(timeout=300.0)
                container = discord.ui.Container(accent_color=None)
                
                container.add_item(discord.ui.TextDisplay("# ➕ Added to Queue"))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay(f"**{song.title}**"))
                container.add_item(discord.ui.Separator())
                
                info_text = (
                    f"• **Duration:** {song.format_duration()}\n"
                    f"• **Position in Queue:** #{len(player.queue)}\n"
                    f"• **Requested by:** {ctx.author.mention}"
                )
                container.add_item(discord.ui.TextDisplay(info_text))
                
                view.add_item(container)
                await search_msg.edit(content="", view=view)
                
        except Exception as e:
            await ctx.send(f"❌ Error: {str(e)}")

    @commands.command(name="queue", aliases=["q"])
    @blacklist_check()
    @ignore_check()
    async def show_queue(self, ctx: Context):
        """📋 Show the current music queue"""
        player = self.get_player(ctx.guild.id)
        
        view = discord.ui.LayoutView(timeout=300.0)
        container = discord.ui.Container(accent_color=None)
        
        container.add_item(discord.ui.TextDisplay("# 📋 Music Queue"))
        container.add_item(discord.ui.Separator())
        
        # Current song
        if player.current_song:
            current = player.current_song
            current_text = f"**{current.title}** ({current.format_duration()})\nRequested by {current.requester.mention}"
            container.add_item(discord.ui.TextDisplay(f"## 🎵 Now Playing\n{current_text}"))
            container.add_item(discord.ui.Separator())
        
        # Queue
        if player.queue:
            queue_text = ""
            for i, song in enumerate(player.queue[:10], 1):  # Show first 10
                queue_text += f"`{i}.` **{song.title}** ({song.format_duration()})\n"
            
            if len(player.queue) > 10:
                queue_text += f"\n... and {len(player.queue) - 10} more songs"
            
            container.add_item(discord.ui.TextDisplay(f"## 📋 Up Next\n{queue_text}"))
        else:
            container.add_item(discord.ui.TextDisplay("## 📋 Up Next\nQueue is empty"))
        
        # Queue stats
        total_duration = sum(song.duration for song in player.queue if song.duration)
        if total_duration:
            hours, remainder = divmod(total_duration, 3600)
            minutes, seconds = divmod(remainder, 60)
            duration_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}" if hours else f"{minutes:02d}:{seconds:02d}"
            stats_text = f"Total queue time: {duration_str} • {len(player.queue)} songs"
        else:
            stats_text = f"{len(player.queue)} songs in queue"
        
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay(stats_text))
        
        view.add_item(container)
        await ctx.send(view=view)

    @commands.command(name="skip", aliases=["s"])
    @blacklist_check()
    @ignore_check()
    async def skip_song(self, ctx: Context):
        """⏭️ Skip the current song"""
        if not ctx.voice_client:
            return await ctx.send("❌ Not connected to voice!")
        
        if ctx.voice_client.is_playing() or ctx.voice_client.is_paused():
            player = self.get_player(ctx.guild.id)
            player.skip_song()
            ctx.voice_client.stop()
            await ctx.send("⏭️ Skipped current song!")
        else:
            await ctx.send("❌ Nothing is playing!")

    @commands.command(name="stop")
    @blacklist_check()
    @ignore_check()
    async def stop_music(self, ctx: Context):
        """⏹️ Stop music and clear queue"""
        if not ctx.voice_client:
            return await ctx.send("❌ Not connected to voice!")
        
        player = self.get_player(ctx.guild.id)
        player.clear_queue()
        player.current_song = None
        
        ctx.voice_client.stop()
        await ctx.send("⏹️ Stopped music and cleared queue!")

    @commands.command(name="pause")
    @blacklist_check()
    @ignore_check()
    async def pause_music(self, ctx: Context):
        """⏸️ Pause music playback"""
        if not ctx.voice_client:
            return await ctx.send("❌ Not connected to voice!")
        
        if ctx.voice_client.is_playing():
            ctx.voice_client.pause()
            await ctx.send("⏸️ Paused music!")
        else:
            await ctx.send("❌ Nothing is playing!")

    @commands.command(name="resume")
    @blacklist_check()
    @ignore_check()
    async def resume_music(self, ctx: Context):
        """▶️ Resume music playback"""
        if not ctx.voice_client:
            return await ctx.send("❌ Not connected to voice!")
        
        if ctx.voice_client.is_paused():
            ctx.voice_client.resume()
            await ctx.send("▶️ Resumed music!")
        else:
            await ctx.send("❌ Nothing is paused!")

    @commands.command(name="loop")
    @blacklist_check()
    @ignore_check()
    async def loop_song(self, ctx: Context):
        """🔁 Toggle loop for current song"""
        player = self.get_player(ctx.guild.id)
        
        if not player.current_song:
            return await ctx.send("❌ No song is currently playing!")
        
        is_looping = player.toggle_loop()
        status = "enabled" if is_looping else "disabled"
        await ctx.send(f"🔁 Loop {status} for current song!")
        
        # Update now playing message
        await self.update_now_playing(ctx)

    @commands.command(name="shuffle")
    @blacklist_check()
    @ignore_check()
    async def shuffle_queue(self, ctx: Context):
        """🔀 Shuffle the music queue"""
        player = self.get_player(ctx.guild.id)
        
        if not player.queue:
            return await ctx.send("❌ Queue is empty!")
        
        import random
# Created by Trusty X Ayaan
        random.shuffle(player.queue)
        await ctx.send(f"🔀 Shuffled {len(player.queue)} songs in queue!")

    @commands.command(name="clear")
    @blacklist_check()
    @ignore_check()
    async def clear_queue(self, ctx: Context):
        """🗑️ Clear the music queue"""
        player = self.get_player(ctx.guild.id)
        
        if not player.queue:
            return await ctx.send("❌ Queue is already empty!")
        
        cleared_count = len(player.queue)
        player.clear_queue()
        await ctx.send(f"🗑️ Cleared {cleared_count} songs from queue!")

    @commands.command(name="nowplaying", aliases=["np"])
    @blacklist_check()
    @ignore_check()
    async def now_playing(self, ctx: Context):
        """🎵 Show currently playing song"""
        player = self.get_player(ctx.guild.id)
        
        if not player.current_song:
            return await ctx.send("❌ Nothing is currently playing!")
        
# Dev: Trusty X Ayaan
        await self.update_now_playing(ctx)


async def setup(bot):
    await bot.add_cog(MusicYTDL(bot))