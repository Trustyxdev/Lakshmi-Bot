"""
Prefix Management Commands
"""
import discord
from discord.ext import commands
import aiosqlite
# © Trusty X Ayaan Development


class Prefix(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/prefix.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS prefixes (
                guild_id INTEGER PRIMARY KEY,
                prefix TEXT DEFAULT '!'
            )
        ''')
        await self.db.commit()

    @commands.hybrid_group(name='prefix', help='Manage server prefix')
    @commands.has_permissions(administrator=True)
    async def prefix(self, ctx):
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="Prefix Management",
                description="Use subcommands to manage your server prefix",
                color=0x000000
            )
            await ctx.send(embed=embed)

    @prefix.command(name='add', help='Add a new prefix')
    @commands.has_permissions(administrator=True)
    async def prefix_add(self, ctx, *, new_prefix: str):
        if len(new_prefix) > 5:
            embed = discord.Embed(title="Error", description="Prefix must be 5 characters or less", color=0xFF0000)
            return await ctx.send(embed=embed)
        
        await self.db.execute(
            'INSERT OR REPLACE INTO prefixes (guild_id, prefix) VALUES (?, ?)',
            (ctx.guild.id, new_prefix)
        )
        await self.db.commit()
        
        embed = discord.Embed(title="Success", description=f"Prefix set to `{new_prefix}`", color=0x00FF00)
        await ctx.send(embed=embed)

    @prefix.command(name='show', help='Show current prefix')
    async def prefix_show(self, ctx):
        async with self.db.execute('SELECT prefix FROM prefixes WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            row = await cursor.fetchone()
            current_prefix = row[0] if row else '!'
        
        embed = discord.Embed(title="Current Prefix", description=f"`{current_prefix}`", color=0x000000)
        await ctx.send(embed=embed)

    @prefix.command(name='reset', help='Reset to default prefix')
    @commands.has_permissions(administrator=True)
    async def prefix_reset(self, ctx):
        await self.db.execute(
            'INSERT OR REPLACE INTO prefixes (guild_id, prefix) VALUES (?, ?)',
            (ctx.guild.id, '!')
        )
        await self.db.commit()
        
        embed = discord.Embed(title="Success", description="Prefix reset to `!`", color=0x00FF00)
        await ctx.send(embed=embed)

    @prefix.command(name='remove', help='Remove custom prefix')
    @commands.has_permissions(administrator=True)
    async def prefix_remove(self, ctx):
        await self.db.execute('DELETE FROM prefixes WHERE guild_id = ?', (ctx.guild.id,))
        await self.db.commit()
        
        embed = discord.Embed(title="Success", description="Custom prefix removed", color=0x00FF00)
# Made by Trusty X Ayaan Dev
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Prefix(bot))
