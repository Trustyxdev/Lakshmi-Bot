"""
Debug Music Commands - For testing queue end notifications
"""
import discord
from discord.ext import commands
from discord import ui
from core import Cog, Context
from utils.Tools import *


class DebugMusic(Cog):
    """Debug commands for music system"""

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="testqueuemsg")
    @blacklist_check()
    @ignore_check()
    async def test_queue_message(self, ctx: Context):
        """Test queue end notification message"""
        # Create beautiful embed for queue finished
        view = ui.LayoutView(timeout=60.0)
        container = ui.Container(accent_color=None)
        
        container.add_item(ui.TextDisplay("# 🎵 Queue Khatam Ho Gaya"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(
            "**Sab gaane khatam ho gaye! 🎶**\n\n"
            "Queue me ab koi gaana nahi bacha hai.\n\n"
            "Naye gaane bajane ke liye `.play <song name>` use karo!"
        ))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(
            "**Quick Commands:**\n"
            "• `.play <song>` - Naya gaana bajao\n"
            "• `.search <query>` - Gaane search karo\n"
            "• `.queue` - Queue dekho\n"
            "• `.disconnect` - Voice se disconnect karo"
        ))
        
        view.add_item(container)
        await ctx.send(view=view)
        await ctx.send("✅ Yeh message aana chahiye jab queue khatam ho!")


async def setup(bot):
    await bot.add_cog(DebugMusic(bot))
