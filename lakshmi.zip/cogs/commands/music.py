"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import wavelink
from discord.ext import commands
from discord import ui
from core import Cog, Context
from utils.Tools import *
import asyncio
import time
from typing import Optional
# © Trusty X Ayaan Development


class AdvancedMusic(Cog):
    """Advanced Music System - Based on Lakshmi Music Engine"""

    def __init__(self, bot):
        self.bot = bot
        self.music_disabled = False
        self.last_context = {}  # Store last context per guild for notifications
        bot.loop.create_task(self.connect_nodes())
        
    @commands.Cog.listener()
    async def on_wavelink_track_end(self, payload: wavelink.TrackEndEventPayload):
        """Handle track end event and notify when queue is empty"""
        player = payload.player
        
        if not player:
            return
            
        # Wait a moment for wavelink to process
        await asyncio.sleep(0.5)
        
        # Check if queue is empty and nothing is playing
        if player.queue.is_empty and not player.playing and not player.paused:
            # Get the last context for this guild
            guild_id = player.guild.id
            ctx = self.last_context.get(guild_id)
            
            if ctx:
                try:
                    # Create beautiful embed for queue finished
                    view = ui.LayoutView(timeout=60.0)
                    container = ui.Container(accent_color=None)
                    
                    container.add_item(ui.TextDisplay("# 🎵 Queue Khatam Ho Gaya"))
                    container.add_item(ui.Separator())
                    container.add_item(ui.TextDisplay(
                        "**Sab gaane khatam ho gaye! 🎶**\n\n"
                        "Queue me ab koi gaana nahi bacha hai.\n\n"
                        "Naye gaane bajane ke liye `.play <song name>` use karo!"
                    ))
                    container.add_item(ui.Separator())
                    container.add_item(ui.TextDisplay(
                        "**Quick Commands:**\n"
                        "• `.play <song>` - Naya gaana bajao\n"
                        "• `.search <query>` - Gaane search karo\n"
                        "• `.queue` - Queue dekho\n"
                        "• `.disconnect` - Voice se disconnect karo"
                    ))
                    
                    view.add_item(container)
                    await ctx.send(view=view)
                    
                    print(f"✅ Queue finished notification sent to {ctx.guild.name}")
                    
                except Exception as e:
                    print(f"❌ Error sending queue finished message: {e}")
                    import traceback
                    traceback.print_exc()
    
    @commands.Cog.listener()
    async def on_wavelink_inactive_player(self, player: wavelink.Player):
        """Handle when player becomes inactive (no tracks in queue)"""
        if not player:
            return
            
        guild_id = player.guild.id
        ctx = self.last_context.get(guild_id)
        
        if ctx:
            try:
                # Create beautiful embed for queue finished
                view = ui.LayoutView(timeout=60.0)
                container = ui.Container(accent_color=None)
                
                container.add_item(ui.TextDisplay("# 🎵 Queue Khatam Ho Gaya"))
                container.add_item(ui.Separator())
                container.add_item(ui.TextDisplay(
                    "**Sab gaane khatam ho gaye! 🎶**\n\n"
                    "Queue me ab koi gaana nahi bacha hai.\n\n"
                    "Naye gaane bajane ke liye `.play <song name>` use karo!"
                ))
                container.add_item(ui.Separator())
                container.add_item(ui.TextDisplay(
                    "**Quick Commands:**\n"
                    "• `.play <song>` - Naya gaana bajao\n"
                    "• `.search <query>` - Gaane search karo\n"
                    "• `.queue` - Queue dekho\n"
                    "• `.disconnect` - Voice se disconnect karo"
                ))
                
                view.add_item(container)
                await ctx.send(view=view)
                
                print(f"✅ Inactive player notification sent to {ctx.guild.name}")
                
            except Exception as e:
                print(f"❌ Error sending inactive player message: {e}")
                import traceback
                traceback.print_exc()

    def help_custom(self):
        """Return help info for this cog"""
        return ("<a:crz_music:1491702314116059238>", "Music", "Advanced music system with multiple sources")

    async def connect_nodes(self):
        """Connect to Lavalink nodes with multiple fallbacks"""
        await self.bot.wait_until_ready()
        
        # Multiple Lavalink servers for better reliability
        nodes = [
            {
                "uri": "http://lavalinkv4.serenetia.com:80",
                "password": "https://dsc.gg/ajidevserver"
            },
            {
                "uri": "https://lavalink.alfari.id",
                "password": "catfein"
            },
            {
                "uri": "https://lavalink.devamop.in", 
                "password": "DevamOP"
            },
            {
                "uri": "https://lavalink.oops.wtf",
                "password": "www.freelavalink.ga"
            }
        ]
        
        connected = False
        for node_config in nodes:
            try:
                print(f"🔄 Attempting connection to {node_config['uri']}...")
                
                node = wavelink.Node(
                    uri=node_config["uri"],
                    password=node_config["password"]
                )
                
                await asyncio.wait_for(
                    wavelink.Pool.connect(client=self.bot, nodes=[node]),
                    timeout=8.0
                )
                
                print(f"✅ Successfully connected to Lavalink: {node_config['uri']}")
                connected = True
                break
                
            except asyncio.TimeoutError:
                print(f"⏱️ Connection timeout for {node_config['uri']}")
                continue
            except Exception as e:
                print(f"❌ Connection failed for {node_config['uri']}: {str(e)[:50]}...")
                continue
        
        if not connected:
            print("⚠️ No Lavalink servers available. Music functionality will be limited.")
            self.music_disabled = True
        else:
            print("🎵 Advanced Music System Ready!")
            self.music_disabled = False

    # Voice Connection Commands
    @commands.hybrid_command(name="connect", aliases=["join", "j"])
    @blacklist_check()
    @ignore_check()
    async def connect(self, ctx: Context):
        """Join your voice channel"""
        if not ctx.author.voice:
            return await ctx.send("❌ You need to be in a voice channel!")
        
        channel = ctx.author.voice.channel
        
        # Check if already connected
        if ctx.voice_client:
            if ctx.voice_client.channel.id == channel.id:
                return await ctx.send("🎵 Already connected to your voice channel!")
            else:
                return await ctx.send(f"❌ Already connected to <#{ctx.voice_client.channel.id}>!")
        
        # Check permissions
        permissions = channel.permissions_for(ctx.guild.me)
        if not permissions.connect or not permissions.speak:
            return await ctx.send("❌ I don't have permission to join or speak in your voice channel!")
        
        try:
            if wavelink.Pool.nodes:
                await channel.connect(cls=wavelink.Player, self_deaf=False, self_mute=False)
            else:
                await channel.connect(self_deaf=False, self_mute=False)
            await ctx.send(f"✅ Successfully joined <#{channel.id}>!")
        except Exception as e:
            await ctx.send(f"❌ Failed to join: {str(e)}")

    @commands.hybrid_command(name="disconnect", aliases=["leave", "dc"])
    @blacklist_check()
    @ignore_check()
    async def disconnect(self, ctx: Context):
        """Leave the voice channel"""
        if not ctx.voice_client:
            return await ctx.send("❌ Not connected to any voice channel!")
        
        await ctx.voice_client.disconnect()
        await ctx.send("👋 Disconnected from voice channel!")

    # Music Playback Commands
    @commands.hybrid_command(name="play", aliases=["p"])
    @blacklist_check()
    @ignore_check()
    async def play(self, ctx: Context, *, query: str):
        """Play music from various sources (YouTube, Spotify, SoundCloud)"""
        # Store context for notifications
        self.last_context[ctx.guild.id] = ctx
        
        if not ctx.author.voice:
            return await ctx.send("❌ You need to be in a voice channel!")

        if not wavelink.Pool.nodes:
            return await ctx.send("❌ Music service unavailable. Use `.join` for basic voice connection.")

        # Auto-join if not connected
        if not ctx.voice_client:
            try:
                vc: wavelink.Player = await ctx.author.voice.channel.connect(cls=wavelink.Player, self_deaf=False, self_mute=False)
            except Exception as e:
                return await ctx.send(f"❌ Failed to join: {e}")
        else:
            vc: wavelink.Player = ctx.voice_client

        # Same voice channel check
        if ctx.voice_client and ctx.author.voice.channel.id != ctx.voice_client.channel.id:
            return await ctx.send("❌ You must be in the same voice channel as the bot!")

        try:
            # Search for tracks
            tracks = await wavelink.Playable.search(query)
            if not tracks:
                return await ctx.send("❌ No results found!")

            # Handle playlist vs single track
            if isinstance(tracks, wavelink.Playlist):
                # Filter tracks (minimum 30 seconds)
                valid_tracks = [t for t in tracks.tracks if t.length >= 30000 or t.is_stream()]
                
                if not valid_tracks:
                    return await ctx.send("❌ No valid tracks in playlist (minimum 30 seconds)!")
                
                for track in valid_tracks:
                    await vc.queue.put_wait(track)
                
                # Create component-based view
                view = ui.LayoutView(timeout=300.0)
                container = ui.Container(accent_color=None)
                
                container.add_item(ui.TextDisplay("# 🎵 Playlist Added"))
                container.add_item(ui.Separator())
                container.add_item(ui.TextDisplay(f"**{tracks.name}**\n{len(valid_tracks)} tracks added to queue!"))
                container.add_item(ui.Separator())
                container.add_item(ui.TextDisplay(f"Requested by {ctx.author.mention}"))
                
                view.add_item(container)
                
            else:
                track = tracks[0]
                
                # Check minimum duration
                if not track.is_stream() and track.length < 30000:
                    return await ctx.send("❌ Track too short (minimum 30 seconds)!")
                
                await vc.queue.put_wait(track)
                
                # Create component-based view
                view = ui.LayoutView(timeout=300.0)
                container = ui.Container(accent_color=None)
                
                container.add_item(ui.TextDisplay("# 🎵 Track Added"))
                container.add_item(ui.Separator())
                container.add_item(ui.TextDisplay(f"**[{track.title}]({track.uri})**\nBy: {track.author}"))
                container.add_item(ui.Separator())
                
                info_text = (
                    f"• **Duration:** {self._format_time(track.length)}\n"
                    f"• **Position:** #{vc.queue.count}\n"
                    f"• **Requested by:** {ctx.author.mention}"
                )
                container.add_item(ui.TextDisplay(info_text))
                
                view.add_item(container)

            # Start playing if not already
            if not vc.playing and not vc.paused:
                await vc.play(vc.queue.get())

            await ctx.send(view=view)

        except Exception as e:
            await ctx.send(f"❌ Error: {str(e)}")

    @commands.hybrid_command(name="pause")
    @blacklist_check()
    @ignore_check()
    async def pause(self, ctx: Context):
        """Pause the current track"""
        vc: wavelink.Player = ctx.voice_client
        if not vc or not vc.playing:
            return await ctx.send("❌ Nothing is playing!")
        
        await vc.pause(True)
        await ctx.send("⏸️ Paused the music!")

    @commands.hybrid_command(name="resume")
    @blacklist_check()
    @ignore_check()
    async def resume(self, ctx: Context):
        """Resume the paused track"""
        vc: wavelink.Player = ctx.voice_client
        if not vc or not vc.paused:
            return await ctx.send("❌ Nothing is paused!")
        
        await vc.pause(False)
        await ctx.send("▶️ Resumed the music!")

    @commands.hybrid_command(name="skip", aliases=["s"])
    @blacklist_check()
    @ignore_check()
    async def skip(self, ctx: Context):
        """Skip the current track"""
        vc: wavelink.Player = ctx.voice_client
        if not vc or not vc.playing:
            return await ctx.send("❌ Nothing is playing!")
        
        await vc.skip()
        await ctx.send("⏭️ Skipped the track!")

    @commands.hybrid_command(name="stop")
    @blacklist_check()
    @ignore_check()
    async def stop(self, ctx: Context):
        """Stop playback and clear queue"""
        vc: wavelink.Player = ctx.voice_client
        if not vc:
            return await ctx.send("❌ Not connected!")
        
        vc.queue.clear()
        await vc.stop()
# Made by Trusty X Ayaan Dev
        await ctx.send("⏹️ Stopped and cleared queue!")

    # Queue Management
    @commands.hybrid_command(name="queue", aliases=["q"])
    @blacklist_check()
    @ignore_check()
    async def queue(self, ctx: Context):
        """Show the current queue"""
        vc: wavelink.Player = ctx.voice_client
        if not vc or vc.queue.is_empty:
            return await ctx.send("❌ Queue is empty!")

        view = ui.LayoutView(timeout=300.0)
        container = ui.Container(accent_color=None)
        
        container.add_item(ui.TextDisplay("# 🎵 Music Queue"))
        container.add_item(ui.Separator())
        
        # Current track
        if vc.current:
            current_info = f"**[{vc.current.title}]({vc.current.uri})**\nBy: {vc.current.author}"
            container.add_item(ui.TextDisplay(f"## 🎶 Now Playing\n{current_info}"))
            container.add_item(ui.Separator())
        
        # Queue tracks
        queue_list = []
        for i, track in enumerate(list(vc.queue)[:10], 1):
            queue_list.append(f"`{i}.` **{track.title}** - {track.author}")
        
        if queue_list:
            queue_text = "\n".join(queue_list)
            container.add_item(ui.TextDisplay(f"## 📋 Up Next ({vc.queue.count} tracks)\n{queue_text}"))
        
        if vc.queue.count > 10:
            container.add_item(ui.Separator())
            container.add_item(ui.TextDisplay(f"➕ And {vc.queue.count - 10} more..."))
        
        view.add_item(container)
        await ctx.send(view=view)

    @commands.hybrid_command(name="nowplaying", aliases=["np"])
    @blacklist_check()
    @ignore_check()
    async def nowplaying(self, ctx: Context):
        """Show currently playing track"""
        vc: wavelink.Player = ctx.voice_client
        if not vc or not vc.current:
            return await ctx.send("❌ Nothing is playing!")

        track = vc.current
        
        view = ui.LayoutView(timeout=300.0)
        container = ui.Container(accent_color=None)
        
        container.add_item(ui.TextDisplay("# 🎵 Now Playing"))
        container.add_item(ui.Separator())
        
        container.add_item(ui.TextDisplay(f"**[{track.title}]({track.uri})**"))
        container.add_item(ui.Separator())
        
        info_text = (
            f"• **Artist:** {track.author}\n"
            f"• **Duration:** {self._format_time(track.length)}\n"
            f"• **Position:** {self._format_time(vc.position)}"
        )
        container.add_item(ui.TextDisplay(info_text))
        
        # Progress bar
        if track.length > 0:
            progress = int((vc.position / track.length) * 20)
            bar = "█" * progress + "░" * (20 - progress)
            progress_text = f"`{bar}`\n`{self._format_time(vc.position)} / {self._format_time(track.length)}`"
            container.add_item(ui.Separator())
            container.add_item(ui.TextDisplay(progress_text))
        
        view.add_item(container)
        await ctx.send(view=view)

    # Advanced Commands
    @commands.hybrid_command(name="volume", aliases=["vol"])
    @blacklist_check()
    @ignore_check()
    async def volume(self, ctx: Context, level: int):
        """Set volume (0-100)"""
        vc: wavelink.Player = ctx.voice_client
        if not vc:
            return await ctx.send("❌ Not connected!")
        
        if not 0 <= level <= 100:
            return await ctx.send("❌ Volume must be between 0-100!")
        
        await vc.set_volume(level)
        await ctx.send(f"🔊 Volume set to {level}%!")

    @commands.hybrid_command(name="shuffle")
    @blacklist_check()
    @ignore_check()
    async def shuffle(self, ctx: Context):
        """Shuffle the queue"""
        vc: wavelink.Player = ctx.voice_client
        if not vc or vc.queue.is_empty:
            return await ctx.send("❌ Queue is empty!")
        
        vc.queue.shuffle()
        await ctx.send("🔀 Queue shuffled!")

    @commands.hybrid_command(name="loop")
    @blacklist_check()
    @ignore_check()
    async def loop(self, ctx: Context, mode: str = None):
        """Toggle loop mode: off, track, queue"""
        vc: wavelink.Player = ctx.voice_client
        if not vc:
            return await ctx.send("❌ Not connected!")

        modes = {
            "off": wavelink.QueueMode.normal,
            "track": wavelink.QueueMode.loop,
            "queue": wavelink.QueueMode.loop_all
        }
        
        if mode and mode.lower() in modes:
            vc.queue.mode = modes[mode.lower()]
            await ctx.send(f"🔁 Loop mode: **{mode.lower()}**")
        else:
            current_mode = vc.queue.mode.name.replace('_', ' ')
            await ctx.send(f"Current loop mode: **{current_mode}**\nOptions: `off`, `track`, `queue`")

    @commands.hybrid_command(name="remove")
    @blacklist_check()
    @ignore_check()
    async def remove(self, ctx: Context, index: int):
        """Remove a track from queue"""
        vc: wavelink.Player = ctx.voice_client
        if not vc or vc.queue.is_empty:
            return await ctx.send("❌ Queue is empty!")
        
        if not 1 <= index <= vc.queue.count:
            return await ctx.send(f"❌ Invalid index! Queue has {vc.queue.count} tracks.")
        
        removed = vc.queue[index - 1]
        del vc.queue[index - 1]
        await ctx.send(f"🗑️ Removed: **{removed.title}**")

    @commands.hybrid_command(name="clear")
    @blacklist_check()
    @ignore_check()
    async def clear(self, ctx: Context):
        """Clear the entire queue"""
        vc: wavelink.Player = ctx.voice_client
        if not vc or vc.queue.is_empty:
            return await ctx.send("❌ Queue is empty!")
        
        vc.queue.clear()
        await ctx.send("🗑️ Queue cleared!")

    @commands.hybrid_command(name="search")
    @blacklist_check()
    @ignore_check()
    async def search(self, ctx: Context, *, query: str):
        """Search for tracks"""
        if not wavelink.Pool.nodes:
            return await ctx.send("❌ Music service unavailable!")

        tracks = await wavelink.Playable.search(query)
        if not tracks:
            return await ctx.send("❌ No results found!")

        view = ui.LayoutView(timeout=300.0)
        container = ui.Container(accent_color=None)
        
        container.add_item(ui.TextDisplay("# 🔍 Search Results"))
        container.add_item(ui.Separator())
        
        results = []
        for i, track in enumerate(tracks[:10], 1):
            results.append(f"`{i}.` **{track.title}** - {track.author}")
        
        results_text = "\n".join(results)
        container.add_item(ui.TextDisplay(results_text))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay("Use `.play <song name>` to play a track"))
        
        view.add_item(container)
        await ctx.send(view=view)

    @commands.hybrid_command(name="grab", aliases=["save"])
    @blacklist_check()
    @ignore_check()
    async def grab(self, ctx: Context):
        """Save current track to DMs"""
        vc: wavelink.Player = ctx.voice_client
        if not vc or not vc.current:
            return await ctx.send("❌ Nothing is playing!")

        track = vc.current
        
        view = ui.LayoutView(timeout=300.0)
        container = ui.Container(accent_color=None)
        
        container.add_item(ui.TextDisplay("# 🎵 Saved Track"))
        container.add_item(ui.Separator())
        
        container.add_item(ui.TextDisplay(f"**[{track.title}]({track.uri})**"))
        container.add_item(ui.Separator())
        
        info_text = (
            f"• **Artist:** {track.author}\n"
            f"• **Duration:** {self._format_time(track.length)}"
        )
        container.add_item(ui.TextDisplay(info_text))
        
        view.add_item(container)
        
        try:
            await ctx.author.send(view=view)
            await ctx.send("✅ Track sent to your DMs!")
        except discord.Forbidden:
            await ctx.send("❌ Couldn't DM you! Enable DMs from server members.")

    @commands.hybrid_command(name="musicstatus", aliases=["mstatus"])
    @blacklist_check()
    @ignore_check()
    async def music_status(self, ctx: Context):
        """Check music system status"""
        view = ui.LayoutView(timeout=300.0)
        container = ui.Container(accent_color=None)
        
        container.add_item(ui.TextDisplay("# 🎵 Music System Status"))
        container.add_item(ui.Separator())
        
        if wavelink.Pool.nodes:
            node = list(wavelink.Pool.nodes.values())[0]
            status_text = (
                f"• **Status:** ✅ Online\n"
                f"• **Server:** `{node.uri}`\n"
                f"• **Players:** `{len(node.players)}`\n"
                f"• **Latency:** `{node.heartbeat}ms`"
            )
        else:
            status_text = (
                f"• **Status:** ❌ Offline\n"
                f"• **Reason:** No Lavalink servers available\n"
                f"• **Note:** Voice joining still works with `.join`"
            )
        
        container.add_item(ui.TextDisplay(status_text))
        
        # Debug info
        if ctx.guild.id in self.last_context:
            container.add_item(ui.Separator())
            container.add_item(ui.TextDisplay("✅ Context stored for notifications"))
        else:
            container.add_item(ui.Separator())
            container.add_item(ui.TextDisplay("⚠️ No context stored - use `.play` first"))
        
        view.add_item(container)
        
        await ctx.send(view=view)
    
    @commands.hybrid_command(name="testqueueend", aliases=["tqe"])
    @blacklist_check()
    @ignore_check()
    async def test_queue_end(self, ctx: Context):
        """Test queue end notification (Debug command)"""
        # Store context
        self.last_context[ctx.guild.id] = ctx
        
        # Send test notification
        view = ui.LayoutView(timeout=60.0)
        container = ui.Container(accent_color=None)
        
        container.add_item(ui.TextDisplay("# 🎵 Queue Khatam Ho Gaya"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(
            "**Sab gaane khatam ho gaye! 🎶**\n\n"
            "Queue me ab koi gaana nahi bacha hai.\n\n"
            "Naye gaane bajane ke liye `.play <song name>` use karo!"
        ))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(
            "**Quick Commands:**\n"
            "• `.play <song>` - Naya gaana bajao\n"
            "• `.search <query>` - Gaane search karo\n"
            "• `.queue` - Queue dekho\n"
            "• `.disconnect` - Voice se disconnect karo"
        ))
        
        view.add_item(container)
        await ctx.send(view=view)

    def _format_time(self, ms: int) -> str:
        """Format milliseconds to MM:SS or HH:MM:SS"""
        if ms == 0:
            return "Live"
        
        seconds = ms // 1000
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        if hours > 0:
            return f"{hours}:{minutes:02d}:{seconds:02d}"
        else:
# Code by Trusty X Ayaan
            return f"{minutes}:{seconds:02d}"


async def setup(bot):
    await bot.add_cog(AdvancedMusic(bot))