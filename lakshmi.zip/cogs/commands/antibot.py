"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
from discord.ext import commands
from utils.Tools import blacklist_check, ignore_check
# Developers: Trusty X Ayaan


# Built by Trusty X Ayaan Dev
class AntiBot(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/bot_database.db") as db:
            await db.execute(
                """CREATE TABLE IF NOT EXISTS antibot_config (
                    guild_id INTEGER PRIMARY KEY,
                    enabled INTEGER DEFAULT 0,
                    auto_delete INTEGER DEFAULT 1,
                    auto_kick INTEGER DEFAULT 0,
                    whitelist_bots TEXT,
                    enabled_at TEXT
                )"""
            )
            await db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000
        )
        for key, value in kwargs.items():
            if value:
                embed.add_field(name=key, value=value, inline=False)
        return embed

    @commands.group(name="antibot", invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    async def antibot(self, ctx):
        """Manage anti-bot settings"""
        await ctx.send_help(ctx.command)

    @antibot.command(name="enable")
    @commands.has_permissions(manage_guild=True)
    async def antibot_enable(self, ctx):
        """Enable anti-bot protection"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO antibot_config 
                    (guild_id, enabled, enabled_at)
                    VALUES (?, 1, datetime('now'))""",
                    (ctx.guild.id,)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Anti-Bot Enabled",
                "Anti-bot protection is now active. Unauthorized bots will be automatically deleted."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to enable anti-bot: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @antibot.command(name="disable")
    @commands.has_permissions(manage_guild=True)
    async def antibot_disable(self, ctx):
        """Disable anti-bot protection"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    "UPDATE antibot_config SET enabled = 0 WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Anti-Bot Disabled",
                "Anti-bot protection is now inactive."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to disable anti-bot: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @antibot.command(name="autodelete")
    @commands.has_permissions(manage_guild=True)
    async def antibot_autodelete(self, ctx, enabled: bool = True):
        """Toggle auto-delete for unauthorized bots"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    "UPDATE antibot_config SET auto_delete = ? WHERE guild_id = ?",
                    (1 if enabled else 0, ctx.guild.id)
                )
                await db.commit()

            status = "enabled" if enabled else "disabled"
            embed = self.create_embed(
                "✅ Auto-Delete Updated",
                f"Auto-delete for unauthorized bots is now {status}."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to update auto-delete: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @antibot.command(name="autokick")
    @commands.has_permissions(manage_guild=True)
    async def antibot_autokick(self, ctx, enabled: bool = False):
        """Toggle auto-kick for unauthorized bots"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    "UPDATE antibot_config SET auto_kick = ? WHERE guild_id = ?",
                    (1 if enabled else 0, ctx.guild.id)
                )
                await db.commit()

            status = "enabled" if enabled else "disabled"
            embed = self.create_embed(
                "✅ Auto-Kick Updated",
                f"Auto-kick for unauthorized bots is now {status}."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to update auto-kick: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @antibot.command(name="whitelist")
    @commands.has_permissions(manage_guild=True)
    async def antibot_whitelist(self, ctx, bot: discord.User):
        """Add a bot to the whitelist"""
        if not bot.bot:
# Made by Trusty X Ayaan Dev
            embed = self.create_embed(
                "❌ Not a Bot",
                "This user is not a bot."
            )
            return await ctx.reply(embed=embed)

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT whitelist_bots FROM antibot_config WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                row = await cursor.fetchone()
                
                whitelist = []
                if row and row[0]:
                    whitelist = row[0].split(",")
                
                if str(bot.id) not in whitelist:
                    whitelist.append(str(bot.id))
                    
                    await db.execute(
                        "UPDATE antibot_config SET whitelist_bots = ? WHERE guild_id = ?",
                        (",".join(whitelist), ctx.guild.id)
                    )
                    await db.commit()

            embed = self.create_embed(
                "✅ Bot Whitelisted",
                f"{bot.mention} has been added to the whitelist."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to whitelist bot: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @antibot.command(name="unwhitelist")
    @commands.has_permissions(manage_guild=True)
    async def antibot_unwhitelist(self, ctx, bot: discord.User):
        """Remove a bot from the whitelist"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT whitelist_bots FROM antibot_config WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                row = await cursor.fetchone()
                
                if not row or not row[0]:
                    embed = self.create_embed(
                        "❌ Not Whitelisted",
                        f"{bot.mention} is not in the whitelist."
                    )
                    return await ctx.reply(embed=embed)
                
                whitelist = row[0].split(",")
                if str(bot.id) in whitelist:
                    whitelist.remove(str(bot.id))
                    
                    await db.execute(
                        "UPDATE antibot_config SET whitelist_bots = ? WHERE guild_id = ?",
                        (",".join(whitelist) if whitelist else None, ctx.guild.id)
                    )
                    await db.commit()

            embed = self.create_embed(
                "✅ Bot Removed",
                f"{bot.mention} has been removed from the whitelist."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to remove bot: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @antibot.command(name="status")
    @commands.has_permissions(manage_guild=True)
    async def antibot_status(self, ctx):
        """View anti-bot status"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM antibot_config WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                config = await cursor.fetchone()

            if not config:
                embed = self.create_embed(
                    "📊 Anti-Bot Status",
                    "Status: **Disabled**"
                )
                return await ctx.reply(embed=embed)

            enabled = "🟢 Enabled" if config[1] else "🔴 Disabled"
            auto_delete = "✅ Enabled" if config[2] else "❌ Disabled"
            auto_kick = "✅ Enabled" if config[3] else "❌ Disabled"
            
            whitelist_text = "None"
            if config[4]:
                whitelist_ids = config[4].split(",")
                whitelist_text = ", ".join([f"<@{bot_id}>" for bot_id in whitelist_ids])

            embed = self.create_embed(
                "📊 Anti-Bot Status",
                f"**Status:** {enabled}\n**Auto-Delete:** {auto_delete}\n**Auto-Kick:** {auto_kick}\n**Whitelisted Bots:** {whitelist_text}"
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to fetch status: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if not member.bot:
            return

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM antibot_config WHERE guild_id = ?",
                    (member.guild.id,)
                )
                config = await cursor.fetchone()

                if not config or not config[1]:  # Not enabled
                    return

                whitelist = []
                if config[4]:
                    whitelist = config[4].split(",")

                if str(member.id) not in whitelist:
                    if config[3]:  # auto_kick
                        try:
                            await member.kick(reason="Unauthorized bot detected by anti-bot system")
                        except:
                            pass
                    if config[2]:  # auto_delete
                        try:
                            await member.send("You were kicked from the server for being an unauthorized bot.")
                        except:
                            pass
        except:
            pass


async def setup(bot):
    await bot.add_cog(AntiBot(bot))
