"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
from discord.ext import commands
from utils.Tools import blacklist_check, ignore_check
# Trusty X Ayaan - discord.gg/ibadat


# Developers: Trusty X Ayaan
class ChatBan(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/bot_database.db") as db:
            await db.execute(
                """CREATE TABLE IF NOT EXISTS chat_bans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER,
                    user_id INTEGER,
                    reason TEXT,
                    banned_at TEXT,
                    banned_by INTEGER,
                    UNIQUE(guild_id, user_id)
                )"""
            )
            await db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000
        )
        for key, value in kwargs.items():
            if value:
                embed.add_field(name=key, value=value, inline=False)
        return embed

    @commands.group(name="chat", invoke_without_command=True)
    @commands.has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def chat(self, ctx):
        """Manage chat bans"""
        await ctx.send_help(ctx.command)

    @chat.command(name="ban")
    @commands.has_permissions(manage_messages=True)
    async def chat_ban(self, ctx, user: discord.User, *, reason: str = "No reason provided"):
        """Ban a user from chatting"""
        if user.bot:
            embed = self.create_embed(
                "❌ Cannot Ban Bot",
                "You cannot chat ban a bot."
            )
            return await ctx.reply(embed=embed)

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO chat_bans 
                    (guild_id, user_id, reason, banned_at, banned_by)
                    VALUES (?, ?, ?, datetime('now'), ?)""",
                    (ctx.guild.id, user.id, reason, ctx.author.id)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ User Chat Banned",
                f"{user.mention} has been chat banned.",
                Reason=reason
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to chat ban user: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @chat.command(name="unban")
    @commands.has_permissions(manage_messages=True)
    async def chat_unban(self, ctx, user: discord.User):
        """Unban a user from chatting"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM chat_bans WHERE guild_id = ? AND user_id = ?",
# Code by Trusty X Ayaan
                    (ctx.guild.id, user.id)
                )
                ban = await cursor.fetchone()

                if not ban:
                    embed = self.create_embed(
                        "❌ Not Chat Banned",
                        f"{user.mention} is not chat banned."
                    )
                    return await ctx.reply(embed=embed)

                await db.execute(
                    "DELETE FROM chat_bans WHERE guild_id = ? AND user_id = ?",
                    (ctx.guild.id, user.id)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ User Chat Unbanned",
                f"{user.mention} has been chat unbanned."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to chat unban user: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @chat.command(name="banlist")
    @commands.has_permissions(manage_messages=True)
    async def chat_banlist(self, ctx):
        """View all chat banned users"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    "SELECT * FROM chat_bans WHERE guild_id = ? ORDER BY banned_at DESC",
                    (ctx.guild.id,)
                )
                bans = await cursor.fetchall()

            if not bans:
                embed = self.create_embed(
                    "📋 Chat Ban List",
                    "No users are currently chat banned."
                )
                return await ctx.reply(embed=embed)

            ban_text = ""
            for idx, ban in enumerate(bans, 1):
                user = self.bot.get_user(ban['user_id'])
                user_name = user.mention if user else f"Unknown ({ban['user_id']})"
                banned_by = self.bot.get_user(ban['banned_by'])
                banned_by_name = banned_by.mention if banned_by else f"Unknown ({ban['banned_by']})"
                
                ban_text += f"**{idx}.** {user_name}\n"
                ban_text += f"   Reason: {ban['reason']}\n"
                ban_text += f"   Banned by: {banned_by_name}\n\n"

            embed = self.create_embed(
                "📋 Chat Ban List",
                ban_text
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to fetch ban list: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM chat_bans WHERE guild_id = ? AND user_id = ?",
                    (message.guild.id, message.author.id)
                )
                ban = await cursor.fetchone()

                if ban:
                    try:
                        await message.delete()
                    except:
                        pass
        except:
# Created by Trusty X Ayaan
            pass


async def setup(bot):
    await bot.add_cog(ChatBan(bot))
