"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
from discord.ext import commands
from utils.Tools import blacklist_check, ignore_check
# Built by Trusty X Ayaan Dev


# Trusty X Ayaan - Krishx Dev
class Purge(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/bot_database.db") as db:
            await db.execute(
                """CREATE TABLE IF NOT EXISTS purge_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER,
                    channel_id INTEGER,
                    executor_id INTEGER,
                    purge_type TEXT,
                    count INTEGER,
                    timestamp TEXT
                )"""
            )
            await db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000
        )
        for key, value in kwargs.items():
            if value:
                embed.add_field(name=key, value=value, inline=False)
        return embed

    @commands.group(name="purge", invoke_without_command=True)
    @commands.has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def purge(self, ctx, amount: int = None):
        """Purge messages from the channel
        
        Usage: 
        - .purge 10 (delete 10 messages)
        - .purge clear 10 (same as above)
        - .purge user @user 10 (delete user's messages)
        """
        if amount is None:
            return await ctx.send_help(ctx.command)
        
        # Direct purge with number
        if amount < 1 or amount > 1000:
            embed = self.create_embed(
                "❌ Invalid Amount",
                "Please specify a number between 1 and 1000."
            )
            return await ctx.reply(embed=embed)

        try:
            deleted = await ctx.channel.purge(limit=amount + 1)  # +1 to include command message
            
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT INTO purge_logs 
                    (guild_id, channel_id, executor_id, purge_type, count, timestamp)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, ctx.channel.id, ctx.author.id, "direct", len(deleted))
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Messages Purged",
                f"Successfully deleted **{len(deleted)}** messages from {ctx.channel.mention}"
            )
            msg = await ctx.send(embed=embed)
            await asyncio.sleep(5)
            await msg.delete()
        except Exception as e:
            embed = self.create_embed(
                "❌ Purge Failed",
                f"Error: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @purge.command(name="clear")
    @commands.has_permissions(manage_messages=True)
    async def purge_clear(self, ctx, amount: int = 10):
        """Clear a specific number of messages"""
        if amount < 1 or amount > 1000:
            embed = self.create_embed(
                "❌ Invalid Amount",
                "Please specify a number between 1 and 1000."
            )
            return await ctx.reply(embed=embed)

        try:
            deleted = await ctx.channel.purge(limit=amount)
            
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT INTO purge_logs 
                    (guild_id, channel_id, executor_id, purge_type, count, timestamp)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, ctx.channel.id, ctx.author.id, "clear", len(deleted))
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Messages Purged",
                f"Successfully deleted **{len(deleted)}** messages from {ctx.channel.mention}"
            )
            await ctx.reply(embed=embed, delete_after=5)
        except Exception as e:
            embed = self.create_embed(
                "❌ Purge Failed",
                f"Error: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @purge.command(name="user")
    @commands.has_permissions(manage_messages=True)
    async def purge_user(self, ctx, user: discord.User, amount: int = 10):
        """Purge messages from a specific user"""
        if amount < 1 or amount > 1000:
            embed = self.create_embed(
                "❌ Invalid Amount",
                "Please specify a number between 1 and 1000."
            )
            return await ctx.reply(embed=embed)

        try:
            deleted = await ctx.channel.purge(
                limit=amount,
                check=lambda m: m.author == user
            )
            
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT INTO purge_logs 
                    (guild_id, channel_id, executor_id, purge_type, count, timestamp)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, ctx.channel.id, ctx.author.id, f"user_{user.id}", len(deleted))
                )
                await db.commit()

            embed = self.create_embed(
                "✅ User Messages Purged",
                f"Deleted **{len(deleted)}** messages from {user.mention}"
            )
            await ctx.reply(embed=embed, delete_after=5)
        except Exception as e:
            embed = self.create_embed(
                "❌ Purge Failed",
                f"Error: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @purge.command(name="bots")
    @commands.has_permissions(manage_messages=True)
    async def purge_bots(self, ctx, amount: int = 10):
        """Purge messages from bots"""
        if amount < 1 or amount > 1000:
            embed = self.create_embed(
                "❌ Invalid Amount",
                "Please specify a number between 1 and 1000."
            )
            return await ctx.reply(embed=embed)

        try:
            deleted = await ctx.channel.purge(
                limit=amount,
                check=lambda m: m.author.bot
            )
            
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT INTO purge_logs 
                    (guild_id, channel_id, executor_id, purge_type, count, timestamp)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, ctx.channel.id, ctx.author.id, "bots", len(deleted))
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Bot Messages Purged",
                f"Deleted **{len(deleted)}** bot messages from {ctx.channel.mention}"
            )
            await ctx.reply(embed=embed, delete_after=5)
        except Exception as e:
            embed = self.create_embed(
                "❌ Purge Failed",
# Trusty X Ayaan - discord.gg/ibadat
                f"Error: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @purge.command(name="contains")
    @commands.has_permissions(manage_messages=True)
    async def purge_contains(self, ctx, text: str, amount: int = 10):
        """Purge messages containing specific text"""
        if amount < 1 or amount > 1000:
            embed = self.create_embed(
                "❌ Invalid Amount",
                "Please specify a number between 1 and 1000."
            )
            return await ctx.reply(embed=embed)

        try:
            deleted = await ctx.channel.purge(
                limit=amount,
                check=lambda m: text.lower() in m.content.lower()
            )
            
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT INTO purge_logs 
                    (guild_id, channel_id, executor_id, purge_type, count, timestamp)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, ctx.channel.id, ctx.author.id, f"contains_{text}", len(deleted))
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Messages Purged",
                f"Deleted **{len(deleted)}** messages containing '{text}'"
            )
            await ctx.reply(embed=embed, delete_after=5)
        except Exception as e:
            embed = self.create_embed(
                "❌ Purge Failed",
                f"Error: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @purge.command(name="embeds")
    @commands.has_permissions(manage_messages=True)
    async def purge_embeds(self, ctx, amount: int = 10):
        """Purge messages with embeds"""
        if amount < 1 or amount > 1000:
            embed = self.create_embed(
                "❌ Invalid Amount",
                "Please specify a number between 1 and 1000."
            )
            return await ctx.reply(embed=embed)

        try:
            deleted = await ctx.channel.purge(
                limit=amount,
                check=lambda m: len(m.embeds) > 0
            )
            
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT INTO purge_logs 
                    (guild_id, channel_id, executor_id, purge_type, count, timestamp)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, ctx.channel.id, ctx.author.id, "embeds", len(deleted))
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Embed Messages Purged",
                f"Deleted **{len(deleted)}** messages with embeds"
            )
            await ctx.reply(embed=embed, delete_after=5)
        except Exception as e:
            embed = self.create_embed(
                "❌ Purge Failed",
                f"Error: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @purge.command(name="files")
    @commands.has_permissions(manage_messages=True)
    async def purge_files(self, ctx, amount: int = 10):
        """Purge messages with files/attachments"""
        if amount < 1 or amount > 1000:
            embed = self.create_embed(
                "❌ Invalid Amount",
                "Please specify a number between 1 and 1000."
            )
            return await ctx.reply(embed=embed)

        try:
            deleted = await ctx.channel.purge(
                limit=amount,
                check=lambda m: len(m.attachments) > 0
            )
            
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT INTO purge_logs 
                    (guild_id, channel_id, executor_id, purge_type, count, timestamp)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, ctx.channel.id, ctx.author.id, "files", len(deleted))
                )
                await db.commit()

            embed = self.create_embed(
                "✅ File Messages Purged",
                f"Deleted **{len(deleted)}** messages with attachments"
            )
            await ctx.reply(embed=embed, delete_after=5)
        except Exception as e:
            embed = self.create_embed(
                "❌ Purge Failed",
                f"Error: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @purge.command(name="logs")
    @commands.has_permissions(manage_messages=True)
    async def purge_logs(self, ctx):
        """View purge logs for this channel"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    """SELECT * FROM purge_logs 
                    WHERE guild_id = ? AND channel_id = ? 
                    ORDER BY timestamp DESC LIMIT 10""",
                    (ctx.guild.id, ctx.channel.id)
                )
                logs = await cursor.fetchall()

            if not logs:
                embed = self.create_embed(
                    "📋 Purge Logs",
                    "No purge logs found for this channel."
                )
                return await ctx.reply(embed=embed)

            log_text = ""
            for log in logs:
                executor = self.bot.get_user(log['executor_id'])
                executor_name = executor.mention if executor else f"Unknown ({log['executor_id']})"
                log_text += f"**{log['purge_type']}** - {log['count']} messages by {executor_name}\n"

            embed = self.create_embed(
                "📋 Purge Logs",
                log_text
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to fetch logs: {str(e)}"
            )
            await ctx.reply(embed=embed)


async def setup(bot):
    await bot.add_cog(Purge(bot))
