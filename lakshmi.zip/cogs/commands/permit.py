"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
from discord.ext import commands
import aiosqlite
# Developers: Trusty X Ayaan


# Trusty X Ayaan - Krishx Dev
class Permit(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/permit.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS permits (
                guild_id INTEGER,
                user_id INTEGER,
                command TEXT,
                PRIMARY KEY (guild_id, user_id, command)
            )
        ''')
        await self.db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000,
            **kwargs
        )
        return embed

    @commands.hybrid_command(name='permit', help='Permit a user to run a command')
    @commands.has_permissions(administrator=True)
    async def permit(self, ctx, user: discord.User, *, command: str):
        await self.db.execute(
            'INSERT OR REPLACE INTO permits (guild_id, user_id, command) VALUES (?, ?, ?)',
            (ctx.guild.id, user.id, command)
        )
        await self.db.commit()
        
        embed = self.create_embed(
            title="Success",
            description=f"Permitted {user.mention} to run `{command}`"
        )
        await ctx.send(embed=embed)

    async def check_permit(self, guild_id: int, user_id: int, command: str) -> bool:
        async with self.db.execute(
            'SELECT 1 FROM permits WHERE guild_id = ? AND user_id = ? AND command = ?',
            (guild_id, user_id, command)
        ) as cursor:
# Trusty X Ayaan © 2024
            return await cursor.fetchone() is not None


async def setup(bot):
    await bot.add_cog(Permit(bot))
