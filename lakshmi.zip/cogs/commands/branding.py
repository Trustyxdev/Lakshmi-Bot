"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
from discord.ext import commands
import aiosqlite
# Code by Trusty X Ayaan


class Branding(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        self.db = await aiosqlite.connect('db/branding.db')
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS branding (
                guild_id INTEGER PRIMARY KEY,
                banner_url TEXT DEFAULT '',
                avatar_url TEXT DEFAULT '',
                bio TEXT DEFAULT ''
            )
        ''')
        await self.db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000,
            **kwargs
        )
        return embed

    @commands.hybrid_group(name='customize', help='Customize server branding')
    @commands.has_permissions(administrator=True)
    async def customize(self, ctx):
        if ctx.invoked_subcommand is None:
            embed = self.create_embed(
                title="Server Customization",
                description="Use subcommands to customize your server branding"
            )
            await ctx.send(embed=embed)

    @customize.command(name='banner', help='Set server banner')
    @commands.has_permissions(administrator=True)
    async def customize_banner(self, ctx, url: str = None):
        if url is None and not ctx.message.attachments:
            embed = self.create_embed(title="Error", description="Please provide a banner URL or upload an image")
            return await ctx.send(embed=embed)
        
        banner_url = url or ctx.message.attachments[0].url
# © Trusty X Ayaan Development
        
        await self.db.execute(
            'INSERT OR REPLACE INTO branding (guild_id, banner_url) VALUES (?, ?)',
            (ctx.guild.id, banner_url)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Server banner updated")
        await ctx.send(embed=embed)

    @customize.command(name='avatar', help='Set server avatar')
    @commands.has_permissions(administrator=True)
    async def customize_avatar(self, ctx, url: str = None):
        if url is None and not ctx.message.attachments:
            embed = self.create_embed(title="Error", description="Please provide an avatar URL or upload an image")
            return await ctx.send(embed=embed)
        
        avatar_url = url or ctx.message.attachments[0].url
        
        await self.db.execute(
            'INSERT OR REPLACE INTO branding (guild_id, avatar_url) VALUES (?, ?)',
            (ctx.guild.id, avatar_url)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Server avatar updated")
        await ctx.send(embed=embed)

    @customize.command(name='bio', help='Set server bio')
    @commands.has_permissions(administrator=True)
    async def customize_bio(self, ctx, *, bio: str):
        if len(bio) > 500:
            embed = self.create_embed(title="Error", description="Bio must be 500 characters or less")
            return await ctx.send(embed=embed)
        
        await self.db.execute(
            'INSERT OR REPLACE INTO branding (guild_id, bio) VALUES (?, ?)',
            (ctx.guild.id, bio)
        )
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Server bio updated")
        await ctx.send(embed=embed)

    @customize.command(name='reset', help='Reset server branding')
    @commands.has_permissions(administrator=True)
    async def customize_reset(self, ctx):
        await self.db.execute('DELETE FROM branding WHERE guild_id = ?', (ctx.guild.id,))
        await self.db.commit()
        
        embed = self.create_embed(title="Success", description="Server branding reset")
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Branding(bot))
