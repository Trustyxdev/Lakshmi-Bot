﻿"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord 
from discord import app_commands, ui
from discord .ext import commands 
from discord .ext .commands import Context 
import aiosqlite 
import asyncio 
from utils .Tools import *
from typing import List ,Tuple 
# Code by Trusty X Ayaan

DATABASE_PATH ='db/customrole.db'
DATABASE_PATH2 ='db/np.db'


# Trusty X Ayaan - discord.gg/ibadat
class Customrole (commands .Cog ):

    def __init__ (self ,bot ):
        self .bot =bot 
        self .cooldown ={}
        self .rate_limit ={}
        self .rate_limit_timeout =5 


        self .bot .loop .create_task (self .create_tables ())

    async def send_message(self, ctx, title=None, description=None):
        view = ui.LayoutView(timeout=60.0)
        container = ui.Container(accent_color=None)
        
        if title:
            container.add_item(ui.TextDisplay(f"# {title}"))
            container.add_item(ui.Separator())
        
        if description:
            container.add_item(ui.TextDisplay(description))
        
        view.add_item(container)
        await ctx.reply(view=view)


    async def reset_rate_limit (self ,user_id ):
        await asyncio .sleep (self .rate_limit_timeout )
        self .rate_limit .pop (user_id ,None )




    async def add_role (self ,*,role_id :int ,member :discord .Member ):
        if member .guild .me .guild_permissions .manage_roles :
            role =discord .Object (id =role_id )
            await member .add_roles (role ,reason ="Lakshmi Customrole | Role Added")
        else :
            raise discord .Forbidden ("Bot does not have permission to manage roles.")



    async def remove_role (self ,*,role_id :int ,member :discord .Member ):
        if member .guild .me .guild_permissions .manage_roles :
            role =discord .Object (id =role_id )
            await member .remove_roles (role ,reason ="Lakshmi Customrole | Role Removed")
        else :
            raise discord .Forbidden ("Bot does not have permission to manage roles.")



    async def add_role2 (self ,*,role :int ,member :discord .Member ):
        if member .guild .me .guild_permissions .manage_roles :
            role =discord .Object (id =int (role ))
            await member .add_roles (role ,reason ="Lakshmi Customrole | Role Added ")

    async def remove_role2 (self ,*,role :int ,member :discord .Member ):
        if member .guild .me .guild_permissions .manage_roles :
            role =discord .Object (id =int (role ))
            await member .remove_roles (role ,reason ="Lakshmi Customrole| Role Removed")



    async def handle_role_command (self ,context :Context ,member :discord .Member ,role_type :str ):
        async with aiosqlite .connect (DATABASE_PATH )as db :
            async with db .execute (f"SELECT reqrole, {role_type} FROM roles WHERE guild_id = ?",(context .guild .id ,))as cursor :
                data =await cursor .fetchone ()
                if data :
                    reqrole_id ,role_id =data 
                    reqrole =context .guild .get_role (reqrole_id )if reqrole_id else None 
                    role =context .guild .get_role (role_id )if role_id else None 


                    if not role_id :
                        await self.send_message(context, title="❌ Role Not Configured", description=f"{role_type.capitalize()} role is not configured in {context.guild.name}.\nPlease use `setup {role_type} @role` to configure it first.")
                        return 


                    if not role :
                        await self.send_message(context, title="❌ Role Not Found", description=f"The configured {role_type} role no longer exists in {context.guild.name}.\nPlease reconfigure it using `setup {role_type} @role`.")
                        return 


                    if reqrole_id and not reqrole :
                        await self.send_message(context, title="⚠️ Required Role Missing", description=f"The required role for using custom roles no longer exists in {context.guild.name}.\nPlease reconfigure it using `setup reqrole @role`.")
                        return 


                    if reqrole_id and reqrole :
                        if context .author !=context .guild .owner and reqrole not in context .author .roles :
                            await self.send_message(context, title="⚠️ Access Denied", description=f"You need {reqrole.mention} to run this command.")
                            return 


                    try :
                        if role in member .roles :
                            await self .remove_role2 (role =role_id ,member =member )
                            await self.send_message(context, title="✅ Success", description=f"**Removed** {role.mention} from {member.mention}")
                        else :
                            await self .add_role2 (role =role_id ,member =member )
                            await self.send_message(context, title="✅ Success", description=f"**Given** {role.mention} to {member.mention}")
                    except discord .Forbidden :
                        await self.send_message(context, title="❌ Permission Error", description="I don't have permission to manage this role. Please check my role hierarchy and permissions.")
                    except Exception as e :
                        await self.send_message(context, title="❌ Error", description=f"An error occurred while managing the role: {str(e)}")
                else :
                    await self.send_message(context, title="❌ Setup Required", description=f"Role configuration is not set up in {context.guild.name}.\nPlease use `setup {role_type} @role` to configure it first.")




    async def create_tables (self ):
        async with aiosqlite .connect (DATABASE_PATH )as db :
            await db .execute ('''
                CREATE TABLE IF NOT EXISTS roles (
                    guild_id INTEGER PRIMARY KEY,
                    staff INTEGER,
                    girl INTEGER,
                    vip INTEGER,
                    guest INTEGER,
                    frnd INTEGER,
                    reqrole INTEGER
                )
            ''')
            await db .execute ('''
                CREATE TABLE IF NOT EXISTS custom_roles (
                    guild_id INTEGER,
                    name TEXT,
                    role_id INTEGER,
                    PRIMARY KEY (guild_id, name)
                )
            ''')
            await db .commit ()


    @commands .hybrid_group (name ="setup",
    description ="Setups custom roles for the server.",
    help ="Setups custom roles for the server.")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    async def set (self ,context :Context ):
        if context .subcommand_passed is None :
            await context .send_help (context .command )
            context .command .reset_cooldown (context )

    async def fetch_role_data (self ,guild_id ):
        async with aiosqlite .connect (DATABASE_PATH )as db :
            async with db .execute ("SELECT staff, girl, vip, guest, frnd, reqrole FROM roles WHERE guild_id = ?",(guild_id ,))as cursor :
                return await cursor .fetchone ()




    async def update_role_data (self ,guild_id ,column ,value ):
        try :
            async with aiosqlite .connect (DATABASE_PATH )as db :
                await db .execute (f"INSERT OR REPLACE INTO roles (guild_id, {column}) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET {column} = ?",
                (guild_id ,value ,value ))
                await db .commit ()
        except Exception as e :
            print (f"Error updating role data: {e}")


    async def fetch_custom_role_data (self ,guild_id ):
        async with aiosqlite .connect (DATABASE_PATH )as db :
            async with db .execute ("SELECT name, role_id FROM custom_roles WHERE guild_id = ?",(guild_id ,))as cursor :
                return await cursor .fetchall ()



    @set .command (name ="girl",
    description ="Setup girl role in the Guild",
    help ="Setup girl role in the Guild")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    @app_commands .describe (role ="Role to be added")
    async def girl (self ,context :Context ,role :discord .Role )->None :
        if context .author ==context .guild .owner or context .author .top_role .position >context .guild .me .top_role .position :
            await self .update_role_data (context .guild .id ,'girl',role .id )
            await self.send_message(context, title="✅ Success", description=f"Added {role.mention} to `Girl` Role\n\n__**How to Use?**__\nUse `girl <user>` Command to **Add {role.mention}** role to User & use again to the same user to **Remove role**.")
        else :
            await self.send_message(context, title="⚠️ Access Denied", description="Your role should be above my top role.")

    @set .command (name ="vip",
    description ="Setups vip role in the Guild",
    help ="Setups vip role in the Guild")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    @app_commands .describe (role ="Role to be added")
    async def vip (self ,context :Context ,role :discord .Role )->None :
        if context .author ==context .guild .owner or context .author .top_role .position >context .guild .me .top_role .position :
            await self .update_role_data (context .guild .id ,'vip',role .id )
            await self.send_message(context, description=f"Added {role.mention} to `VIP` Role\n\n__**How to Use?**__\nUse `vip <user>` Command to **Add {role.mention}** role to User & use again to the same user to **Remove role**.")
        else :
            await self.send_message(context, title="⚠️ Access Denied", description="Your role should be above my top role.")

    @set .command (name ="guest",
    description ="Setup guest role in the Guild",
    help ="Setup guest role in the Guild")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    @app_commands .describe (role ="Role to be added")
    async def guest (self ,context :Context ,role :discord .Role )->None :
        if context .author ==context .guild .owner or context .author .top_role .position >context .guild .me .top_role .position :
            await self .update_role_data (context .guild .id ,'guest',role .id )
            await self.send_message(context, description=f"Added {role.mention} to `Guest` Role\n\n__**How to Use?**__\nUse `guest <user>` Command to **Add {role.mention}** role to User & use again to the same user to **Remove role**.")
        else :
            await self.send_message(context, title="⚠️ Access Denied", description="Your role should be above my top role.")

    @set .command (name ="friend",
    description ="Setup friend role in the Guild",
    help ="Setup friend role in the Guild")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    @app_commands .describe (role ="Role to be added")
    async def friend (self ,context :Context ,role :discord .Role )->None :
        if context .author ==context .guild .owner or context .author .top_role .position >context .guild .me .top_role .position :
            await self .update_role_data (context .guild .id ,'frnd',role .id )
            await self.send_message(context, description=f"Added {role.mention} to `Friend` Role\n\n__**How to Use?**__\nUse `friend <user>` Command to **Add {role.mention}** role to User & use again to the same user to **Remove role**.")
        else :
            await self.send_message(context, title="⚠️ Access Denied", description="Your role should be above my top role.")

    @set .command (name ="reqrole",
    description ="Setup required role for custom role commands",
    help ="Setup required role for custom role commands")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,4 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    @app_commands .describe (role ="Role to be added")
    async def req_role (self ,context :Context ,role :discord .Role )->None :
        if context .author ==context .guild .owner or context .author .top_role .position >context .guild .me .top_role .position :
            await self .update_role_data (context .guild .id ,'reqrole',role .id )
            await self.send_message(context, title="✅ Success", description=f"Added {role.mention} for Required role to run custom role commands in {context.guild.name}")
        else :
            await self.send_message(context, title="⚠️ Access Denied", description="Your role should be above my top role.")



    @set .command (name ="config",
    description ="Shows the current custom role configuration in the Guild.",
    help ="Shows the current custom role configuration in the Guild.")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    async def config (self ,context :Context )->None :
        role_data =await self .fetch_role_data (context .guild .id )
        if role_data :
            view = ui.LayoutView(timeout=60.0)
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay("# Custom Role Configuration"))
            container.add_item(ui.Separator())
            
            staff_role = context.guild.get_role(role_data[0]).mention if role_data[0] else "None"
            girl_role = context.guild.get_role(role_data[1]).mention if role_data[1] else "None"
            vip_role = context.guild.get_role(role_data[2]).mention if role_data[2] else "None"
            guest_role = context.guild.get_role(role_data[3]).mention if role_data[3] else "None"
            friend_role = context.guild.get_role(role_data[4]).mention if role_data[4] else "None"
            req_role = context.guild.get_role(role_data[5]).mention if role_data[5] else "None"
            
            container.add_item(ui.TextDisplay(
# © Trusty X Ayaan Development
                f"**Staff Role**\n{staff_role}\n\n"
                f"**Girl Role**\n{girl_role}\n\n"
                f"**VIP Role**\n{vip_role}\n\n"
                f"**Guest Role**\n{guest_role}\n\n"
                f"**Friend Role**\n{friend_role}\n\n"
                f"**Required Role for Commands**\n{req_role}\n\n"
                f"_Use Commands to assign role & use again to the same user to remove role._"
            ))
            
            view.add_item(container)
            await context.reply(view=view)
        else :
            await self.send_message(context, description="No custom role configuration found in this Guild.")






    @set .command (name ="create",
    description ="Creates a custom role command.",
    help ="Creates a custom role command")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,5 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    @app_commands .describe (name ="Command name",role ="Role to be assigned")
    async def create (self ,context :Context ,name :str ,role :discord .Role )->None :
        async with aiosqlite .connect (DATABASE_PATH )as db :
            async with db .execute ("SELECT COUNT(*) FROM custom_roles WHERE guild_id = ?",(context .guild .id ,))as cursor :
                count =await cursor .fetchone ()
                if count [0 ]>=56 :
                    await self.send_message(context, title="⚠️ Access Denied", description="You have reached the maximum limit of 56 custom role commands for this guild.")
                    return 

            async with db .execute ("SELECT name FROM custom_roles WHERE guild_id = ?",(context .guild .id ,))as cursor :
                existing_role =await cursor .fetchall ()
                if any (name ==row [0 ]for row in existing_role ):
                    await self.send_message(context, description=f"A custom role command with the name `{name}` already exists in this guild. Remove it before creating a new one.")
                    return 

            await db .execute ("INSERT INTO custom_roles (guild_id, name, role_id) VALUES (?, ?, ?)",
            (context .guild .id ,name ,role .id ))
            await db .commit ()

        await self.send_message(context, title="✅ Success", description=f"Custom role command `{name}` created to assign the role {role.mention}.\n\n__**How to Use?**__\nUse `{name} <user>` Command to Assign/Remove {role.mention} role to User.\n> This will work for the users having `Manage Roles` permissions.")


    @set .command (name ="delete",aliases =["remove"],
    description ="Deletes a custom role command.",
    help ="Deletes a custom role command.")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,5 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    @app_commands .describe (name ="Command name to be deleted")
    async def delete (self ,context :Context ,name :str )->None :
        async with aiosqlite .connect (DATABASE_PATH )as db :
            async with db .execute ("SELECT name FROM custom_roles WHERE guild_id = ? AND name = ?",(context .guild .id ,name ))as cursor :
                existing_role =await cursor .fetchone ()

        if not existing_role :
            await self.send_message(context, description=f"No custom role command with the name `{name}` was found in this guild.")
            return 

        async with aiosqlite .connect (DATABASE_PATH )as db :
            await db .execute ("DELETE FROM custom_roles WHERE guild_id = ? AND name = ?",(context .guild .id ,name ))
            await db .commit ()

        await self.send_message(context, title="✅ Success", description=f"Custom role command `{name}` has been deleted.")


    @set .command (
    name ="list",
    description ="List all the custom roles setup for the server.",
    help ="List all the custom roles setup for the server."
    )
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    async def list (self ,context :Context )->None :
        custom_roles =await self .fetch_custom_role_data (context .guild .id )

        if not custom_roles :
            await self.send_message(context, description="No custom roles have been created for this server.")
            return 


        def chunk_list (data :List [Tuple [str ,int ]],chunk_size :int ):
            """Yield successive chunks of `chunk_size` from `data`."""
            for i in range (0 ,len (data ),chunk_size ):
                yield data [i :i +chunk_size ]


        chunks =list (chunk_list (custom_roles ,7 ))

        for i ,chunk in enumerate (chunks ):
            view = ui.LayoutView(timeout=60.0)
            container = ui.Container(accent_color=None)
            container.add_item(ui.TextDisplay("# Custom Roles"))
            container.add_item(ui.Separator())
            
            roles_text = ""
            for name ,role_id in chunk :
                role =context .guild .get_role (role_id )
                if role :
                    roles_text += f"**Name:** {name}\n**Role:** {role.mention}\n\n"
            
            container.add_item(ui.TextDisplay(roles_text + f"_Page {i+1}/{len(chunks)} | These commands are usable by Members having Manage Role permissions._"))
            
            view.add_item(container)
            await context .reply (view=view)


    @set .command (name ="reset",
    description ="Resets custom role configuration for the server.",
    help ="Resets custom role configuration for the server.")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,4 ,commands .BucketType .user )
    @commands .has_permissions (administrator =True )
    async def reset (self ,context :Context )->None :
        if context .author ==context .guild .owner or context .author .top_role .position >context .guild .me .top_role .position :
            removed_roles =[]
            role_data =await self .fetch_role_data (context .guild .id )
            if role_data :
                roles =["staff","girl","vip","guest","frnd","reqrole"]
                for i ,role_name in enumerate (roles ):
                    role_id =role_data [i ]
                    if role_id :
                        role =context .guild .get_role (role_id )
                        if role :
                            removed_roles .append (f"**{role_name.capitalize()}:** {role.mention}")
                            await self .update_role_data (context .guild .id ,role_name ,None )

                async with aiosqlite .connect (DATABASE_PATH )as db :
                    await db .execute ("DELETE FROM custom_roles WHERE guild_id = ?",(context .guild .id ,))
                    await db .commit ()
                    description_text = f"Deleted All Custom Role commands <:Yuna_tick:1227866641027698792>\n\n**Removed Roles:**\n" + "\n".join(removed_roles) if removed_roles else "No roles were previously set."
                    await self.send_message(context, title="Custom Role Configuration Reset", description=description_text)
            else :
                await self.send_message(context, description="No configuration found for this server.")
        else :
            await self.send_message(context, title="⚠️ Access Denied", description="Your role should be above my top role.")




    @commands .Cog .listener ()
    async def on_message (self ,message :discord .Message ):

        if message .author .bot or not message .content or not message .guild :
            return 

        prefixes =await self .bot .get_prefix (message )


        if not prefixes :
            return 


        if not any (message .content .startswith (prefix )for prefix in prefixes ):
            return 


        for prefix in prefixes :
            if message .content .startswith (prefix ):
                parts = message .content [len (prefix ):].split ()
                if not parts :
                    return 
                command_name = parts [0 ]
                break 
        else :
            return 

        guild_id =message .guild .id 


        async with aiosqlite .connect (DATABASE_PATH )as db :
            async with db .execute ("SELECT role_id FROM custom_roles WHERE guild_id = ? AND name = ?",(guild_id ,command_name ))as cursor :
                result =await cursor .fetchone ()

        if result :
            role_id =result [0 ]
            role =message .guild .get_role (role_id )


            async with aiosqlite .connect (DATABASE_PATH )as db :
                async with db .execute ("SELECT reqrole FROM roles WHERE guild_id = ?",(guild_id ,))as cursor :
                    reqrole_result =await cursor .fetchone ()

            reqrole_id =reqrole_result [0 ]if reqrole_result else None 
            reqrole =message .guild .get_role (reqrole_id )if reqrole_id else None 


            if reqrole is None :
                await message .channel .send ("⚠️ The required role is not set up in this server. Please set it up using `setup reqrole`.")
                return 


            if reqrole not in message .author .roles :
                view = ui.LayoutView(timeout=60.0)
                container = ui.Container(accent_color=None)
                container.add_item(ui.TextDisplay(f"⚠️ You need the {reqrole.mention} role to use this command."))
                view.add_item(container)
                await message.channel.send(view=view)
                return 


            member =message .mentions [0 ]if message .mentions else None 
            if not member :
                await message .channel .send ("Please mention a user to assign the role.")
                return 


            now =asyncio .get_event_loop ().time ()
            if guild_id not in self .cooldown or now -self .cooldown [guild_id ]>=10 :
                self .cooldown [guild_id ]=now 
            else :
                await message .channel .send ("You're on a cooldown of 5 seconds. Please wait before sending another command.",delete_after =5 )
                return 

            try :
                if role in member .roles :
                    await self .remove_role (role_id =role_id ,member =member )
                    view = ui.LayoutView(timeout=60.0)
                    container = ui.Container(accent_color=None)
                    container.add_item(ui.TextDisplay("# ✅ Success"))
                    container.add_item(ui.Separator())
                    container.add_item(ui.TextDisplay(f"**Removed** the role {role.mention} from {member.mention}."))
                    view.add_item(container)
                    await message.channel.send(view=view)
                else :
                    await self .add_role (role_id =role_id ,member =member )
                    view = ui.LayoutView(timeout=60.0)
                    container = ui.Container(accent_color=None)
                    container.add_item(ui.TextDisplay("# ✅ Success"))
                    container.add_item(ui.Separator())
                    container.add_item(ui.TextDisplay(f"**Added** the role {role.mention} to {member.mention}."))
                    view.add_item(container)
                    await message.channel.send(view=view)
            except discord .Forbidden as e :
                await message .channel .send ("I do not have permission to manage this role to the given user.")
                print (f"Error: {e}")
        else :
            return 




    @commands .hybrid_command (name ="girl",
    description ="Gives the girl role to the user.",
    aliases =['qt'],
    help ="Gives the girl role to the user.")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )

    async def _girl (self ,context :Context ,member :discord .Member )->None :
        await self .handle_role_command (context ,member ,'girl')

    @commands .hybrid_command (name ="vip",
    description ="Gives the VIP role to the user.",
    help ="Gives the VIP role to the user.")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )

    async def _vip (self ,context :Context ,member :discord .Member )->None :
        await self .handle_role_command (context ,member ,'vip')

    @commands .hybrid_command (name ="guest",
    description ="Gives the guest role to the user.",
    help ="Gives the guest role to the user.")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )

    async def _guest (self ,context :Context ,member :discord .Member )->None :
        await self .handle_role_command (context ,member ,'guest')

    @commands .hybrid_command (name ="friend",
    description ="Gives the friend role to the user.",
    aliases =['frnd'],
    help ="Gives the friend role to the user.")
    @blacklist_check ()
    @ignore_check ()
    @commands .cooldown (1 ,3 ,commands .BucketType .user )

    async def _friend (self ,context :Context ,member :discord .Member )->None :
        await self .handle_role_command (context ,member ,'frnd')

