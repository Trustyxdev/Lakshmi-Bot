"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import discord
import aiosqlite
from discord.ext import commands
from utils.Tools import blacklist_check, ignore_check
# Created by Trusty X Ayaan


# Trusty X Ayaan - Krishx Dev
class Greetings(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/bot_database.db") as db:
            await db.execute(
                """CREATE TABLE IF NOT EXISTS greeting_config (
                    guild_id INTEGER PRIMARY KEY,
                    join_channel_id INTEGER,
                    join_message TEXT,
                    leave_channel_id INTEGER,
                    leave_message TEXT,
                    join_dm_enabled INTEGER DEFAULT 0,
                    join_dm_message TEXT,
                    boost_channel_id INTEGER,
                    boost_message TEXT,
                    created_at TEXT
                )"""
            )
            await db.commit()

    def create_embed(self, title: str, description: str = "", **kwargs):
        embed = discord.Embed(
            title=title,
            description=description,
            color=0x000000
        )
        for key, value in kwargs.items():
            if value:
                embed.add_field(name=key, value=value, inline=False)
        return embed

    @commands.group(name="greet", invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    async def greet(self, ctx):
        """Manage greeting messages"""
        await ctx.send_help(ctx.command)

    @greet.command(name="join")
    @commands.has_permissions(manage_guild=True)
    async def greet_join(self, ctx, channel: discord.TextChannel, *, message: str):
        """Set join greeting message"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO greeting_config 
                    (guild_id, join_channel_id, join_message, created_at)
                    VALUES (?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, channel.id, message)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Join Message Set",
                f"Join messages will be sent to {channel.mention}\nMessage: {message[:100]}{'...' if len(message) > 100 else ''}"
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to set join message: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @greet.command(name="leave")
    @commands.has_permissions(manage_guild=True)
    async def greet_leave(self, ctx, channel: discord.TextChannel, *, message: str):
        """Set leave greeting message"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO greeting_config 
                    (guild_id, leave_channel_id, leave_message, created_at)
                    VALUES (?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, channel.id, message)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Leave Message Set",
                f"Leave messages will be sent to {channel.mention}\nMessage: {message[:100]}{'...' if len(message) > 100 else ''}"
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to set leave message: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @greet.command(name="joindm")
    @commands.has_permissions(manage_guild=True)
    async def greet_joindm(self, ctx, *, message: str):
        """Set join DM message"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO greeting_config 
                    (guild_id, join_dm_enabled, join_dm_message, created_at)
                    VALUES (?, 1, ?, datetime('now'))""",
                    (ctx.guild.id, message)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Join DM Message Set",
                f"New members will receive: {message[:100]}{'...' if len(message) > 100 else ''}"
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to set join DM message: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @greet.command(name="boost")
    @commands.has_permissions(manage_guild=True)
    async def greet_boost(self, ctx, channel: discord.TextChannel, *, message: str):
        """Set boost greeting message"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                await db.execute(
                    """INSERT OR REPLACE INTO greeting_config 
                    (guild_id, boost_channel_id, boost_message, created_at)
                    VALUES (?, ?, ?, datetime('now'))""",
                    (ctx.guild.id, channel.id, message)
                )
                await db.commit()

            embed = self.create_embed(
                "✅ Boost Message Set",
                f"Boost messages will be sent to {channel.mention}\nMessage: {message[:100]}{'...' if len(message) > 100 else ''}"
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to set boost message: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @greet.command(name="disable")
    @commands.has_permissions(manage_guild=True)
    async def greet_disable(self, ctx, greeting_type: str):
        """Disable a greeting type"""
        greeting_type = greeting_type.lower()
        if greeting_type not in ["join", "leave", "joindm", "boost"]:
            embed = self.create_embed(
                "❌ Invalid Type",
                "Valid types: join, leave, joindm, boost"
            )
            return await ctx.reply(embed=embed)

        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                if greeting_type == "join":
                    await db.execute(
# Code by Trusty X Ayaan
                        "UPDATE greeting_config SET join_channel_id = NULL WHERE guild_id = ?",
                        (ctx.guild.id,)
                    )
                elif greeting_type == "leave":
                    await db.execute(
                        "UPDATE greeting_config SET leave_channel_id = NULL WHERE guild_id = ?",
                        (ctx.guild.id,)
                    )
                elif greeting_type == "joindm":
                    await db.execute(
                        "UPDATE greeting_config SET join_dm_enabled = 0 WHERE guild_id = ?",
                        (ctx.guild.id,)
                    )
                elif greeting_type == "boost":
                    await db.execute(
                        "UPDATE greeting_config SET boost_channel_id = NULL WHERE guild_id = ?",
                        (ctx.guild.id,)
                    )
                await db.commit()

            embed = self.create_embed(
                "✅ Greeting Disabled",
                f"{greeting_type.title()} greeting has been disabled."
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to disable greeting: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @greet.command(name="status")
    @commands.has_permissions(manage_guild=True)
    async def greet_status(self, ctx):
        """View greeting configuration"""
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM greeting_config WHERE guild_id = ?",
                    (ctx.guild.id,)
                )
                config = await cursor.fetchone()

            if not config:
                embed = self.create_embed(
                    "📋 Greeting Status",
                    "No greeting configuration found."
                )
                return await ctx.reply(embed=embed)

            status_text = ""
            
            if config[1]:  # join_channel_id
                channel = self.bot.get_channel(config[1])
                channel_mention = channel.mention if channel else f"Unknown ({config[1]})"
                status_text += f"**Join Message:** {channel_mention}\n"
            else:
                status_text += "**Join Message:** Disabled\n"

            if config[3]:  # leave_channel_id
                channel = self.bot.get_channel(config[3])
                channel_mention = channel.mention if channel else f"Unknown ({config[3]})"
                status_text += f"**Leave Message:** {channel_mention}\n"
            else:
                status_text += "**Leave Message:** Disabled\n"

            if config[5]:  # join_dm_enabled
                status_text += "**Join DM:** Enabled\n"
            else:
                status_text += "**Join DM:** Disabled\n"

            if config[7]:  # boost_channel_id
                channel = self.bot.get_channel(config[7])
                channel_mention = channel.mention if channel else f"Unknown ({config[7]})"
                status_text += f"**Boost Message:** {channel_mention}\n"
            else:
                status_text += "**Boost Message:** Disabled\n"

            embed = self.create_embed(
                "📋 Greeting Status",
                status_text
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = self.create_embed(
                "❌ Error",
                f"Failed to fetch status: {str(e)}"
            )
            await ctx.reply(embed=embed)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM greeting_config WHERE guild_id = ?",
                    (member.guild.id,)
                )
                config = await cursor.fetchone()

                if not config:
                    return

                # Send join message
                if config[1]:  # join_channel_id
                    channel = self.bot.get_channel(config[1])
                    if channel and config[2]:  # join_message
                        message = config[2].replace("{user}", member.mention).replace("{guild}", member.guild.name)
                        try:
                            await channel.send(message)
                        except:
                            pass

                # Send join DM
                if config[5]:  # join_dm_enabled
                    if config[6]:  # join_dm_message
                        message = config[6].replace("{user}", member.mention).replace("{guild}", member.guild.name)
                        try:
                            await member.send(message)
                        except:
                            pass
        except:
            pass

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        try:
            async with aiosqlite.connect("db/bot_database.db") as db:
                cursor = await db.execute(
                    "SELECT * FROM greeting_config WHERE guild_id = ?",
                    (member.guild.id,)
                )
                config = await cursor.fetchone()

                if not config or not config[3]:  # leave_channel_id
                    return

                channel = self.bot.get_channel(config[3])
                if channel and config[4]:  # leave_message
                    message = config[4].replace("{user}", member.mention).replace("{guild}", member.guild.name)
                    try:
                        await channel.send(message)
                    except:
                        pass
        except:
            pass

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        # Check for boost
        if not before.premium_since and after.premium_since:
            try:
                async with aiosqlite.connect("db/bot_database.db") as db:
                    cursor = await db.execute(
                        "SELECT * FROM greeting_config WHERE guild_id = ?",
                        (after.guild.id,)
                    )
                    config = await cursor.fetchone()

                    if not config or not config[7]:  # boost_channel_id
                        return

                    channel = self.bot.get_channel(config[7])
                    if channel and config[8]:  # boost_message
                        message = config[8].replace("{user}", after.mention).replace("{guild}", after.guild.name)
                        try:
                            await channel.send(message)
                        except:
                            pass
            except:
# Trusty X Ayaan - discord.gg/ibadat
                pass


async def setup(bot):
    await bot.add_cog(Greetings(bot))
