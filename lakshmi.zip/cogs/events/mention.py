"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
from utils import getConfig
import discord
from discord.ext import commands
from discord import ui
from utils.Tools import get_ignore_data
import aiosqlite
import datetime
import os
import platform

INVITE_LINK = "https://discord.com/oauth2/authorize?client_id=1488832375637938227&permissions=8&integration_type=0&scope=bot"
SUPPORT_LINK = "https://discord.gg/ibadat"
WEBSITE_LINK = "https://discord.gg/ibadat"


# Created by Trusty X Ayaan
class MentionView(ui.LayoutView):

    def __init__(self, ctx_author, prefix, bot_member, bot, guild):
        super().__init__(timeout=120)
        self.ctx_author = ctx_author
        self.prefix = prefix
        self.bot_member = bot_member
        self.bot = bot
        self.guild = guild
        self.guild_icon = guild.icon.url if guild and guild.icon else None

        self.container = ui.Container(accent_color=None)
        self._build_home()
        self.add_item(self.container)

        # Single row — all buttons + home (System button removed)
        self.btn_row = ui.ActionRow(
            ui.Button(label="About Devs",  style=discord.ButtonStyle.secondary, custom_id="mention_devs"),
            ui.Button(label="Commands",    style=discord.ButtonStyle.secondary, custom_id="mention_commands"),
            ui.Button(label="Server Info", style=discord.ButtonStyle.secondary, custom_id="mention_server"),
            ui.Button(emoji="🏠",          style=discord.ButtonStyle.primary,   custom_id="mention_home"),
        )
        for child in self.btn_row.children:
            child.callback = self._dispatch
        self.add_item(self.btn_row)

    def _thumb(self):
        if self.guild_icon:
            return ui.Thumbnail(self.guild_icon)
        return None

    async def _dispatch(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx_author.id:
            return await interaction.response.send_message("This menu isn't for you.", ephemeral=True)

        try:
            if not interaction.response.is_done():
                await interaction.response.defer()
        except discord.NotFound:
            return
        except Exception:
            return

        # Disable all buttons while processing
        for child in self.btn_row.children:
            child.disabled = True
        try:
            await interaction.edit_original_response(view=self)
        except Exception:
            pass

        cid = interaction.data.get("custom_id", "")
        if cid == "mention_devs":
            self._build_devs()
        elif cid == "mention_commands":
            self._build_commands()
        elif cid == "mention_server":
            self._build_server()
        else:
            self._build_home()

        # Re-enable buttons
        for child in self.btn_row.children:
            child.disabled = False

        try:
            await interaction.edit_original_response(view=self)
        except Exception:
            pass

    async def _cat_select_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx_author.id:
            return await interaction.response.send_message("This menu isn't for you.", ephemeral=True)
        try:
            if not interaction.response.is_done():
                await interaction.response.defer()
        except Exception:
            return

        val = interaction.data.get("values", [""])[0]
        # Redirect to help command for that category
        from cogs.commands.help import HelpLayout

        class FakeCtx:
            def __init__(self, interaction, bot, prefix):
                self.author = interaction.user
                self.guild  = interaction.guild
                self.bot    = bot
                self.prefix = prefix
                self.me     = interaction.guild.me if interaction.guild else bot.user

        fake_ctx = FakeCtx(interaction, self.bot, self.prefix)
        help_view = HelpLayout(help_cog=None, ctx=fake_ctx, server_prefix=self.prefix)

        # Trigger the category content directly
        cat_map = {
            "security":   help_view.show_security_content,
            "automod":    help_view.show_automod_content,
            "giveaway":   help_view.show_giveaway_content,
            "tickets":    help_view.show_tickets_content,
            "leveling":   help_view.show_leveling_content,
            "ai":         help_view.show_ai_content,
            "voice":      help_view.show_voice_content,
            "moderation": help_view.show_moderation_content,
            "utility":    help_view.show_utility_content,
            "sticky":     help_view.show_stickynotes_content,
            "tracking":   help_view.show_tracking_content,
            "premium":    help_view.show_premium_content,
        }
        fn = cat_map.get(val)
        if fn:
            try:
                await fn(interaction)
            except Exception:
                await interaction.followup.send("Could not load category.", ephemeral=True)
        else:
            await interaction.followup.send("Category not found.", ephemeral=True)

    # ── Home ──────────────────────────────────────────────────────────────────
    def _build_home(self):
        self.container.clear_items()
        bot_name = self.bot_member.display_name
        header = ui.TextDisplay(
            f"# Hey, I'm {bot_name} <:0Salute:1488950898368708689>\n"
            f"*A **multipurpose** bot made to manage your server safely and smoothly "
            f"with **moderation, antinuke, tickets and more...** ℹ️*"
        )
        thumb = self._thumb()
        if thumb:
            self.container.add_item(ui.Section(header, accessory=thumb))
        else:
            self.container.add_item(header)
        self.container.add_item(ui.Separator())
        self.container.add_item(ui.TextDisplay(
            f"*Type `{self.prefix}help` to know more about my commands...*\n\n"
            f"**Server Prefix:** `{self.prefix}`"
        ))
        self.container.add_item(ui.Separator())

        self.container.add_item(ui.TextDisplay(
            f"[Invite]({INVITE_LINK}) · [Support]({SUPPORT_LINK}) · [Website]({WEBSITE_LINK})"
        ))

    # ── System ────────────────────────────────────────────────────────────────
    def _build_system(self):
        self.container.clear_items()
        uptime_str = "N/A"
        if hasattr(self.bot, '_start_time') and self.bot._start_time:
            delta = datetime.datetime.now(datetime.timezone.utc) - self.bot._start_time
            d = delta.days
            h, rem = divmod(delta.seconds, 3600)
            m, s = divmod(rem, 60)
            uptime_str = f"{d}d {h}h {m}m {s}s"
        try:
            import psutil
            proc = psutil.Process(os.getpid())
            mem_str = f"{proc.memory_info().rss / 1024 / 1024:.2f} MB"
        except Exception:
            mem_str = "N/A"
        total_users = sum(g.member_count or 0 for g in self.bot.guilds)
        latency = round(self.bot.latency * 1000)
        if latency < 100:   ping_icon = "🟢"
        elif latency < 200: ping_icon = "🟡"
        elif latency < 400: ping_icon = "🟠"
        else:               ping_icon = "🔴"
        total_cmds = len(set(self.bot.walk_commands()))
        py_ver = platform.python_version()
        dpy_ver = discord.__version__

        header = ui.TextDisplay(f"# <:0Salute:1488950898368708689> System Information")
        thumb = self._thumb()
        if thumb:
            self.container.add_item(ui.Section(header, accessory=thumb))
        else:
            self.container.add_item(header)
        self.container.add_item(ui.Separator())
        self.container.add_item(ui.TextDisplay(
            f"> `01.` **Bot Version** — `v1.0.0`\n"
            f"> `02.` **Python** — `v{py_ver}`\n"
            f"> `03.` **Discord.py** — `v{dpy_ver}`\n"
            f"> `04.` **Uptime** — `{uptime_str}`\n"
            f"> `05.` **Memory** — `{mem_str}`\n"
            f"> `06.` **Servers** — `{len(self.bot.guilds)}`\n"
            f"> `07.` **Users** — `{total_users:,}`\n"
            f"> `08.` **Ping** — {ping_icon} `{latency}ms`\n"
            f"> `09.` **Shards** — `{self.bot.shard_count or 1}`\n"
            f"> `10.` **Commands** — `{total_cmds}`"
        ))
        self.container.add_item(ui.Separator())
        self.container.add_item(ui.TextDisplay("Powered By Krishx Development"))

    # ── About Devs ────────────────────────────────────────────────────────────
    def _build_devs(self):
        self.container.clear_items()
        bot_name = self.bot_member.display_name
        from utils.config import OWNER_IDS
# Code by Trusty X Ayaan
        owner_id = OWNER_IDS[0] if OWNER_IDS else None
        owner_profile_url = f"https://discord.com/users/{owner_id}" if owner_id else SUPPORT_LINK
        owner_avatar_url = None
        if owner_id:
            if self.guild:
                m = self.guild.get_member(owner_id)
                if m and m.display_avatar:
                    owner_avatar_url = m.display_avatar.url
            if not owner_avatar_url:
                u = self.bot.get_user(owner_id)
                if u and u.display_avatar:
                    owner_avatar_url = u.display_avatar.url
# Built by Trusty X Ayaan Dev

        header = ui.TextDisplay(f"# <a:gawrgurafingerguns:1491702274362310676> About Developers")
        thumb = self._thumb()
        if thumb:
            self.container.add_item(ui.Section(header, accessory=thumb))
        else:
            self.container.add_item(header)
        self.container.add_item(ui.Separator())
        dev_text = ui.TextDisplay(
            f"> `01.` ***Developed And Designed By* [Trusty]({owner_profile_url}) ✅**"
        )
        if owner_avatar_url:
            self.container.add_item(ui.Section(dev_text, accessory=ui.Thumbnail(owner_avatar_url)))
        else:
            self.container.add_item(dev_text)
        self.container.add_item(ui.Separator())
        self.container.add_item(ui.TextDisplay(
            f"*The creator behind **{bot_name}***\n"
            f"Community: [Krishx Development]({SUPPORT_LINK})"
        ))

    # ── Commands ──────────────────────────────────────────────────────────────
    def _build_commands(self):
        self.container.clear_items()
        cog_map = {
            "<a:liv_glass:1491702186177204256> Security":       ["antinuke", "whitelist", "antiban", "antikick"],
            "<:redglow:1491702218825531462> Automod":           ["automod", "anticaps", "antilink", "antispam"],
            "<a:giveaway:1491454220442800138> Giveaway":        ["giveaway"],
            "<a:Tickets:1491702292028592138> Tickets":          ["ticket", "advanced"],
            "<a:FakeNitroEmoji:1491702303231840306> Leveling":  ["leveling"],
            "<a:gawrgurafingerguns:1491702274362310676> AI":    ["ai"],
            "<a:crz_music:1491702314116059238> Voice":          ["voice", "tempvc"],
            "<a:male:1491702242712092682> Moderation":          ["ban", "kick", "mute", "warn", "lock"],
            "<a:ayehaye:1491702263952052264> Utility":          ["extra", "general"],
            "<a:sal_cute_baby:1489101120293834972> Sticky":     ["sticky"],
            "<a:baby_swag_entry:1491702374400786503> Tracking": ["tracking"],
            "<a:sal_skull360:1491707164828373095> Premium":     ["premium", "guildprofile"],
        }
        all_cmds = list(self.bot.walk_commands())
        total = len(set(all_cmds))
        entries = []
        for label, keywords in cog_map.items():
            count = sum(1 for c in all_cmds if any(k in (c.cog_name or "").lower() for k in keywords))
            if count > 0:
                entries.append(f"{label} `{count}`")

        paired = []
        for i in range(0, len(entries), 2):
            left = entries[i]
            right = entries[i + 1] if i + 1 < len(entries) else ""
            paired.append(f"> {left}  ·  {right}" if right else f"> {left}")

        header = ui.TextDisplay(f"# <a:ayehaye:1491702263952052264> Command Categories")
        thumb = self._thumb()
        if thumb:
            self.container.add_item(ui.Section(header, accessory=thumb))
        else:
            self.container.add_item(header)
        self.container.add_item(ui.Separator())
        self.container.add_item(ui.TextDisplay("\n".join(paired) if paired else "> No categories found."))
        self.container.add_item(ui.Separator())
        self.container.add_item(ui.TextDisplay(
            f"**Total Commands:** `{total}`  ·  *Type `{self.prefix}help` to explore all!*"
        ))
        self.container.add_item(ui.Separator())
        self.container.add_item(ui.TextDisplay(
            f"[Invite]({INVITE_LINK}) · [Support]({SUPPORT_LINK}) · [Website]({WEBSITE_LINK})"
        ))
        self.container.add_item(ui.Separator())
        
        # Add select menu inside container
        select_menu = discord.ui.Select(
            placeholder="📂 Select a category to view commands...",
            custom_id="category_select",
            options=[
                discord.SelectOption(label="Security", emoji="<a:liv_glass:1491702186177204256>", value="security", description="Antinuke & Protection commands"),
                discord.SelectOption(label="Automod", emoji="<:redglow:1491702218825531462>", value="automod", description="Auto-moderation commands"),
                discord.SelectOption(label="Giveaway", emoji="<a:giveaway:1491454220442800138>", value="giveaway", description="Giveaway management"),
                discord.SelectOption(label="Tickets", emoji="<a:Tickets:1491702292028592138>", value="tickets", description="Ticket system commands"),
                discord.SelectOption(label="Leveling", emoji="<a:FakeNitroEmoji:1491702303231840306>", value="leveling", description="Leveling system"),
                discord.SelectOption(label="AI", emoji="<a:gawrgurafingerguns:1491702274362310676>", value="ai", description="AI commands"),
                discord.SelectOption(label="Voice", emoji="<a:crz_music:1491702314116059238>", value="voice", description="Voice & Music commands"),
                discord.SelectOption(label="Moderation", emoji="<a:male:1491702242712092682>", value="moderation", description="Moderation tools"),
                discord.SelectOption(label="Utility", emoji="<a:ayehaye:1491702263952052264>", value="utility", description="Utility commands"),
                discord.SelectOption(label="Sticky", emoji="<a:sal_cute_baby:1489101120293834972>", value="sticky", description="Sticky messages"),
                discord.SelectOption(label="Tracking", emoji="<a:baby_swag_entry:1491702374400786503>", value="tracking", description="Tracking commands"),
                discord.SelectOption(label="Premium", emoji="<a:sal_skull360:1491707164828373095>", value="premium", description="Premium features"),
            ]
        )
        select_menu.callback = self._category_select_callback
        
        # Add select menu in container as ActionRow
        self.container.add_item(ui.ActionRow(select_menu))
    
    async def _category_select_callback(self, interaction: discord.Interaction):
        """Handle category selection"""
        if interaction.user.id != self.ctx_author.id:
            return await interaction.response.send_message("❌ This menu is not for you!", ephemeral=True)
        
        await interaction.response.defer()
        category = interaction.data['values'][0]
        
        # Show commands for selected category
        self.container.clear_items()
        self.container.add_item(ui.TextDisplay(f"# 📂 {category.title()} Commands"))
        self.container.add_item(ui.Separator())
        self.container.add_item(ui.TextDisplay(f"Use `{self.prefix}help {category}` to see all commands in this category!"))
        self.container.add_item(ui.Separator())
        
        try:
            await interaction.edit_original_response(view=self)
        except:
            pass

    # ── Server Info ───────────────────────────────────────────────────────────
    def _build_server(self):
        self.container.clear_items()
        g = self.guild
        if not g:
            self.container.add_item(ui.TextDisplay("No server info available."))
            return

        created_rel = discord.utils.format_dt(g.created_at, style='R')
        created_abs = discord.utils.format_dt(g.created_at, style='D')
        owner       = g.owner.mention if g.owner else "Unknown"
        boosts      = g.premium_subscription_count or 0
        boost_lvl   = g.premium_tier
        text_ch     = len(g.text_channels)
        voice_ch    = len(g.voice_channels)
        stage_ch    = len(g.stage_channels)
        categories  = len(g.categories)
        roles       = len(g.roles) - 1  # exclude @everyone
        members     = g.member_count or 0
        bots        = sum(1 for m in g.members if m.bot)
        humans      = members - bots
        emoji_count = len(g.emojis)
        sticker_count = len(g.stickers)
        vanity      = f"`{g.vanity_url_code}`" if g.vanity_url_code else "`None`"
        nsfw_lvl    = str(g.nsfw_level).replace("NSFWLevel.", "").title()
        mfa         = "✅ Enabled" if g.mfa_level else "❌ Disabled"
        features    = ", ".join(f"`{f.replace('_',' ').title()}`" for f in g.features) or "`None`"

        # Header with server icon thumbnail
        header = ui.TextDisplay(f"# <:sal_loveu:1491697181458173980> {g.name}")
        thumb = self._thumb()
        if thumb:
            self.container.add_item(ui.Section(header, accessory=thumb))
        else:
            self.container.add_item(header)

        self.container.add_item(ui.Separator())

        self.container.add_item(ui.TextDisplay(
            f"> `01.` **Owner** — {owner}\n"
            f"> `02.` **Server ID** — `{g.id}`\n"
            f"> `03.` **Created** — {created_abs} ({created_rel})\n"
            f"> `04.` **Members** — `{humans:,}` humans · `{bots}` bots · `{members:,}` total\n"
            f"> `05.` **Channels** — `{text_ch}` text · `{voice_ch}` voice · `{stage_ch}` stage · `{categories}` categories\n"
            f"> `06.` **Roles** — `{roles}`\n"
            f"> `07.` **Emojis** — `{emoji_count}` · **Stickers** — `{sticker_count}`\n"
            f"> `08.` **Boosts** — `{boosts}` (Level `{boost_lvl}`)\n"
            f"> `09.` **Verification** — `{str(g.verification_level).title()}`\n"
            f"> `10.` **NSFW Level** — `{nsfw_lvl}`\n"
            f"> `11.` **2FA Moderation** — {mfa}\n"
            f"> `12.` **Vanity URL** — {vanity}\n"
            f"> `13.` **Features** — {features}"
        ))
        self.container.add_item(ui.Separator())
        if g.banner:
            try:
                self.container.add_item(ui.Thumbnail(media=g.banner.url))
            except Exception:
                # Fallback if Thumbnail fails
                pass
            self.container.add_item(ui.Separator())
        self.container.add_item(ui.TextDisplay("Powered By Krishx Development"))

class Mention(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/block.db") as db:
            await db.execute('''CREATE TABLE IF NOT EXISTS user_blacklist (
                user_id INTEGER PRIMARY KEY,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
            await db.execute('''CREATE TABLE IF NOT EXISTS guild_blacklist (
                guild_id INTEGER PRIMARY KEY,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
            await db.commit()

    async def is_blacklisted(self, message):
        async with aiosqlite.connect("db/block.db") as db:
            cursor = await db.execute("SELECT 1 FROM guild_blacklist WHERE guild_id = ?", (message.guild.id,))
            if await cursor.fetchone():
                return True
            cursor = await db.execute("SELECT 1 FROM user_blacklist WHERE user_id = ?", (message.author.id,))
            if await cursor.fetchone():
                return True
        return False

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
        if await self.is_blacklisted(message):
            return
        ignore_data = await get_ignore_data(message.guild.id)
        if str(message.author.id) in ignore_data["user"] or str(message.channel.id) in ignore_data["channel"]:
            return
        if message.reference and message.reference.resolved:
            if isinstance(message.reference.resolved, discord.Message):
                if message.reference.resolved.author.id == self.bot.user.id:
                    return
        if self.bot.user not in message.mentions:
            return
        if len(message.content.strip().split()) != 1:
            return

        data = await getConfig(message.guild.id)
        prefix = data["prefix"]
        view = MentionView(
            ctx_author=message.author,
            prefix=prefix,
# Trusty X Ayaan © 2024
            bot_member=message.guild.me,
            bot=self.bot,
            guild=message.guild
        )
        await message.reply(view=view, mention_author=True)
