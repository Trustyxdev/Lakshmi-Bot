"""
Lakshmi - Discord Multipurpose Bot
A powerful, feature-rich Discord bot with moderation, entertainment, and utility features.

Author: Trusty + Ayaan
Community: discord.gg/ibadat
"""
import os
import sys
# Dev: Trusty X Ayaan

# Simple .env file loader
def load_env():
    """Load environment variables from .env file"""
    # © Trusty X Ayaan Development
    env_path = '.env'
    if os.path.exists(env_path):
        with open(env_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key.strip()] = value.strip()
        return True
    else:
        print("❌ .env file not found!")
        print("📝 Please create .env file with your bot token")
        print("💡 Copy .env.example to .env and add your token")
        return False

# Load environment variables
if not load_env():
    sys.exit(1)

import asyncio 
import traceback 
import signal 
from datetime import datetime, timezone, timedelta

# Check Python version
if sys.version_info < (3, 11):
    import typing 
    if not hasattr(typing, 'Self'):
        try:
            from typing_extensions import Self 
            typing.Self = Self 
        except ImportError:
            typing.Self = type('Self', (), {})

import aiohttp 
import discord 
from discord.ext import commands, tasks
# Made by Trusty X Ayaan Dev
from core import Context 
from core.Lakshmi import Lakshmi 
from utils.Tools import *
from utils.config import *
from utils.logger import logger
# Trusty X Ayaan - Krishx Dev
import cogs

# Load jishaku if available (optional debugging tool)
try:
    import jishaku
except ImportError:
    jishaku = None

async def load_reactionrole():
    await bot.add_cog(cogs.ReactionRole(bot))

import aiosqlite 
import logging 

def print_startup_banner():
    """Print the Lakshmi startup banner"""
    # Created by Trusty X Ayaan
    RESET = "\x1b[0m"
    def fg(h):
        h = h.lstrip('#')
        # Developers: Trusty X Ayaan
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        return lambda t: f"\x1b[38;2;{r};{g};{b}m{t}{RESET}"
    
    cyan = fg('#00D9FF')
    purple = fg('#B794F4')
    green = fg('#48BB78')
    yellow = fg('#F6AD55')
    white = fg('#FFFFFF')

    lines = [
        "",
        f"  {cyan('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}",
        f"",
        f"      {purple('██╗')}      {purple('█████╗')} {purple('██╗')}  {purple('██╗')} {purple('███████╗')} {purple('██╗')}  {purple('██╗')} {purple('███╗')}   {purple('███╗')} {purple('██╗')}",
        f"      {purple('██║')}     {purple('██╔══██╗')}{purple('██║')} {purple('██╔╝')} {purple('██╔════╝')} {purple('██║')}  {purple('██║')} {purple('████╗')} {purple('████║')} {purple('██║')}",
        f"      {purple('██║')}     {purple('███████║')}{purple('█████╔╝')}  {purple('███████╗')} {purple('███████║')} {purple('██╔████╔██║')} {purple('██║')}",
        f"      {purple('██║')}     {purple('██╔══██║')}{purple('██╔═██╗')}  {purple('╚════██║')} {purple('██╔══██║')} {purple('██║╚██╔╝██║')} {purple('██║')}",
        f"      {purple('███████╗')}{purple('██║')}  {purple('██║')}{purple('██║')}  {purple('██╗')} {purple('███████║')} {purple('██║')}  {purple('██║')} {purple('██║')} {purple('╚═╝')} {purple('██║')} {purple('██║')}",
        f"      {purple('╚══════╝')}╚═╝  ╚═╝╚═╝  ╚═╝ ╚══════╝ ╚═╝  ╚═╝ ╚═╝     ╚═╝ ╚═╝",
        f"",
        f"      {white('Multipurpose Discord Bot')}  {cyan('•')}  {yellow('v2.0.0')}",
        f"",
        f"  {cyan('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}",
        f"",
        f"      {green('✓')} Developers    {white('Trusty X Ayaan')}",
        f"      {green('✓')} Community     {white('discord.gg/ibadat')}",
        f"      {green('✓')} Status        {green('Online & Ready')}",
        f"",
        f"  {cyan('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}",
        "",
    ]
    for line in lines:
        sys.stdout.write(line + "\n")
    sys.stdout.flush()

def print_system_ready():
    """Print the final system ready message"""
    RESET = "\x1b[0m"
    def fg(h):
        h = h.lstrip('#')
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        return lambda t: f"\x1b[38;2;{r};{g};{b}m{t}{RESET}"
    
    green = fg('#48BB78')
    cyan = fg('#00D9FF')
    
    print(f"\n  {cyan('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}")
    print(f"      {green('✓')} Bot is now online and ready to serve!")
    print(f"  {cyan('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}\n")

# Setup logging
_log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
os.makedirs(_log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.ERROR,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(_log_dir, 'discord.log'))
    ]
)

logging.getLogger('discord').setLevel(logging.ERROR)
logging.getLogger('discord.http').setLevel(logging.ERROR)
logging.getLogger('discord.gateway').setLevel(logging.ERROR)
logging.getLogger('discord.client').setLevel(logging.ERROR)

class DatabaseTestFilter(logging.Filter):
    def filter(self, record):
        message = record.getMessage().lower()
        if 'database connection test successful' in message:
            return False 
        return True 

for logger_name in ['discord', 'discord.http', 'discord.gateway', 'discord.client']:
    std_logger = logging.getLogger(logger_name)
    std_logger.propagate = True
    std_logger.handlers = []
    std_logger.addFilter(DatabaseTestFilter())

logging.getLogger().addFilter(DatabaseTestFilter())

# Jishaku environment variables
os.environ["JISHAKU_NO_DM_TRACEBACK"] = "False"
os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_FORCE_PAGINATOR"] = "True"

def utc_to_ist(dt):
    ist_offset = timedelta(hours=5, minutes=30)
    return dt.replace(tzinfo=timezone.utc).astimezone(timezone(ist_offset))

class LakshmiBot(Lakshmi):
    def __init__(self):
        # Trusty X Ayaan © 2024
        super().__init__()
        self.db = None

    async def setup_hook(self):
        print_startup_banner()
        logger.info("BOOT", "Connecting to database")
        try:
            self.db = await aiosqlite.connect("db/bot_database.db")
            if self.db is None:
                raise Exception("Failed to connect to database")

            logger.success("DB", "Connected successfully")
            
            # Initialize tools database
            from utils.Tools import init_tools_db
            await init_tools_db()
            
            from utils.Tools import updateAllGuildsPrefixFromEnv
            await updateAllGuildsPrefixFromEnv()
            
            logger.success("DB", "Schema initialized")

            # Initialize ticket system tables
            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS tickets (
                    guild_id INTEGER PRIMARY KEY,
                    channel_id INTEGER,
                    role_id INTEGER,
                    category_id INTEGER,
                    log_channel_id INTEGER,
                    ping_role_id INTEGER,
                    embed_title TEXT DEFAULT 'Create a Ticket',
                    embed_description TEXT DEFAULT 'Need assistance? Select a category below to create a ticket, and our support team will assist you shortly! 📩',
                    embed_footer TEXT DEFAULT 'Powered by Krishx Development',
                    embed_image_url TEXT,
                    embed_color INTEGER DEFAULT 16711680,
                    panel_type TEXT DEFAULT 'dropdown'
                )
            """)

            async with self.db.cursor() as cur:
                await cur.execute("PRAGMA table_info(tickets)")
                columns = [col[1] for col in await cur.fetchall()]
                if "panel_type" not in columns:
                    await cur.execute("ALTER TABLE tickets ADD COLUMN panel_type TEXT DEFAULT 'dropdown'")
                if "ping_role_id" not in columns:
                    await cur.execute("ALTER TABLE tickets ADD COLUMN ping_role_id INTEGER")

            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS ticket_categories (
                    guild_id INTEGER,
                    category_name TEXT,
                    PRIMARY KEY (guild_id, category_name)
                )
            """)

            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS ticket_panels (
                    guild_id INTEGER,
                    channel_id INTEGER,
                    message_id INTEGER,
                    PRIMARY KEY (guild_id, message_id)
                )
            """)

            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS guild_blacklist (
                    guild_id INTEGER PRIMARY KEY,
                    reason TEXT,
                    blacklisted_at TEXT
                )
            """)

            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS user_blacklist (
                    user_id INTEGER PRIMARY KEY,
                    reason TEXT,
                    blacklisted_at TEXT
                )
            """)

            await self.db.commit()
            logger.success("DB", "Tables created")
        except Exception as e:
            logger.error("DB", f"Database setup failed: {e}")
            raise 

        logger.info("BOOT", "Loading core modules")
        try:
            # Try to load jishaku (optional debugging tool)
            if jishaku:
                try:
                    await self.load_extension("jishaku")
                    logger.info("BOOT", "Debug tools loaded")
                except Exception as e:
                    pass  # Silently skip if jishaku not available
            
            await self.load_extension("cogs")
        except Exception as e:
            logger.error("BOOT", f"Failed to load extensions: {e}")
            raise 

        logger.info("BOOT", "Synchronizing command tree")
        try:
            synced = await self.tree.sync()
            logger.info("BOOT", f"Synced {len(synced)} slash commands")
        except Exception as e:
            logger.error("BOOT", f"Failed to sync commands: {e}")
            raise

        logger.info("BOOT", "Finalizing setup")
        try:
            self.setup_component_interactions()
            logger.success("BOOT", "Initialization complete")
        except Exception as e:
            logger.error("BOOT", f"Failed to setup components: {e}")

    def setup_component_interactions(self):
        """Setup component interaction handlers for Components v2"""
        pass 

    async def close(self):
        try:
            if hasattr(self, 'status_rotation'):
                self.status_rotation.cancel()

            if self.db:
                await self.db.close()
                logger.info("DB", "Database connection gracefully closed")

            import gc 
            for obj in gc.get_objects():
                try:
                    if hasattr(obj, 'close') and 'aiosqlite' in str(type(obj)):
                        try:
                            await obj.close()
                        except:
                            pass 
                except:
                    pass

        except Exception as e:
            logger.error("SHUTDOWN", f"Failed to close resources: {e}")
        finally:
            await super().close()

client = LakshmiBot()
tree = client.tree 

@client.check
async def global_bot_access_check(ctx):
    """Global check for bot access control - applies to all commands"""
    # Owner always has access
    if ctx.author.id in [1414058403202072688, 1442939274982068335]:
        return True

    # Check if guild has access restrictions
    async with aiosqlite.connect('db/bot_database.db') as db:
        cursor = await db.execute(
            "SELECT normal_users_blocked, premium_users_blocked FROM bot_access WHERE guild_id = ?",
            (ctx.guild.id,)
        )
        row = await cursor.fetchone()

        if not row:
            return True

        normal_blocked, premium_blocked = row

        # Check if user is premium
        is_premium = False
        try:
            async with aiosqlite.connect('db/premium.db') as pdb:
                pcursor = await pdb.execute(
                    "SELECT user_id FROM premium_users WHERE user_id = ?",
                    (ctx.author.id,)
                )
                prow = await pcursor.fetchone()
                is_premium = prow is not None
        except:
            pass

        # Check access based on user type
        if is_premium:
            if premium_blocked:
                container = discord.ui.Container(accent_color=None)
                container.add_item(discord.ui.TextDisplay("# 🔴 Access Denied"))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay(
                    "Premium users are currently blocked from using this bot in this server.\n\n"
                    "Contact server administrators for more information."
                ))
                view = discord.ui.LayoutView()
                view.add_item(container)
                await ctx.send(view=view, delete_after=10)
                return False
            return True
        else:
            if normal_blocked:
                container = discord.ui.Container(accent_color=None)
                container.add_item(discord.ui.TextDisplay("# 🔴 Access Denied"))
                container.add_item(discord.ui.Separator())
                container.add_item(discord.ui.TextDisplay(
                    "Normal users are currently blocked from using this bot in this server.\n\n"
                    "Consider getting premium access or contact server administrators."
                ))
                view = discord.ui.LayoutView()
                view.add_item(container)
                await ctx.send(view=view, delete_after=10)
                return False
            return True

@client.event 
async def on_ready():
    await client.wait_until_ready()

    import datetime
    if not hasattr(client, '_start_time') or client._start_time is None:
        client._start_time = datetime.datetime.now(datetime.timezone.utc)

    # Don't set status here - let owner commands control it
    # Status will be set manually using .setonline, .setidle, etc.

    logger.success("READY", f"Logged in as {client.user.name}")

    print_system_ready()

# Get configuration from environment
TOKEN = os.getenv("TOKEN")
WEBHOOK_URL = os.getenv("WEBHOOK_URL")
PREFIX = os.getenv("BOT_PREFIX", ".")

if TOKEN is None:
    logger.error("TOKEN environment variable not set in .env file. Please ensure your .env file contains the TOKEN.")
    print("\n❌ ERROR: Bot token not found!")
    print("📝 Please add your bot token to .env file")
    print("💡 Copy .env.example to .env and add your token\n")
    sys.exit(1)

if WEBHOOK_URL is None:
    logger.warning("WEBHOOK_URL not set - logging webhook disabled")

if PREFIX is None:
    logger.warning("PREFIX not set - using default: .")

async def run_bot():
    """Run the bot with graceful shutdown handling"""
    try:
        logger.info("BOOT", "Establishing connection to Discord")
        await client.start(TOKEN)
    except discord.LoginFailure:
        logger.error("BOOT", "Authentication failed - Invalid token configuration")
        print("\n❌ ERROR: Invalid bot token!")
        print("📝 Please check your token in .env file\n")
    except KeyboardInterrupt:
        logger.info("BOOT", "Keyboard interrupt received, shutting down...")
    except Exception as e:
        logger.error("BOOT", f"Startup failed: {e}")
    finally:
        if not client.is_closed():
            logger.info("BOOT", "Shutdown signal received, stopping bot gracefully...")
            await client.close()
        logger.success("BOOT", "Bot shutdown completed gracefully")

if __name__ == '__main__':
    try:
        asyncio.run(run_bot())
    except KeyboardInterrupt:
        logger.info("BOOT", "Received keyboard interrupt, shutdown complete.")
    except Exception as e:
        logger.error("BOOT", f"Critical error: {e}")
        sys.exit(1)
