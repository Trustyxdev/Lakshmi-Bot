# ⚠️ IMPORTANT DISCLAIMER & LEGAL NOTICE

## 🔴 READ THIS BEFORE USING THIS SOFTWARE

---

## 📜 Copyright & Ownership

**This software is the intellectual property of:**
- **Developers:** Trusty X Ayaan
- **Organization:** Krishx Development
- **Copyright:** © 2024-2026 All Rights Reserved

---

## ⚖️ Legal Terms & Conditions

### ✅ YOU ARE ALLOWED TO:

1. ✅ **Use** this bot for personal or commercial purposes (with attribution)
2. ✅ **Modify** the code to suit your needs
3. ✅ **Learn** from the codebase and improve your skills
4. ✅ **Fork** and create your own versions (with proper credits)
5. ✅ **Host** this bot on your own servers
6. ✅ **Contribute** improvements back to the community

### 🔴 YOU ARE STRICTLY PROHIBITED FROM:

1. ❌ **Claiming** this software as your own creation
2. ❌ **Removing** developer credits from source code
3. ❌ **Selling** this software without explicit written permission
4. ❌ **Rebranding** without proper attribution to original developers
5. ❌ **Distributing** modified versions without crediting original authors
6. ❌ **Using** for illegal, malicious, or harmful purposes
7. ❌ **Violating** Discord's Terms of Service or Community Guidelines

---

## 🚨 CONSEQUENCES OF LICENSE VIOLATION

### If you violate these terms, we will take the following actions:

#### 1️⃣ **DMCA Takedown Notice**
- Your repository will be reported to GitHub/GitLab/hosting platform
- Your content will be removed within 24-48 hours
- Your account may receive strikes or suspension

#### 2️⃣ **Legal Action**
We reserve the right to pursue legal action including but not limited to:
- **Copyright Infringement Claims** under DMCA (Digital Millennium Copyright Act)
- **Intellectual Property Theft** prosecution
- **Breach of Contract** lawsuits
- **Cease and Desist** orders

#### 3️⃣ **Financial Penalties**
You may be held liable for:
- **Statutory Damages:** Up to $150,000 per violation (US Copyright Law)
- **Legal Fees:** All attorney costs and court expenses
- **Lost Revenue:** Compensation for unauthorized commercial use
- **Punitive Damages:** Additional penalties for willful infringement

#### 4️⃣ **Community Ban**
- Permanent ban from discord.gg/ibadat
- Blacklist from all support services
- Public disclosure of violation (if severe)

---

## 🔍 CREDIT DETECTION SYSTEM

⚠️ **IMPORTANT:** This codebase contains:
- **509 embedded attribution markers** across **153+ files**
- **Hidden developer signatures** in multiple locations
- **Timestamp verification** systems
- **Code fingerprinting** technology

### What this means:
- ✅ We can **prove original authorship** in any legal dispute
- ✅ We can **detect credit removal** attempts automatically
- ✅ We can **track unauthorized distributions** across the internet
- ✅ We have **evidence** for legal proceedings

**Attempting to remove all credits is:**
- ⏰ Extremely time-consuming (hours of work)
- 🔍 Easily detectable (we have automated tools)
- ⚖️ Legally actionable (clear evidence of intent)
- 💸 Not worth the risk (potential $150K+ in damages)

---

## 📋 PROPER ATTRIBUTION REQUIREMENTS

### When using or distributing this software, you MUST include:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                    LAKSHMI DISCORD BOT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Original Developers: Trusty X Ayaan
Organization: Krishx Development
Community: discord.gg/ibadat

This bot is based on open-source code created by Krishx Development.
Licensed under MIT License with mandatory attribution requirements.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### In your README.md, include:

```markdown
## Credits

This bot is based on [Lakshmi Bot](link-to-repo) created by 
**Trusty X Ayaan** from **Krishx Development**.

- Original Repository: [link]
- Community: discord.gg/ibadat
- License: MIT with Attribution
```

---

## 💼 COMMERCIAL USE POLICY

### Free Commercial Use (WITH CONDITIONS):
- ✅ You may use this bot for commercial purposes
- ✅ You may charge for hosting services
- ✅ You may offer premium features
- ⚠️ **BUT** you MUST maintain all credits and attribution

### Paid Distribution (REQUIRES PERMISSION):
- ❌ You CANNOT sell this bot as a product without permission
- ❌ You CANNOT offer it as a paid download
- ❌ You CANNOT claim exclusive ownership
- ✅ Contact us for commercial licensing agreements

---

## 🛡️ WARRANTY DISCLAIMER

```
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
NONINFRINGEMENT.

IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE 
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION 
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN 
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
```

### What this means:
- ⚠️ We are NOT responsible for any damages caused by using this software
- ⚠️ We do NOT guarantee the software will work perfectly
- ⚠️ You use this software at your own risk
- ⚠️ We are NOT liable for Discord account bans or server issues
- ⚠️ You are responsible for complying with Discord's Terms of Service

---

## 🔒 PRIVACY & DATA COLLECTION

### This bot may collect:
- Server IDs and names
- User IDs (for features like leveling, warnings, etc.)
- Message content (for moderation features)
- Voice channel data (for music features)

### Your responsibilities:
- ✅ Comply with GDPR, CCPA, and other privacy laws
- ✅ Inform users about data collection in your privacy policy
- ✅ Provide data deletion options
- ✅ Secure database files properly
- ✅ Do NOT share user data with third parties without consent

---

## 🚫 PROHIBITED USES

### You MAY NOT use this software for:

1. ❌ **Illegal Activities**
   - Harassment, doxxing, or cyberbullying
   - Spreading malware or viruses
   - Unauthorized access to systems (hacking)
   - Distribution of illegal content

2. ❌ **Discord ToS Violations**
   - Self-botting or user-botting
   - API abuse or rate limit circumvention
   - Spam or mass DM campaigns
   - Token grabbing or phishing

3. ❌ **Malicious Purposes**
   - Raiding or nuking servers
   - Creating fake verification bots
   - Scamming or fraud
   - Impersonating official Discord bots

4. ❌ **Unethical Practices**
   - Selling user data
   - Unauthorized surveillance
   - Manipulating or deceiving users
   - Violating user privacy

---

## 📞 REPORTING VIOLATIONS

### If you find someone violating this license:

1. **Gather Evidence:**
   - Screenshot the violation
   - Save repository links
   - Document the infringement

2. **Report to Us:**
   - Join discord.gg/ibadat
   - Contact Trusty X Ayaan
   - Provide all evidence

3. **We Will:**
   - Investigate the claim
   - Issue warnings or takedown notices
   - Take legal action if necessary
   - Protect the community

---

## 🤝 COMMUNITY GUIDELINES

### Be a Good Community Member:

✅ **DO:**
- Give credit where it's due
- Contribute improvements back to the project
- Help other users in the community
- Report bugs and security issues
- Follow Discord's Terms of Service
- Respect intellectual property rights

❌ **DON'T:**
- Steal code and claim it as yours
- Remove credits to hide the source
- Use the bot for harmful purposes
- Violate others' privacy
- Engage in toxic behavior
- Ignore license requirements

---

## 📚 ADDITIONAL RESOURCES

- **License:** See [LICENSE](LICENSE) file
- **Setup Guide:** See [SETUP_GUIDE.md](SETUP_GUIDE.md)
- **Features:** See [BOT_FEATURES_LIST.md](BOT_FEATURES_LIST.md)
- **Community:** discord.gg/ibadat
- **Support:** Join our Discord for help

---

## ✅ ACKNOWLEDGMENT

By using, modifying, or distributing this software, you acknowledge that:

1. ✅ You have read and understood this disclaimer
2. ✅ You agree to comply with all license terms
3. ✅ You will maintain proper attribution
4. ✅ You understand the legal consequences of violations
5. ✅ You will use this software responsibly and ethically

---

## 🎯 FINAL MESSAGE

**We created this bot to help the Discord community.** It's free, open-source, 
and packed with features. All we ask is that you:

1. **Give credit** to the original developers
2. **Follow the license** terms
3. **Be ethical** in your usage
4. **Support the community** by contributing back

**It's that simple.** Don't make it complicated by trying to steal credit.

---

## 📧 CONTACT INFORMATION

**For licensing inquiries, permissions, or to report violations:**

- **Discord Community:** discord.gg/ibadat
- **Developers:** Trusty X Ayaan
- **Organization:** Krishx Development

**For legal matters:**
- Contact through Discord server for official communication channels

---

## 🔐 LEGAL JURISDICTION

This license and disclaimer are governed by international copyright law and 
the laws of the jurisdiction where the developers reside. Any legal disputes 
will be resolved in accordance with applicable laws.

---

<div align="center">

**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

### ⚖️ RESPECT THE LICENSE • GIVE CREDIT • BE ETHICAL ⚖️

**© 2024-2026 Trusty X Ayaan | Krishx Development**

**All Rights Reserved**

**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

</div>

---

*Last Updated: May 3, 2026*
*Version: 2.0.0*
