"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""

import sys
import pytz
from datetime import datetime
import traceback
import os

config = {
    'logLevel': 'debug',
    'defaultContext': 'APP',
    'timezone': 'Asia/Kolkata',
}

# ── ANSI helpers ──────────────────────────────────────────────────────────────

def _fg(hex_color):
    h = hex_color.lstrip('#')
    r, g, b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
    return lambda t: f"\x1b[38;2;{r};{g};{b}m{t}\x1b[0m"

def _bg(bg_hex, fg_hex):
    bh = bg_hex.lstrip('#'); fh = fg_hex.lstrip('#')
    br,bgc,bb = int(bh[0:2],16), int(bh[2:4],16), int(bh[4:6],16)
    fr,fg,fb  = int(fh[0:2],16), int(fh[2:4],16), int(fh[4:6],16)
    return lambda t: f"\x1b[48;2;{br};{bgc};{bb}m\x1b[38;2;{fr};{fg};{fb}m{t}\x1b[0m"

RESET  = "\x1b[0m"
BOLD   = "\x1b[1m"
DIM    = "\x1b[2m"

# ── Palette ───────────────────────────────────────────────────────────────────
# Modern cyan/purple theme
_CYAN       = _fg('#00D9FF')
_PURPLE     = _fg('#B794F4')
_GREEN      = _fg('#48BB78')
_YELLOW     = _fg('#F6AD55')
_RED        = _fg('#FC8181')
_GRAY       = _fg('#A0AEC0')
_WHITE      = _fg('#FFFFFF')
_BLUE       = _fg('#4299E1')

# Badge backgrounds  (bg, fg)
_BADGE = {
    'BOOT':    _bg('#F6AD55', '#FFFAF0'),   # orange/yellow - was purple
    'LOAD':    _bg('#00B5D8', '#E6FFFA'),   # cyan - was CORE
    'DB':      _bg('#38B2AC', '#E6FFFA'),   # teal
    'READY':   _bg('#48BB78', '#F0FFF4'),   # green
    'SYSTEM':  _bg('#4299E1', '#EBF8FF'),   # blue
    'PFPS':    _bg('#9F7AEA', '#FAF5FF'),   # purple
    'DATABASE':_bg('#38B2AC', '#E6FFFA'),   # teal
    'ERROR':   _bg('#F56565', '#FFF5F5'),   # red
    'WARN':    _bg('#ED8936', '#FFFAF0'),   # orange
    'APP':     _bg('#4A5568', '#F7FAFC'),   # gray
}
_DEFAULT_BADGE = _bg('#4A5568', '#F7FAFC')

# ── Symbols ───────────────────────────────────────────────────────────────────
_SYM = {
    'BOOT':    '◈',  # diamond symbol instead of lightning
    'LOAD':    '▣',  # was CORE with ◆
    'DB':      '◉',
    'READY':   '✓',
    'SYSTEM':  '●',
    'PFPS':    '◈',
    'DATABASE':'◎',
    'ERROR':   '✗',
    'WARN':    '⚠',
}

# ── Divider ───────────────────────────────────────────────────────────────────
_DIV = _GRAY(' │ ')

# Trusty X Ayaan - Krishx Dev
class Logger:
    def __init__(self):
        self.levels = {'debug': 0, 'info': 1, 'success': 2, 'warn': 3, 'error': 4}
        self.console_log_level = self.levels.get(config.get('logLevel', 'debug'), 0)
        try:
            self.tz = pytz.timezone(config['timezone'])
        except Exception:
            self.tz = pytz.UTC
        self.log_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'logs', 'bot.log')
        os.makedirs(os.path.dirname(self.log_file), exist_ok=True)

    def _time(self):
        return datetime.now(self.tz).strftime('%H:%M:%S')

    def _parse(self, args):
        context = config['defaultContext']
        error = None
        a = list(args)
        if a and isinstance(a[-1], Exception):
            error = a.pop()
        if a and isinstance(a[0], str) and a[0].isupper() and len(a[0]) <= 12:
            context = a.pop(0)
        msg_parts = []
        for x in a:
            if isinstance(x, (dict, list)):
                import json
# Dev: Trusty X Ayaan
                try:    msg_parts.append(json.dumps(x, indent=2))
                except: msg_parts.append(str(x))
            else:
                msg_parts.append(str(x))
        return context, " ".join(msg_parts), error

    def _badge(self, ctx):
        fn = _BADGE.get(ctx, _DEFAULT_BADGE)
        sym = _SYM.get(ctx, '›')
        return fn(f" {sym} {ctx} ")

    def _log(self, level, *args):
        if self.levels[level] < self.console_log_level:
            return
        context, msg, error = self._parse(args)

        # File log
        ts = datetime.now(self.tz).strftime('%Y-%m-%d %H:%M:%S')
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(f"[{ts}] [{level.upper()}] [{context}] {msg}\n")
            if error:
                traceback.print_exception(type(error), error, error.__traceback__, file=f)

        # Console — only show info and success
        if level not in ('info', 'success'):
            return

        time_str  = _GRAY(f"[{self._time()}]")
        badge_str = self._badge(context)

        if level == 'success':
            msg_str = _GREEN(msg)
        else:
            msg_str = _WHITE(msg)

        line = f"{time_str}{_DIV}{badge_str} {msg_str}"
        sys.stdout.write(line + RESET + "\n")
        sys.stdout.flush()

    def info(self, *a):    self._log('info',    *a)
    def success(self, *a): self._log('success', *a)
# Trusty X Ayaan © 2024
    def warn(self, *a):    self._log('warn',    *a)
    def error(self, *a):   self._log('error',   *a)
    def debug(self, *a):   self._log('debug',   *a)
    def warning(self, *a): self._log('warn',    *a)  # Alias for warn

logger = Logger()
