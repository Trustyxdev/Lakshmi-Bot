"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
from __future__ import annotations 
import discord 
from utils .config import BotName 
from discord .ext import commands 
from discord .ext .commands import Context ,Paginator as CmdPaginator 
from typing import Any ,List 
# Built by Trusty X Ayaan Dev


# Developers: Trusty X Ayaan
class FieldPagePaginator:

    def __init__ (self ,
    entries :list [tuple [Any ,Any ]],
    *,
    per_page :int =10 ,
    inline :bool =False ,
    **kwargs )->None :
        self .entries = entries
        self .per_page = per_page
        self .embed :discord .Embed =discord .Embed (
        title =kwargs .get ('title'),
        description =kwargs .get ('description'),
        color =kwargs .get ('color', 0x000000) )
        self .inline :bool =inline 

    def get_max_pages (self):
        return (len(self.entries) + self.per_page - 1) // self.per_page

    async def format_page (self ,current_page :int ,ctx :Context)->discord .Embed :
        self .embed .clear_fields ()
        
        start = current_page * self.per_page
        end = start + self.per_page
        entries = self.entries[start:end]

        for key ,value in entries :
            self .embed .add_field (name =key ,value =value ,inline =self .inline )

        maximum = self.get_max_pages()
        if maximum >1 :
            text =f'• Page {current_page + 1}/{maximum} | Requested by {ctx.author.display_name}'
            self .embed .set_footer (
            text =text ,
            icon_url =
            "https://i.ibb.co/TxtQNnyH/2400e46b-9674-4142-b2dc-73244e769c3b.png"
            )

        return self .embed 


class TextPaginator:

    def __init__ (self ,text ,*,prefix ='```',suffix ='```',max_size =2000 ):
        pages =CmdPaginator (prefix =prefix ,
        suffix =suffix ,
        max_size =max_size -200 )
        for line in text .split ('\n'):
            pages .add_line (line )

        self.pages = pages.pages
        self.per_page = 1

    def get_max_pages(self):
        return len(self.pages)

    async def format_page (self ,current_page :int ,ctx :Context)->str :
        content = self.pages[current_page]
        maximum = self.get_max_pages()
        if maximum >1 :
            return f'{content} {BotName} • Page {current_page + 1}/{maximum}'
        return content 


class DescriptionEmbedPaginator:

    def __init__ (self ,
    entries :list [Any ],
    *,
    per_page :int =10 ,
    **kwargs )->None :
        self .entries = entries
        self .per_page = per_page
        self .embed :discord .Embed =discord .Embed (
        title =kwargs .get ('title'),
        color =kwargs .get ('color', 0x000000),
        )

    def get_max_pages(self):
        return (len(self.entries) + self.per_page - 1) // self.per_page

    async def format_page (self ,current_page :int ,ctx :Context)->discord .Embed :
        self .embed .clear_fields ()
        
        start = current_page * self.per_page
        end = start + self.per_page
        entries = self.entries[start:end]

        self .embed .description ='\n'.join (entries )

        maximum = self.get_max_pages()
        if maximum >1 :
            text =f'• Page {current_page + 1}/{maximum} | Requested by {ctx.author.display_name}'
            self .embed .set_footer (
            text =text ,
            icon_url =
# Created by Trusty X Ayaan
            "https://i.ibb.co/TxtQNnyH/2400e46b-9674-4142-b2dc-73244e769c3b.png"
            )

        return self .embed

