"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
import os 
# Made by Trusty X Ayaan Dev

TOKEN = os.environ.get("TOKEN")
LOG_CHANNEL_ID = int(os.environ.get("LOG_CHANNEL_ID", 0))
NAME = "Lakshmi"
server = "https://discord.gg/ibadat"
ch = "https://discord.com/channels/1324668335069331477/1324668336470102143"

# Debug: Print what we're reading
_owner_ids_str = os.environ.get("OWNER_IDS", "")
_npqts_ids_str = os.environ.get("NPQTS_IDS", "")
# Created by Trusty X Ayaan
_premium_ids_str = os.environ.get("PREMIUM_IDS", "")

OWNER_IDS = [int(x.strip()) for x in _owner_ids_str.split(",") if x.strip()]
NPQTS_IDS = [int(x.strip()) for x in _npqts_ids_str.split(",") if x.strip()]
PREMIUM_IDS = [int(x.strip()) for x in _premium_ids_str.split(",") if x.strip()]

BotName = "Lakshmi"
serverLink = "https://discord.gg/ibadat"

invite_link = "https://discord.com/oauth2/authorize?client_id=1488832375637938227&permissions=8&integration_type=0&scope=bot"
website_link = "https://example.com"
support_link = "https://discord.gg/ibadat"
"""
: ! Lakshmi !
# Dev: Trusty X Ayaan
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""

