"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""
from __future__ import annotations 

from discord .ext import commands 
# Built by Trusty X Ayaan Dev

__all__ =("Cog",)


# Created by Trusty X Ayaan
# Dev: Trusty X Ayaan
class Cog (commands .Cog ):

    def __init__ (self ,*args ,**kwargs )->None :
        super ().__init__ (*args ,**kwargs )

    def __str__ (self )->str :
        return "{0.__class__.__name__}".format (self )
"""
: ! Lakshmi !
    + Discord: Trusty + Ayaan
    + Community: https://discord.gg/ibadat (Krishx Development )
    + for any queries reach out Community or DM me.
"""

